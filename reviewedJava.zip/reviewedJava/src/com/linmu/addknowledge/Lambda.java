package com.linmu.addknowledge;

/**
 * @author Jackson Black
 * @version The past cannot be redeemed, the future can be changed.
 * @CreateTime 2022/12/2 14:22:27
 * <p>
 * <p>
 * lambda表达式：参数列表 -> 方法体
     * 1. 不需要参数,返回值为 2
     * () -> 2
     * 2. 接收一个参数(数字类型),返回其2倍的值
     * x -> 2 * x
     * 3. 接受2个参数(数字),并返回他们的和
     * (x, y) -> x + y
     * 4. 接收2个int型整数,返回他们的乘积
     * (int x, int y) -> x * y
     * 5. 接受一个 string 对象,并在控制台打印,不返回任何值(看起来像是返回void)
     * (String s) -> System.out.print(s)
 * <p>
 * <p>
 * 函数式接口定义：一个接口有且只有一个抽象方法
 * <p>
 * <p>
 * 3.语法精简
     * Lambda表达式的语法还可以精简，显得非常有逼格，但是可读性就非常差。
     * 1.参数类型可以省略，如果需要省略，每个参数的类型都要省略。
     * 2.参数的小括号里面只有一个参数，那么小括号可以省略
     * 3.如果方法体当中只有一句代码，那么大括号可以省略
     * 4.如果方法体中只有一条语句，其是return语句，那么大括号可以省略，且去掉return关键字
 **/
@SuppressWarnings({"all"})
public class Lambda {
    public static void main(String[] args) {
//        IA ia = () -> 123;
//        System.out.println(ia.print());
        IA ia = (a, b) -> a + b;
        System.out.println(ia.add(1, 2));
    }
}

interface IA {
    //    int print();
    int add(int a, int b);
}
