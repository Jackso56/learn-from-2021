package com.linmu.IO_.inputstream_;

import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class ObjectInputStream_ {

    @Test
    public void method01() throws IOException, ClassNotFoundException {
        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream("d:/IO流/file10.txt"));
        System.out.println(objectInputStream.read());
        System.out.println(objectInputStream.readFloat());
        System.out.println(objectInputStream.readDouble());
        System.out.println(objectInputStream.readBoolean());
        System.out.println(objectInputStream.readChar());
        System.out.println(objectInputStream.readUTF());
        System.out.println(objectInputStream.readObject());
        objectInputStream.close();
    }
}
