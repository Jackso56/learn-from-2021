package com.linmu.IO_.inputstream_;


import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 输入到程序中表示input/reader
 * 输出到存储中表示output/writer
 * BufferedInputStream/BufferedOutputStream是处理流，内嵌字节流
 **/
@SuppressWarnings({"all"})
public class BufferedInputStream_ {
    @Test
    public void method01() throws IOException {
        String src = new String("d:/IO流/1.jpg");
        String desc = new String("d:/IO流/2.jpg");
        BufferedInputStream bufferedInputStream = new BufferedInputStream(
                new FileInputStream(src));
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
                new FileOutputStream(desc));
        byte[] bytes = new byte[1024];
        int length_ = 0;
        while((length_ = bufferedInputStream.read(bytes)) != -1){
            bufferedOutputStream.write(bytes);
        }
        if (bufferedOutputStream != null){
            bufferedOutputStream.close();
        }
        if (bufferedInputStream != null){
            bufferedInputStream.close();
        }


    }
}
