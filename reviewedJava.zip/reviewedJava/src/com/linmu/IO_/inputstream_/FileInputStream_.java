package com.linmu.IO_.inputstream_;

import org.testng.annotations.Test;
import java.io.*;
import java.lang.String;
/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * FileInputStream构造器：FileInputStream(filePath)，FileInputStream(File)
 * FileInputStream方法：read()读取一个字节的数据,其中汉字占3个字节
 *                      read(byte[] byte)读取指定长度的数据，可以提高读取的效率
 *
 **/
@SuppressWarnings({"all"})
public class FileInputStream_ {
    public static void main(String[] args) throws IOException {
//        文件路径
        String filePath = new String("d:/IO流/newfile.txt");
//        创建FileInputStream对象,抛出异常
        FileInputStream fileInputStream = new FileInputStream(filePath);
//        读取数据1
        System.out.println("read()方法读取数据：" + (char) fileInputStream.read());
//        数据读取的辅助变量
        byte[] by = new byte[1024];
        int length_ = 0;
//        循环读取数据2
        while((length_ = fileInputStream.read(by)) != -1){
            System.out.print("read(byte[] bytes)方法读取数据：" + new String(by,0, length_));
        }
//        关闭资源
        fileInputStream.close();
    }

    @Test
    public void constracter() throws IOException {
//        文件路径
        String filePath = new String("d:/IO流/file02.txt");
//        创建File对象
        File file = new File(filePath);
//        创建OutputStreamWriter对象
        FileInputStream fileinputStream = new FileInputStream(file);
        byte[] by = new byte[1024];
        int length_ = 0;
//        循环读取数据2
        while((length_ = fileinputStream.read(by)) != -1){
                System.out.print("read(byte[] bytes)方法读取数据：" + new String(by,0, length_));
        }
//        关闭资源
        fileinputStream.close();
    }
}
