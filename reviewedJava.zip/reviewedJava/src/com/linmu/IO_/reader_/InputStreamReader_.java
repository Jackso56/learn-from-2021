package com.linmu.IO_.reader_;

import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 使读取编码和读入编码的编码方式一样，可以有效的解决乱码的问题
 **/
@SuppressWarnings({"all"})
public class InputStreamReader_ {
    @Test
    public void method01() throws IOException {
        String filePath = new String("d:/IO流/file06.txt");
        String CharSet = "gbk";
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
                new FileInputStream(filePath), CharSet));
        String str = null;
        while ((str = bufferedReader.readLine()) != null ){
            System.out.println(str);
        }
        bufferedReader.close();
    }
}
