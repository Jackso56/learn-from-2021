package com.linmu.IO_.reader_;

import org.testng.annotations.Test;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class BufferedReader_ {

    @Test
    public void method01() throws IOException {
        String filePath = new String("d:/IO流/file05.txt");
        BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
//        要变量来接收数据，不然会读取两行数据吗，却只输出一行数据
        String str = null;
//        读取数据：readline()
        while (!((str = bufferedReader.readLine()) == null)) {
            System.out.println(str);
        }
        bufferedReader.close();


    }
}
