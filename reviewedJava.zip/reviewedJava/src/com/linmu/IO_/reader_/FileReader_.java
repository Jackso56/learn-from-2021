package com.linmu.IO_.reader_;

import org.testng.annotations.Test;

import java.io.FileReader;
import java.io.IOException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class FileReader_ {

    @Test // read(char c)方法读取数据
    public void method01() throws IOException {
        String filePath = new String("d:/IO流/file03.txt");
        FileReader fileReader = new FileReader(filePath);
        int length_ = 0;
        while((length_ = fileReader.read()) != -1){
            System.out.println("读取数据：" + (char)length_);
        }
    }

    @Test // read(char[] chars)方法读取数据
    public void method02() throws IOException {
        String filePath = new String("d:/IO流/file03.txt");
        FileReader fileReader = new FileReader(filePath);
        char[] chars = new char[1024];
        int length_ = 0;
        while((length_ = fileReader.read(chars)) != -1){
            System.out.println("读取数据：" + new String(chars,0, length_));
        }
    }
}
