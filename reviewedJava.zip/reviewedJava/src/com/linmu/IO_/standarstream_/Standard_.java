package com.linmu.IO_.standarstream_;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 *
 * 输入流和输出流是针对计算而言，
 * 输入到计算机表示输入流，
 * 输出到显示屏上表示输出流。
 **/
@SuppressWarnings({"all"})
public class Standard_ {
    public static void main(String[] args) {
//        标准输入流（键盘输入）
//        public final static InputStream in = null;
//        编译类型：InputStream
//        运行类型：BufferedInputStream
        System.out.println("System.in运行类型：" + System.in.getClass());
//        标准输出流（显示屏输出）
//        public final static PrintStream out = null;
//        编译类型：PrintStream
//        运行类型：PrintStream
        System.out.println("System.out运行类型：" + System.out.getClass());
    }
}
