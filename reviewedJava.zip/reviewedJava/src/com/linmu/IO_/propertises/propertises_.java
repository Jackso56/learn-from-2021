package com.linmu.IO_.propertises;

import org.testng.annotations.Test;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class propertises_ {

    @Test
    public void method01() throws IOException {
//        1.创建Properties对象
        Properties properties = new Properties();
//        2.加载配置文件
        properties.load(new FileReader("src\\a.properties"));
//        创建修改配置文件内容
        properties.setProperty("age","20");
        properties.setProperty("no.","1");
//        中文保存的是Unicode编码
        properties.setProperty("name","林沐");
//        3.将配置文件的全部内容显示在控制台
        properties.list(System.out);
//        4.根据键获取值
        String name = properties.getProperty("name");
        String age = properties.getProperty("age");
        System.out.println("name=" + name +"\t" + "age=" + age);
//        保存文件
        properties.store(new FileOutputStream("src\\c.properties"),null);
    }
}
