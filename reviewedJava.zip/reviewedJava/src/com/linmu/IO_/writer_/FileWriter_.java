package com.linmu.IO_.writer_;

import org.testng.annotations.Test;

import java.io.FileWriter;
import java.io.IOException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * FileWriter构造器：FileWriter(filePath)---覆盖写 ,FileWriter(filePath,true)---追加写
 * FileWriter方法：write(char c),write(int num),write(char[],off,len),write(String str),
 *                  write(String str,off,length)
 **/
@SuppressWarnings({"all"})
public class FileWriter_ {
    @Test // 覆盖写内容
    public void method01() throws IOException {
        String filePath = new String("d:/IO流/file04.txt");
        FileWriter fileWriter = new FileWriter(filePath);
        fileWriter.write("hello,word.你好，世界");
//        使用FileWriter对象以字节的形式写入要进行手动装箱
        fileWriter.write("A");
        fileWriter.write("林羽",0,2);
        fileWriter.close();
    }

    @Test // 创建写入内容
    public void method02() throws IOException {
        String filePath = new String("d:/IO流/file04.txt");
        FileWriter fileWriter = new FileWriter(filePath,true);
        fileWriter.write("林羽师弟");
        fileWriter.close();
    }
}
