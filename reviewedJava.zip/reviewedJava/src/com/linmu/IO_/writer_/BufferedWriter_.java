package com.linmu.IO_.writer_;

import org.testng.annotations.Test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 *
 * 方法：write(int c),write(String str),write(char[] cbuf, int off, int len),
 *      write(String s, int off, int len)
 *      newLine()：换行
 *      flush()：刷新
 *      close()：关闭流，先刷新。
 **/
@SuppressWarnings({"all"})
public class BufferedWriter_ {

    @Test // BufferedWriter类覆盖写
    public void method01() throws IOException {
        String filePath = new String("d:/IO流/file05.txt");
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filePath));
//        内容写入
        bufferedWriter.write("罗峰：无敌战胜");
//        换行
        bufferedWriter.newLine();
        bufferedWriter.write("罗华：世界银行八大掌控人之一");
        bufferedWriter.close();
    }

    @Test // BufferedWriter类追加写
    public void method02() throws IOException {
        String filePath = new String("d:/IO流/file05.txt");
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(filePath,true));
        bufferedWriter.write("罗峰：无敌战胜");
        bufferedWriter.newLine();
        bufferedWriter.write("罗华：世界银行八大掌控人之一");
        bufferedWriter.close();
    }
}
