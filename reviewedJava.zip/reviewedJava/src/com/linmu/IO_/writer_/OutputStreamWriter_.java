package com.linmu.IO_.writer_;


import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * OutputStreamWriter类：将字节流转换为字符流
 * 方法：write(char[] buf)，write(char[] buf, int off, int len)，
 *       write(int c)，	write(String s)，write(String s, int off, int len)
 **/
@SuppressWarnings({"all"})
public class OutputStreamWriter_ {

    @Test
    public void method01() throws IOException {
        String filePath = new String("d:/IO流/file06.txt");
        String CharSet = "gbk";
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(new FileOutputStream(filePath), CharSet);
        outputStreamWriter.write("萧炎斗之气九段");
        outputStreamWriter.close();
    }
}
