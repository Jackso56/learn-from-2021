package com.linmu.IO_.outputStream_;


import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * FileOutputStream类：创建对象时，若文件不存在，则会自动创建文件
 * FileOutputStream构造器：FileOutputStream(filePath),FileOutputStream(File),FileOutputStream(filePath,true) 可追加写
 * FileOutputStream方法： write(byte b)方法写入内容,
 *                        write(byte[] bytes)方法写入内容,
 *                        write(byte[] bytes,int off,int len)方法写入内容
 *                        (内容写入时会覆盖原有的内容)
 *
 **/
@SuppressWarnings({"all"})
public class FileOutputStream_ {

    @Test
    public void constracter() throws IOException {
//        文件路径
        String filePath = new String("d:/IO流/file02.txt");
//        创建File对象
        File file = new File(filePath);
//        创建OutputStreamWriter对象
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        byte[] bytes = "java".getBytes();
        fileOutputStream.write(bytes);
//        关闭资源
        fileOutputStream.close();
    }
    @Test // write(byte b)方法写入内容
    public void writerContent01() throws IOException {
//        创建文件路径
        String filePath = new String("d:/IO流/file01.txt");
//        创建FileOutputStream对象
        FileOutputStream fileOutputStream = new FileOutputStream(filePath);
//        写入内容
        fileOutputStream.write('a');
//        关闭资源
        fileOutputStream.close();
    }

    @Test // write(byte[] bytes)方法写入内容
    public void writerContent02() throws IOException {
//        创建文件路径
        String filePath = new String("d:/IO流/file01.txt");
//        创建FileOutputStream对象
        FileOutputStream fileOutputStream = new FileOutputStream(filePath);
        byte[] bytes = "hello,world……".getBytes();
//        写入内容,会覆盖原有的内容
        fileOutputStream.write(bytes);
//        关闭资源
        fileOutputStream.close();
    }

    @Test // write(byte[] bytes,int off,int len)方法写入内容
    public void writerContent03() throws IOException {
//        创建文件路径
        String filePath = new String("d:/IO流/file01.txt");
//        创建FileOutputStream对象
        FileOutputStream fileOutputStream = new FileOutputStream(filePath);
        byte[] bytes = "hello,world……".getBytes();
//        写入内容,会覆盖原有的内容
        fileOutputStream.write(bytes,5,3);
//        关闭资源
        fileOutputStream.close();
    }

    @Test // FileOutputStream(filePath,true) 追加写
    public void constracter02() throws IOException {
//        创建文件路径
        String filePath = new String("d:/IO流/file01.txt");
//        创建FileOutputStream对象
        FileOutputStream fileOutputStream = new FileOutputStream(filePath,true);
        byte[] bytes = "hello,world……".getBytes();
//        写入内容,会覆盖原有的内容
        fileOutputStream.write(bytes,0, bytes.length);
//        关闭资源
        fileOutputStream.close();
    }
}
