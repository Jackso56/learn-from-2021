package com.linmu.IO_.outputStream_;

import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 要求实现了Serializable接口的对象才可序列化
 * 反序列化的顺序与序列化的顺序要一致，并且要求内容一致
 **/
@SuppressWarnings({"all"})
public class ObjectOutputStream_{
    @Test
    public void method01() throws IOException {
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                new FileOutputStream("d:/IO流/file10.txt"));
        objectOutputStream.write(3);
        objectOutputStream.writeFloat(3.1f);
        objectOutputStream.writeDouble(3.14);
        objectOutputStream.writeBoolean(true);
        objectOutputStream.writeChar('a');
        objectOutputStream.writeUTF("林沐师兄");
        objectOutputStream.writeObject(new Dog("jack",3,14.1));
        objectOutputStream.close();
    }

    @Test
    public void method02() throws IOException {
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(
                new FileOutputStream("d:/IO流/file11.txt"));
        objectOutputStream.writeObject(new Dog("jack",3,14.1));
        objectOutputStream.close();
    }
}
class Dog implements Serializable{
    private String name;
    private int age;
    private double weight;

    public Dog(String name, int age, double weight) {
        this.name = name;
        this.age = age;
        this.weight = weight;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }
}