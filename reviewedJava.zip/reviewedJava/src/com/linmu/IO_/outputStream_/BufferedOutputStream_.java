package com.linmu.IO_.outputStream_;

import org.testng.annotations.Test;

import java.io.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class BufferedOutputStream_ {
    @Test
    public void method01() throws IOException {
        String src = new String("d:/IO流/3.jpg");
        String desc = new String("d:/IO流/4.jpg");
        BufferedInputStream bufferedInputStream = new BufferedInputStream(
                new FileInputStream(src));
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(
                new FileOutputStream(desc));
        byte[] bytes = new byte[1024];
        int length_ = 0;
        while((length_ = bufferedInputStream.read(bytes)) != -1){
            bufferedOutputStream.write(bytes);
        }
        if (bufferedOutputStream != null){
//            BufferedInputStream关闭资源可以用flush
            bufferedOutputStream.flush();
        }
        if (bufferedInputStream != null){
            bufferedInputStream.close();
        }


    }

}
