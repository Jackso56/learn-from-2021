package com.linmu.IO_.doc_;

import java.io.File;
import java.io.IOException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * File类的基本方法：exists(),getName(),getAbsoluteFile(),getAbsolutePath(),
 *                      length(),getParent(),isFile(),isDirectory()
 **/
@SuppressWarnings({"all"})
public class File_ {
    public static void main(String[] args) throws IOException {
//        1.创建文件路径
        String filePath = new String("d:\\IO流\\newFile.txt");
//        2.创建文件对象
        File file = new File(filePath);
//        3.调用方法创建新文件
        boolean newFile = file.createNewFile();
        System.out.println("文件是否创建：" + newFile); // 文件仅创建一次
        System.out.println("文件名称：" + file.getName());
        System.out.println("文件绝对名称：" + file.getAbsoluteFile());
        System.out.println("文件绝对路径：" + file.getAbsolutePath());
        System.out.println("文件大小（字节数）：" + file.length());
        System.out.println("返回父级路径：" + file.getParent());
        System.out.println("文件是否存在：" + file.exists());
        System.out.println("文件是否为文件：" + file.isFile());
        System.out.println("文件是否为目录：" + file.isDirectory());
    }
}
