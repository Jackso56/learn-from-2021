package com.linmu.IO_.doc_;

import org.testng.annotations.Test;

import java.io.File;
import java.io.IOException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 *  File类的基本方法：mkdir(),      mkdirs(),     delete()
 *                  创建单级目录，  创建多级目录
 **/
@SuppressWarnings({"all"})
public class File_1 {
    public static void main(String[] args) throws IOException {
        String filePath = new String("d:/IO流/创建目录/newfile");
        File file = new File(filePath);
        if(! (file.exists())){
            file.mkdirs();
            System.out.println("文件创建成功...");
        }else {
            System.out.println("文件存在...");
        }
    }

    @Test
    public void deleteFile(){
        String string = new String("d:/IO流/newFile.txt");
        File string1 = new File(string);
        if (string1.exists()){
            string1.delete();
            System.out.println("删除成功...");
        }else {
            System.out.println("不存在...");
        }
    }
}
