package com.linmu.regularexception_.commonlyusedclass;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Matcher类：start(),end(),matches(),replaceAll()
 * PatternSyntaxException是一个非强制异常，，表示一个正则表达式模式中的语法错误
 **/
@SuppressWarnings({"all"})
public class Matcher_ {

    @Test
    public void method01(){
        String content = "hello tom hello jack hello jackson";
        String target = "hello";
        Pattern compile = Pattern.compile(target);
        Matcher matcher = compile.matcher(content);
        while (matcher.find()){
            System.out.println("========");
            // start():返回开始     end():结束索引
            System.out.println(matcher.start() + " " + matcher.end());
            // 通过索引取字符串
            System.out.println(content.substring(matcher.start(),matcher.end()));
        }
    }

    @Test
    public void nethod02(){
        String content = "hello tom hello jack hello jackson";
        String target = "hello.*";
        Pattern compile = Pattern.compile(target);
        Matcher matcher = compile.matcher(content);
        // matches():类似于整体匹配
        System.out.println("是否匹配成功：" + matcher.matches());
    }

    @Test
    public void method03(){
        String content = "hello tom hello jack hello jackson";
        String target = "hello";
        Pattern compile = Pattern.compile(target);
        Matcher matcher = compile.matcher(content);
        // replaceAll():返回修改后的内容，不修改原文
        System.out.println("修改后的内容：" + matcher.replaceAll("你好"));
    }
}
