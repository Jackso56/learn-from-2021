package com.linmu.regularexception_.commonlyusedclass;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Pattern类：没有公共构造方法，需要调用静态方法来
 *              创建Pattern对象：Pattern.compile(pattern)
 * Pattern类常用方法：matches(),compile()
 *
 **/
@SuppressWarnings({"all"})
public class Pattern_ {

    @Test
    public void method01(){
        String str = "43534534";
        Pattern compile = Pattern.compile("\\d\\d");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method02(){ // Pattern.matches 用于整体匹配，常用于格式验证
        String str = "hello,jackson.How are you?";
        String reg = ".*jackson.*";
        boolean matches = Pattern.matches(reg, str);
        System.out.println("匹配是否成功：" +matches);
    }
//    public static boolean matches(String regex, CharSequence input) {
//        Pattern p = Pattern.compile(regex);
//        Matcher m = p.matcher(input);
//        return m.matches();
//    }
}
