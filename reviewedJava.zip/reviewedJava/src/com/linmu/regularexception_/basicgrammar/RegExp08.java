package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 分组：非命名捕获（），命名捕获（?<name>）
 **/
@SuppressWarnings({"all"})
public class RegExp08 {

    @Test
    public void method01(){ // 非命名捕获（）
        String str = "123454678978673";
        Pattern compile = Pattern.compile("(\\d\\d)(\\d\\d)");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
            System.out.println("组1找到：" + matcher.group(1));
            System.out.println("组2找到：" + matcher.group(2));
        }
    }

    @Test
    public void method02(){ // 命名捕获（?<name>）
        String str = "123454678978673";
        Pattern compile = Pattern.compile("(?<g1>\\d\\d)(?<g2>\\d\\d)");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
            System.out.println("组1找到：" + matcher.group("g1"));
            System.out.println("组2找到：" + matcher.group("g2"));
        }
    }
}
