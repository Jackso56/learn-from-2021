package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 贪婪模式（默认）：匹配最多字符
 * 非贪婪模式：末尾加上"+"，匹配最少字符
 **/
@SuppressWarnings({"all"})
public class RegExp10 {

    @Test
    public void method01(){ // 贪婪模式
        String str = "1342342134234213";
        Pattern compile = Pattern.compile("\\d{3,5}");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method02(){ // 非贪婪模式
        String str = "1342342134234213";
        Pattern compile = Pattern.compile("\\d{3,5}?");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }
}
