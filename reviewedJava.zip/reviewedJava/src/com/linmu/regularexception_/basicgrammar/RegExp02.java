package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 源码分析（不考虑分组）：
 * 1）matcher.find()返回字符串的 开始索引 和 结束索引+1
 * 2）结束索引+1 即 下一次find的开始索引（这与索引的取值有关）
 * 3）并将序号存放在groups数组中:groups(0),groups(1)
 * 4）其中oldlast的值也为 结束索引+1
 * matcher.group(0)源码：
 * public String group(int group) {
 *         if (first < 0)
 *             throw new IllegalStateException("No match found");
 *         if (group < 0 || group > groupCount())
 *             throw new IndexOutOfBoundsException("No group " + group);
 *         if ((groups[group*2] == -1) || (groups[group*2+1] == -1))
 *             return null;
 *         return getSubSequence(groups[group * 2], groups[group * 2 + 1]).toString();
 *     }
 *   其中return getSubSequence(groups[group * 2], groups[group * 2 + 1]).toString();
 *   为核心代码
 *
 * 源码分析（考虑分组）：
 * 1）matcher.find()返回字符串的 开始索引 和 结束索引+1
 * 2）结束索引+1 即 下一次find的开始索引（这与索引的取值有关）
 * 3）并将序号存放在groups数组中:groups(0),groups(1)（子组的情况）
 *      第一组：group(2)和group(3)
 *      第二组：group(4)和group(5)
 *      以此类推……
 * 4）其中oldlast的值也为 结束索引+1
 *
 *
 *
 **/
@SuppressWarnings({"all"})
public class RegExp02 {

    @Test
    public void method01(){ // 不考虑分组
        String content ="2000年5月，JDK1.3、JDK1.4和J2SE1.3相继发布，" +
                "几周后其获得了Apple公司Mac OS X的工业标准的支持。" +
                "2001年9月24日，J2EE1.3发布。2002年2月26日，J2SE1.4发布。" +
                "自此Java的计算能力有了大幅提升，与J2SE1.3相比，" +
                "其多了近62%的类和接口。在这些新特性当中，还提供了广泛的" +
                "XML支持、安全套接字（Socket）支持（通过SSL与TLS协议）、" +
                "全新的I/OAPI、正则表达式、日志与断言。2004年9月30日，" +
                "J2SE1.5发布，成为Java语言发展史上的又一里程碑。" +
                "为了表示该版本的重要性，J2SE 1.5更名为Java SE 5.0（内部版" +
                "本号1.5.0），代号为“Tiger”，Tiger包含了从" +
                "1996年发布1.0版本以来的最重大的更新，其中包括泛型" +
                "支持、基本类型的自动装箱、改进的循环、枚举类型、格式化I/O及可变参数。";
        //(1)匹配目标:\d 表示任意数字，涉及转义字符，所有用 \\d
        String target = "\\d\\d\\d\\d";
        //(2)创建模式对象
        Pattern pattern = Pattern.compile(target);
        //(3)创建匹配器
        Matcher matcher = pattern.matcher(content);
        //(4)取出字符
        while(matcher.find()){
            System.out.println("找到:" + matcher.group(0));
        }
    }

    @Test
    public void method02(){ // 考虑分组
        String content ="2000年5月，JDK1.3、JDK1.4和J2SE1.3相继发布，" +
                "几周后其获得了Apple公司Mac OS X的工业标准的支持。" +
                "2001年9月24日，J2EE1.3发布。2002年2月26日，J2SE1.4发布。" +
                "自此Java的计算能力有了大幅提升，与J2SE1.3相比，" +
                "其多了近62%的类和接口。在这些新特性当中，还提供了广泛的" +
                "XML支持、安全套接字（Socket）支持（通过SSL与TLS协议）、" +
                "全新的I/OAPI、正则表达式、日志与断言。2004年9月30日，" +
                "J2SE1.5发布，成为Java语言发展史上的又一里程碑。" +
                "为了表示该版本的重要性，J2SE 1.5更名为Java SE 5.0（内部版" +
                "本号1.5.0），代号为“Tiger”，Tiger包含了从" +
                "1996年发布1.0版本以来的最重大的更新，其中包括泛型" +
                "支持、基本类型的自动装箱、改进的循环、枚举类型、格式化I/O及可变参数。";
        //(1)匹配目标:\d 表示任意数字，涉及转义字符，所有用 \\d
        String target = "(\\d\\d)(\\d\\d)";
        //(2)创建模式对象
        Pattern pattern = Pattern.compile(target);
        //(3)创建匹配器
        Matcher matcher = pattern.matcher(content);
        //(4)取出字符
        while(matcher.find()){
            System.out.println("找到:" + matcher.group(0));
        }
    }
}
