package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 元字符之定位符：^ 以什么开头，$ 以什么结尾，\\b匹配边界字符,\\B匹配非边界字符
 **/
@SuppressWarnings({"all"})
public class RegExp07 {

    @Test
    public void method01(){ // ^ 匹配
        String str = "123asd 23123asdas";
        Pattern compile = Pattern.compile("^[0-9]*");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method02(){ // $ 匹配
        String str = "123asd 23123asdas";
        Pattern compile = Pattern.compile("^[0-9]*.*[a-z]*$");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void methid03(){ // \\b 匹配
        String str = "jackson jack are man jack";
        Pattern compile = Pattern.compile("jack\\b");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void methid04(){ // \\B 匹配
        String str = "jackson jack are man jack";
        Pattern compile = Pattern.compile("jack\\B");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }
}
