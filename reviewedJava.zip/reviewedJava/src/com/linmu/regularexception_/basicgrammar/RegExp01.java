package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class RegExp01 {
    //    正则表达式快速入门
    @Test
    public void method01() {
//        需处理的文本
        String string = "许多程序设计语言都支持利用正则表达式进行字符串操作。" +
                "例如，在Perl中就内建了一个功能强大的正则表达式引擎。" +
                "正则表达式这个概念最初是由Unix中的工具软件（例如sed和grep）普及开来的，" +
                "后来在广泛运用于Scala 、PHP、C# 、Java、C++ 、Objective-c、Perl 、Swift、" +
                "VBScript 、Javascript、Ruby 以及Python等等。正则表达式通常缩写成“regex”，" +
                "单数有regexp、regex，复数有regexps、regexes、regexen。\n";
//          (1) 匹配目标（匹配目标：正则）
        String target = "[a-zA-Z]";
//        （2）创建模式对象（创建对象，传入正则）
        Pattern compile = Pattern.compile(target);
//        (3) 创建匹配器（调用方法，生成匹配器）
        Matcher matcher = compile.matcher(string);
//        (4) 输出内容（寻找、输出内容）
        while (matcher.find()) {
            System.out.print(matcher.group(0) + " ");
        }
    }
}
