package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 元字符之字符匹配符
 * 1）符号：[] 可接收的字符序列，[^] 可接收的字符序列，- 连接符，
 *          .匹配除了换行符以外的所有字符，\\d ===> [0-9]，
 *          \\D ===> [^0-9]，\\w ===> [0-9a-zA-Z]，\\W[^0-9a-zA-Z]，
 *          \\s 匹配空白字符，\\S匹配非空白字符
 * 2）字母大小写区分(二选一)：默认区分大小写，(?i)表示不区分大小写，更精确，可指定到单个字符;
 *                      匹配对象需要加参数Pattern.CASE_INSENSITIVE
 *
 **/
@SuppressWarnings({"all"})
public class RegExp04 {

    @Test
    public void method01() {  //  //d匹配
        String str = "123312asdAWgf]]]";
        Pattern compile = Pattern.compile("\\d");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print(matcher.group(0) + "\t");
        }
    }

    @Test
    public void method02() {  //  //D匹配
        String str = "123312asdgf]]]";
        Pattern compile = Pattern.compile("\\D");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print(matcher.group(0) + "\t");
        }
    }

    @Test
    public void method03() {  //  //w匹配
        String str = "123312asdgf]]]";
        Pattern compile = Pattern.compile("\\w");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print(matcher.group(0) + "\t");
        }
    }

    @Test
    public void method04() {  //  //W匹配
        String str = "123312asdgf]]]";
        Pattern compile = Pattern.compile("\\W");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print(matcher.group(0) + "\t");
        }
    }

    @Test
    public void method05() {  //  大小写区分
        String str = "123312abcABC]]]";
        Pattern compile = Pattern.compile("abc",Pattern.CASE_INSENSITIVE);
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print(matcher.group(0) + "\t");
        }
    }

    @Test
    public void method06() {  //  //s匹配
        String str = "123312  abcABC]  ]]";
        Pattern compile = Pattern.compile("\\s");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print("找到：" + matcher.group(0) + "\t");
        }
    }

    @Test
    public void method07() {  //  //S匹配
        String str = "123312  abcABC]  ]]";
        Pattern compile = Pattern.compile("\\S");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print("找到：" + matcher.group(0) + "\t");
        }
    }

    @Test
    public void method08() {  //  .匹配,匹配除了\n以外的所有字符
                            // 匹配本身要用转义符  \\.
        String str = "123312  abcABC]  ]]";
        Pattern compile = Pattern.compile(".");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()) {
            System.out.print("找到：" + matcher.group(0) + "\t");
        }
    }
}
