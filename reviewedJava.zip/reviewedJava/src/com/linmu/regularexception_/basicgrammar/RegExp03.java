package com.linmu.regularexception_.basicgrammar;


import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 元字符之转义符
 * 1）符号：\\
 * 2）需要转义的字符：*、+、（、）、$、\、/、？、{、}、^
 **/
@SuppressWarnings({"all"})
public class RegExp03 {

    @Test
    public void method01(){
        String str = "ab$d]}";
        Pattern compile = Pattern.compile("\\$");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }
}
