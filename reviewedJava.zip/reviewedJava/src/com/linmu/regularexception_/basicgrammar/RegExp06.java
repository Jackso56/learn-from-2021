package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 元字符之限定符（作为后缀使用）：* 重复0~N次，+ 重复1~N次，？重复0~1次
 *                 {n} 匹配n个字符，{n,} 至少匹配n个字符，
 *                 {n，m} 至少匹配n个字符，最多匹配m个字符
 *
 *
 **/
@SuppressWarnings({"all"})
public class RegExp06 {

    @Test
    public void method01(){ // {n}
        String str = "aaabbbbabababababa";
        Pattern compile = Pattern.compile("a{2}");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method02(){ // {n,}
        String str = "aaabbbbabababababa";
        Pattern compile = Pattern.compile("a{2,}");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method03(){ // {n,m}
        String str = "aaaaaababababababa";
        Pattern compile = Pattern.compile("a{2,4}");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method04(){ // +
        String str = "aaaaaababababababa";
        Pattern compile = Pattern.compile("a+");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method05(){ // ?
        String str = "aaaaaababababababa";
        Pattern compile = Pattern.compile("a?");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method06(){ // *
        String str = "aaaaaababababababa";
        Pattern compile = Pattern.compile("a*");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }
}
