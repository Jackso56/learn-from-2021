package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 元字符之选择匹配符：| 匹配其前后其中之一的字符
 *
 **/
@SuppressWarnings({"all"})
public class RegExp05 {

    @Test
    public void method01(){
        String str = "abcdefgab";
        Pattern compile = Pattern.compile("ab|cd");
        Matcher matcher = compile.matcher(str);
        while (matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }
}
