package com.linmu.regularexception_.basicgrammar;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 特别分组：(?:pattern),(?!pattern),(?=pattern)
 **/
@SuppressWarnings({"all"})
public class RegExp09 {

    @Test
    public void method01(){
        // (?:pattern) ==> "林沐(?:大师兄|小师弟)" ==> "林沐(大师兄|小师弟)"
        String str = "林沐大师兄 林沐小师弟 林沐祖师爷";
        Pattern compile = Pattern.compile("林沐(?:大师兄|小师弟)");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method02(){
        // (?!pattern) ==> "林沐(?!:大师兄|小师弟)" ==> 不在"林沐(大师兄|小师弟)" 中的 "林沐"
        String str = "林沐大师兄 林沐小师弟 林沐祖师爷";
        Pattern compile = Pattern.compile("林沐(?!大师兄|小师弟)");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method03(){
        // (?=pattern) ==> "林沐(?=大师兄|小师弟)" ==>"林沐(大师兄|小师弟)" 中的 "林沐"
        String str = "林沐大师兄 林沐小师弟 林沐祖师爷";
        Pattern compile = Pattern.compile("林沐(?=大师兄|小师弟)");
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }
}
