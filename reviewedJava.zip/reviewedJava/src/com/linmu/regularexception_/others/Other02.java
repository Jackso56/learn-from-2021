package com.linmu.regularexception_.others;


import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * String类中的正则表达式：matches(reg),split(reg)
 **/
@SuppressWarnings({"all"})
public class Other02 {

   @Test
    public void method01(){ // matches()匹配：按正则表达式匹配
       String str = "19957045572";
       String str1 = "19457045572";
       boolean matches = str.matches("19(?:9|8)\\d{8}");
       boolean matches01 = str1.matches("19(?:9|8)\\d{8}");
       System.out.println("是否匹配成功：" + matches + " " + matches01);
   }

   @Test
    public void method02(){ // split()匹配:按分隔符分割
       String str = "hello,jackson.My@name#is jack'now";
//       语法比较严格
       String[] split = str.split("@|#|\\.|,|\\'");
       for (String s : split) {
           System.out.print(s + " ");
       }
   }
}
