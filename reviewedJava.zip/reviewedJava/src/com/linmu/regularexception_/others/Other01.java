package com.linmu.regularexception_.others;

import org.testng.annotations.Test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 反向引用：
 * 1）内部引用：\\组号   从左往右：1,2,3……
 * 2）外部引用：$组号  从左往右：1,2,3……
 **/
@SuppressWarnings({"all"})
public class Other01 {

    @Test
    public void method01(){ // 内部引用
        String str = "1221 3443 5656 7887";
        String reg = "(\\d)(\\d)\\2\\1";
        Pattern compile = Pattern.compile(reg);
        Matcher matcher = compile.matcher(str);
        while(matcher.find()){
            System.out.println("找到：" + matcher.group(0));
        }
    }

    @Test
    public void method02(){ // 外部引用
        String str = "1221 3443 5656 7887";
        String reg = "(\\d)\\1+";
//        替换重复
        String replaceAll = Pattern.compile(reg).matcher(str).replaceAll("$1");
        System.out.println("找到：" + replaceAll);
    }

}
