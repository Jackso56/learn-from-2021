package com.linmu.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// using transaction:setAutoCommit(),commit(),rollback()

@SuppressWarnings({"all"})
public class Transaction_ {

    public static void main(String[] args) {
        transaction();
    }

    // use transaction
    public static void transaction() {

        Connection connection = null;
        String sql = "update account set balance=balance-100 where id=3";
        String sql2 = "update account set balance=balance+100 where id=4";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = JdbcUtils.getConnection();
            // 关闭自动提交事务,开启事务
            connection.setAutoCommit(false);
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeUpdate();
            // throw Exception
            int i = 2 / 0;
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate();
            // 提交事务
            connection.commit();
        } catch (Exception e) {
            // 事务回滚
            try {
                connection.rollback();
            } catch (SQLException sq) {
                sq.printStackTrace();
            }
            e.printStackTrace();
        }

        try {
            JdbcUtils.closeConnections(preparedStatement, connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // unuseing transaction
    public static void untransaction() {

        Connection connection = null;
        String sql = "update account set balance=balance-100 where id=3";
        String sql2 = "update account set balance=balance+100 where id=4";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = JdbcUtils.getConnection();
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.executeUpdate();
            // throw Exception
            int i = 2 / 0;
            preparedStatement = connection.prepareStatement(sql2);
            preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            JdbcUtils.closeConnections(preparedStatement, connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
