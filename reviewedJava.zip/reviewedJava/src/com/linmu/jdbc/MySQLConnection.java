package com.linmu.jdbc;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;


@SuppressWarnings({"all"})
public class MySQLConnection {

    // 连接数据库方式一
    @Test
    public static void connectMySQL1() throws Exception{
        // 反射方式完成Driver的注册驱动
        // 自动完成Driver的注册驱动,可以不写，建议写上，可能有不同的驱动
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/jdbcuse";
        String user = "root";
        String passwd = "000000";
        // 创建SQL连接
        Connection connection = DriverManager.getConnection(url, user, passwd);
        System.out.println("datsbase conection is successfully..." + connection);
    }

    // 连接数据库方式二（利用Perproties文件：使连接更加灵活）
    @Test
    public static void connectMySQL2() throws Exception{
        // 加载配置文件,要写绝对路径
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\com\\linmu\\jdbc\\sql.properties"));
        // 获取相关值
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");
        String user = properties.getProperty("user");
        String passwd = properties.getProperty("passwd");
        // 加载注册驱动
        Class.forName(driver);
        // 创建SQL连接
        Connection connection = DriverManager.getConnection(url, user, passwd);
        System.out.println("datsbase conection is successfully..." + connection);
    }

}
