package com.linmu.jdbc.datasource;

import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// 手写Druid工具类;需要创建一个类,用对象接收结果集(可以将数据集返回)

@SuppressWarnings({"all"})
public class DruidUtilsOfMine {

    @Test
    public static void Test() throws Exception{
        Connection connection = JdbcUtilsDruid.getConnection();
        String sql = "select * from result where studentresult>?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, 70);
        preparedStatement.executeQuery();
        ResultSet resultSet = preparedStatement.getResultSet();
        List<SqlData> data = new ArrayList<>();
        while (resultSet.next()){
            int id = resultSet.getInt("id");
            float result = resultSet.getFloat("studentresult");
            data.add(new SqlData(id, result));
        }
        JdbcUtilsDruid.closeConnection(resultSet, preparedStatement, connection);
        System.out.println("data数据=" + data);
    }

}

