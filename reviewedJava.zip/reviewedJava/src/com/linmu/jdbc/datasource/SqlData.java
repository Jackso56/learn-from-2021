package com.linmu.jdbc.datasource;

import java.time.LocalDateTime;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
public class SqlData {
    private int id;
    private float studentResult;
    private String studentNo;
    private int subjectId;
    private LocalDateTime examDate;

    public SqlData(int id, float studentResult, String studentNo, int subjectId, LocalDateTime examDate) {
        this.id = id;
        this.studentResult = studentResult;
        this.studentNo = studentNo;
        this.subjectId = subjectId;
        this.examDate = examDate;
    }

    public SqlData(int id, float studentResult) {
        this.id = id;
        this.studentResult = studentResult;
    }

    public SqlData() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getStudentResult() {
        return studentResult;
    }

    public void setStudentResult(float studentResult) {
        this.studentResult = studentResult;
    }

    public String getStudentNo() {
        return studentNo;
    }

    public void setStudentNo(String studentNo) {
        this.studentNo = studentNo;
    }

    public int getSubjectId() {
        return subjectId;
    }

    public void setSubjectId(int subjectId) {
        this.subjectId = subjectId;
    }

    public LocalDateTime getExamDate() {
        return examDate;
    }

    public void setExamDate(LocalDateTime examDate) {
        this.examDate = examDate;
    }

    @Override
    public String toString() {
        return "sqlData{" +
                "id=" + id +
                ", studentResult=" + studentResult +
                ", studentNo='" + studentNo + '\'' +
                ", subjectId=" + subjectId +
                ", examDate=" + examDate +
                '}';
    }
}
