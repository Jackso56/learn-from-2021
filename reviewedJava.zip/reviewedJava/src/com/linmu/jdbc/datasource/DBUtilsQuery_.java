package com.linmu.jdbc.datasource;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.util.List;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// 德鲁伊工具类(需要手动创建数据表映射类)： select语句   结果据复用性
// druid的映射类使用无参构造器

@SuppressWarnings({"all"})
public class DBUtilsQuery_ {

    // 返回多行数据,reutnrn ArrayList
    @Test
    public void beanListHander() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        // 创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from result where studentresult>?";
        // 运行sql,数据分装到ArrayList中去,其底层会关闭resultSet,preparedConnection
        List<SqlData> data= queryRunner.query(
                connection, sql, new BeanListHandler<>(SqlData.class), 70.0);
        for (SqlData datum : data) {
            System.out.println(datum);
        }
        JdbcUtilsDruid.closeConnection(connection);
    }

    // 返回单行数据,return AutoClass
    @Test
    public void beanHandler() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        // 创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from result where id=?";
        // 运行sql,数据分装到ArrayList中去,其底层会关闭resultSet,preparedConnection
        SqlData data = queryRunner.query(
                connection, sql, new BeanHandler<>(SqlData.class), 10);
        System.out.println(data);
        JdbcUtilsDruid.closeConnection(connection);
    }

    // 返回单行单列数据,return Object
    @Test
    public void scalarHandler() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        // 创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select studentresult from result where id=?";
        // 运行sql,数据分装到ArrayList中去,其底层会关闭resultSet,preparedConnection
        Object data = queryRunner.query(connection, sql, new ScalarHandler(), 10);
        System.out.println(data);
        JdbcUtilsDruid.closeConnection(connection);
    }

}
