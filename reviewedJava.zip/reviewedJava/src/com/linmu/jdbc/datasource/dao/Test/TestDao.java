package com.linmu.jdbc.datasource.dao.Test;

import com.linmu.jdbc.datasource.dao.class_.Result;
import com.linmu.jdbc.datasource.dao.classdao.ResultDao;
import org.testng.annotations.Test;

import java.util.List;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class TestDao {

    @Test
    public static void beanListHandler(){
        ResultDao resultDao = new ResultDao();
        String sql = "select * from result where id>=?";
        List<Result> list = resultDao.beanListHandler(sql, Result.class, 10);
        for (Result result : list) {
            System.out.println(result);
        }
    }

    @Test
    public static void beanHandler() throws RuntimeException{
        ResultDao resultDao = new ResultDao();
        String sql = "select id,examdate from result where id=?";
        Object o = resultDao.beanHandler(sql, Result.class, 10);
        System.out.println(o);
    }

    @Test
    public static void scalarHandler(){
        ResultDao resultDao = new ResultDao();
        String sql = "select studentresult from result where id=?";
        Object ob = resultDao.scalarHandler(sql, Result.class, 10);
        System.out.println(ob);
    }

}


