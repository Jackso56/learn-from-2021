package com.linmu.jdbc.datasource.dao.classdao;

import com.linmu.jdbc.datasource.dao.basicdao.BasicDAO;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class ResultDao extends BasicDAO {

    // 可以根据业务需求增加业务代码

}
