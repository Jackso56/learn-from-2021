package com.linmu.jdbc.datasource.dao.basicdao;

import com.linmu.jdbc.datasource.JdbcUtilsDruid;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import java.sql.Connection;
import java.util.List;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class BasicDAO<T> { // 指定泛型传参

    private QueryRunner queryRunner = new QueryRunner();

    // 执行dml,可针对任意表
    public int update(String sql, Object... parameters){
        Connection connection = null;
        try {
            connection = JdbcUtilsDruid.getConnection();
            return queryRunner.update(connection, sql, parameters);
        } catch (Exception e){
            throw new RuntimeException(e);
        } finally {
            JdbcUtilsDruid.closeConnection(connection);
        }
    }

    /**
     *
     * @param sql
     * @param class_ 类的Class对象, 例如：result.class
     * @param parameter
     * @return
     */
    // 返回多行多列数据
    public List<T> beanListHandler(String sql, Class<T> class_, Object... parameter){
        Connection connection = null;
        try {
            JdbcUtilsDruid.getConnection();
            return queryRunner.query(connection, sql, new BeanListHandler<T>(class_), parameter);
        } catch (Exception e){
            throw new RuntimeException(e);
        } finally {
            JdbcUtilsDruid.closeConnection(connection);
        }
    }

    // 返回单行多列数据
    public T beanHandler(String sql, Class<T> class_, Object... parameter){
       Connection connection = null;
       try {
           JdbcUtilsDruid.getConnection();
           return queryRunner.query(connection, sql, new BeanHandler<T>(class_), parameter);
       } catch (Exception e){
           throw new RuntimeException(e);
       } finally {
           JdbcUtilsDruid.closeConnection(connection);
       }
    }

    // 返回单行单列数据
    public Object scalarHandler(String sql, Class<T> class_, Object... parameter){
        Connection connection = null;
        try {
            connection = JdbcUtilsDruid.getConnection();
            return queryRunner.query(connection, sql, new ScalarHandler<T>(), parameter);
        } catch (Exception e){
            throw new RuntimeException(e);
        } finally {
            JdbcUtilsDruid.closeConnection(connection);
        }
    }

}
