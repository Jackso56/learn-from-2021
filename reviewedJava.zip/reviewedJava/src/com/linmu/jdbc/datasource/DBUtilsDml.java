package com.linmu.jdbc.datasource;

import org.apache.commons.dbutils.QueryRunner;
import org.testng.annotations.Test;

import java.sql.Connection;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// DBUtils使用update方法执行dml语句

@SuppressWarnings({"all"})
public class DBUtilsDml {

    // update data
    @Test
    public void update_() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        String sql = "update result set studentresult=100 where id=?";
        int affectedRows = queryRunner.update(connection, sql, 10);
        System.out.println(affectedRows > 0 ? "successful..." : "failure...");
        JdbcUtilsDruid.closeConnection(connection);
    }

    // insert data
    @Test
    public void insert_() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        String sql = "insert into account values(?,?)";
        int affectedRows = queryRunner.update(connection, sql, 50, 90000);
        System.out.println(affectedRows > 0 ? "successful..." : "failure...");
        JdbcUtilsDruid.closeConnection(connection);
    }

    // delete data
    @Test
    public void delete_() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        QueryRunner queryRunner = new QueryRunner();
        String sql = "delete from account where id<?";
        int affectedRows = queryRunner.update(connection, sql, 50);
        System.out.println(affectedRows > 0 ? "successful..." : "failure...");
        JdbcUtilsDruid.closeConnection(connection);
    }
}
