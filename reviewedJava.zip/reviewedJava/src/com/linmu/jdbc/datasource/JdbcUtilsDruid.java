package com.linmu.jdbc.datasource;

import com.alibaba.druid.pool.DruidDataSourceFactory;


import javax.sql.DataSource;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class JdbcUtilsDruid {

    private static DataSource ds;

    static {
        Properties properties = new Properties();
        try {
            properties.load(new FileInputStream("src\\com\\linmu\\jdbc\\datasource\\druid.properties"));
            ds = DruidDataSourceFactory.createDataSource(properties);
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    // 获取连接
    public static Connection getConnection() throws Exception{
        return ds.getConnection();
    }

    // 将连接放回连接池
    public static void closeConnection(ResultSet resultSet, Statement statement, Connection connection){
        try {
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // 将连接放回连接池
    public static void closeConnection(Statement statement, Connection connection){
        try {
            statement.close();
            connection.close();
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // 将连接放回连接池
    public static void closeConnection(Connection connection){
        try {
            connection.close();
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}
