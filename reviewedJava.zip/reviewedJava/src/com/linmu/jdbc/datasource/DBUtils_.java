package com.linmu.jdbc.datasource;


import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.util.List;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class DBUtils_ {

    @Test
    public void dbUtils() throws Exception {
        Connection connection = JdbcUtilsDruid.getConnection();
        // 创建 QueryRunner
        QueryRunner queryRunner = new QueryRunner();
        String sql = "select * from result where studentresult>?";
        // 运行sql,数据分装到ArrayList中去,其底层会关闭resultSet,preparedConnection
        List<SqlData> data= queryRunner.query(connection, sql, new BeanListHandler<>(SqlData.class), 70);
        for (SqlData datum : data) {
            System.out.println(datum);
        }
        JdbcUtilsDruid.closeConnection(connection);
    }

}
