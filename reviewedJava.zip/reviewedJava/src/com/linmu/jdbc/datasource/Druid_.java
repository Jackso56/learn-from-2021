package com.linmu.jdbc.datasource;


import com.alibaba.druid.pool.DruidDataSourceFactory;
import org.testng.annotations.Test;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Properties;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// 德鲁伊连接池

@SuppressWarnings({"all"})
public class Druid_ {

    @Test
    public void druid_() throws Exception{
        Properties properties = new Properties();
        properties.load(new FileInputStream(
                "src\\com\\linmu\\jdbc\\datasource\\druid.properties"));
        // 创建连接池
        DataSource dataSource = DruidDataSourceFactory.createDataSource(properties);
        long start = System.currentTimeMillis();
        for (int i = 0; i < 500000; i++) {
            // 获取连接
            Connection connection = dataSource.getConnection();
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("druid连接池500000连接耗时：" + (end - start));
    }

}
