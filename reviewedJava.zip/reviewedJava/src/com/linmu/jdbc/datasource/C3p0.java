package com.linmu.jdbc.datasource;


import com.mchange.v2.c3p0.ComboPooledDataSource;
import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.util.Properties;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// c3p0连接池

@SuppressWarnings({"all"})
public class C3p0 {

    // 连接方式一：手动配置相关信息
    @Test
    public void getConnection() throws Exception{
        // 创建ComboPooledDataSource对象,即连接池
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource();
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\com\\linmu\\jdbc\\sql.properties"));
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");
        String user = properties.getProperty("user");
        String passwd = properties.getProperty("passwd");
        // 设置连接参数
        comboPooledDataSource.setDriverClass(driver);
        comboPooledDataSource.setJdbcUrl(url);
        comboPooledDataSource.setUser(user);
        comboPooledDataSource.setPassword(passwd);
        // 设置初始化连接数
        // initial   英 [ɪˈnɪʃ(ə)l]  美 [ɪˈnɪʃ(ə)l]
        comboPooledDataSource.setInitialPoolSize(100);
        // 设置最大连接数
        comboPooledDataSource.setMaxPoolSize(500);
        // 获取连接   milli 毫，千分之一
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            Connection connection = comboPooledDataSource.getConnection();
            // System.out.println("successfully...");
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("连接耗时：" + (end - start));
    }

    //  方式二：通过配置文件配置相关信息
    @Test
    public void getConnectionAuto() throws Exception{
        // 传入配置文件,创建ComboPooledDataSource对象,即连接池
        // config  英 [kənˈfɪɡ]  美 [kənˈfɪɡ]  n. 配置，布局；显示配置信息命令
        ComboPooledDataSource comboPooledDataSource = new ComboPooledDataSource(
                "c3p0-config.xml");
        long start = System.currentTimeMillis();
        for (int i = 0; i < 500000; i++) {
            // 创建连接
            Connection connection = comboPooledDataSource.getConnection();
            connection.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("c3p0连接池500000次连接耗时：" + (end - start));
    }

}
