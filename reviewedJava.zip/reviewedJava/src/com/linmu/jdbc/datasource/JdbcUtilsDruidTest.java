package com.linmu.jdbc.datasource;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

@SuppressWarnings({"all"})
public class JdbcUtilsDruidTest {

    public static void main(String[] args) throws Exception{
        Test();
    }

    public static void Test() throws Exception{
        Connection connection = JdbcUtilsDruid.getConnection();
        String sql = "select id,studentresult from result where studentresult>?";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setInt(1, 70);
        preparedStatement.executeQuery();
        ResultSet resultSet = preparedStatement.getResultSet();
        while (resultSet.next()){
            int id = resultSet.getInt("id");
            float result = resultSet.getFloat("studentresult");
            System.out.println(id + "\t" + result);
        }
        JdbcUtilsDruid.closeConnection(resultSet, preparedStatement, connection);
    }

}
