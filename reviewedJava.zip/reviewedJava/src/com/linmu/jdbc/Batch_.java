package com.linmu.jdbc;

import com.sun.javaws.jnl.RContentDesc;
import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.PreparedStatement;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// 批处理

@SuppressWarnings({"all"})
public class Batch_ {

    // unBatch
    @Test
    public static void nuBatch() throws Exception {
        Connection connection = JdbcUtils.getConnection();
        String sql = "insert into acc values(null,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            preparedStatement.setString(1, "linmu" + i);
            preparedStatement.setString(2, "123" + i);
            preparedStatement.executeUpdate();
        }
        long end = System.currentTimeMillis();
        // 运行时间：5803
        System.out.println("运行时间：" + (end - start));
        JdbcUtils.closeConnections(preparedStatement, connection);
    }

    // Batch:url中需要添加后缀  ?rewriteBatchedStatements=true
    @Test
    public static void Batch() throws Exception {
        Connection connection = JdbcUtils.getConnection();
        String sql = "insert into acc values(null,?,?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        long start = System.currentTimeMillis();
        for (int i = 0; i < 5000; i++) {
            preparedStatement.setString(1, "linmu" + i);
            preparedStatement.setString(2, "123" + i);
            preparedStatement.addBatch();
            if ((i + 1) % 1000 == 0){
                preparedStatement.executeBatch();
            }
        }
        long end = System.currentTimeMillis();
        System.out.println("运行时间：" + (end - start));
        JdbcUtils.closeConnections(preparedStatement, connection);
    }

}
