package com.linmu.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class JdbcUtilsTest {

    public static void main(String[] args) throws Exception {
        forTest();
    }

    public static void forTest() {

        Connection connection = null;
        // 编写SQL语句
        String sql = "select studentno,studentresult from result where studentresult>?";
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // 创建连接
            connection = JdbcUtils.getConnection();
            // 创建preparedstatement
            preparedStatement = connection.prepareStatement(sql);
            // 设置SQL语句参数
            preparedStatement.setInt(1, 70);
            // 执行SQL语句
            resultSet = preparedStatement.executeQuery();
            // 输出查询结果
            while (resultSet.next()) {
                String studentNo = resultSet.getString("studentno");
                float studentResult = resultSet.getFloat("studentresult");
                System.out.println(studentNo + "\t" + studentResult);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // 关闭资源
        try {
            JdbcUtils.closeConnections(resultSet, preparedStatement, connection);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
