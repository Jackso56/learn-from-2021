package com.linmu.jdbc;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

import org.testng.annotations.Test;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

@SuppressWarnings({"all"})
public class ResultSet_ {

    // resultset：取数据(select语句的结果集)  next(),get...()
    @Test
    public static void resultSet() throws Exception {
        Properties properties = new Properties();
        properties.load(new FileInputStream("src\\com\\linmu\\jdbc\\sql.properties"));
        String driver = properties.getProperty("driver");
        String url = properties.getProperty("url");
        String user = properties.getProperty("user");
        String passwd = properties.getProperty("passwd");
        Connection connection = DriverManager.getConnection(url, user, passwd);
        // 创建statement,执行SQL语句
        Statement statement = connection.createStatement();
        String sql = "SELECT studentno,subjectid,studentresult FROM result WHERE studentresult > 70";
        // resultSet类似于指针取数据
        ResultSet resultSet = statement.executeQuery(sql);
        // while 取数据
        while(resultSet.next()){
            // 获取数据
            String studentNo = resultSet.getString(1);
            int subjectId = resultSet.getInt(2);
            float result = resultSet.getFloat(3);
            System.out.println(studentNo + "\t" + subjectId + "\t" + result);
        }
        // 关闭连接
        resultSet.close();
        statement.close();
        resultSet.close();
    }

}
