package com.linmu.jdbc;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// 将加载驱动,创建连接,关闭连接封装成工具类,减少代码冗余

@SuppressWarnings({"all"})
public class JdbcUtils {

    private static String driver;
    private static String url;
    private static String user;
    private static String passwd;

    static {
        Properties properties = new Properties();
        //在实际开发中，我们可以这样处理,将编译异常转换为运行异常
        //1.将编译异常转成运行异常，比较方便。
        //2.这时调用者，可以选择捕获该异常，也可以选择默认处理该异
        try{
            properties.load(new FileInputStream("src\\com\\linmu\\jdbc\\batch.properties"));
            driver = properties.getProperty("driver");
            url = properties.getProperty("url");
            user = properties.getProperty("user");
            passwd = properties.getProperty("passwd");
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // connection database
    public static Connection getConnection(){
        //在实际开发中，我们可以这样处理,将编译异常转换为运行异常
        //1.将编译异常转成运行异常，比较方便。
        //2.这时调用者，可以选择捕获该异常，也可以选择默认处理该异
        try{
            return DriverManager.getConnection(url, user, passwd);
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // close connections set overloading
    public static void closeConnections(ResultSet resultSet, Statement statement, Connection connection){
        //在实际开发中，我们可以这样处理,将编译异常转换为运行异常
        //1.将编译异常转成运行异常，比较方便。
        //2.这时调用者，可以选择捕获该异常，也可以选择默认处理该异
        try{
            resultSet.close();
            statement.close();
            connection.close();
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // close connections set overloading
    public static void closeConnections(Statement statement, Connection connection){
        //在实际开发中，我们可以这样处理,将编译异常转换为运行异常
        //1.将编译异常转成运行异常，比较方便。
        //2.这时调用者，可以选择捕获该异常，也可以选择默认处理该异
        try{
            statement.close();
            connection.close();
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

    // close connections set overloading
    public static void closeConnections(Connection connection){
        //在实际开发中，我们可以这样处理,将编译异常转换为运行异常
        //1.将编译异常转成运行异常，比较方便。
        //2.这时调用者，可以选择捕获该异常，也可以选择默认处理该异
        try{
            connection.close();
        } catch (Exception e){
            throw new RuntimeException(e);
        }
    }

}
