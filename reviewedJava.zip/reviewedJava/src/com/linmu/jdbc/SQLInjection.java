package com.linmu.jdbc;

import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

 /*
    SQL注入：利用系统没有堆用户输入数据的充分检查，向用户输入的
            数据中注入非法的SQL语句断或命令，恶意攻击数据库
            username=1' or   passwd=or '1'='1(万能密码)
    三种statement接口：Statement[存在sql注入问题，实际开发中不使用],
                  PreparedStatement[预处理，实际开发中使用的Statement],
                  CallableStatement[存储过程];
     PrepareedStatement接口：1)执行的SQL语句中的参数可以用 ？ 来表示,通过调用
                              setXxxx(int index, <...> value)方法来设置参数,索引从1开始
                             2)调用executeQuery()方法,创建ResultSet对象  --> 返回ResultSet结果集
                             3)调用executeUpdate()方法,执行更新操作,包括增加,删除,修改  -->返回影响行数
     PreparedStatement[接口]预处理优势：1)不再使用+拼接SQL语句,减少语法错误
                                     2)有效解决了SQL注入问题
                                     3)大大减少编译次数,效率较高
 */

@SuppressWarnings({"all"})
public class SQLInjection {

    // PreparedStatement执行select语句：executeQuery()
    @Test
    public static void executeQuery_() throws Exception {
        // 创建注册驱动
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/schooldb";
        String user = "root";
        String passwd = "000000";
        // 创建连接
        Connection connection = DriverManager.getConnection(url, user, passwd);
        // 编写SQL语句
        String sql = "SELECT studentno,subjectid,studentresult FROM result WHERE studentresult>? ";
        // 创建PreparedStatement操作SQL语句
        PreparedStatement preSt = connection.prepareStatement(sql);
        // 设置SQL语句的参数
        preSt.setInt(1, 70);
        // 创建结果集，取数据
        ResultSet resultSet = preSt.executeQuery();
        while (resultSet.next()) {
            String studentNo = resultSet.getString(1);
            int subjectId = resultSet.getInt(2);
            int result = resultSet.getInt(3);
            System.out.println(studentNo + "\t" + subjectId + "\t" + result);
        }
        // 关闭连接
        resultSet.close();
        preSt.close();
        connection.close();
    }

    // PreparedStatement执行dml语句：executeUpdate()
    @Test
    public static void executeUpdate_() throws Exception{
        // 创建注册驱动
        Class.forName("com.mysql.cj.jdbc.Driver");
        String url = "jdbc:mysql://localhost:3306/schooldb";
        String user = "root";
        String passwd = "000000";
        // 创建连接
        Connection connection = DriverManager.getConnection(url, user, passwd);
        // 编写SQL语句
        // 增加数据
//        String sql = "insert into grade values(?, ?)";
        // 更新数据
//        String sql = "update grade set gradeid=? where gradename=? ";
        // 删除数据
        String sql = "delete from grade where gradeid=?";
        // 创建preparedStatement,需要存入SQL语句
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        // 设置SQL语句的参数
        preparedStatement.setInt(1, 8);
//        preparedStatement.setString(2, "s7");
        // 执行SQL语句
        int result = preparedStatement.executeUpdate();
        System.out.println(result > 0 ? "successfully..." : "failed...");
        // 关闭连接
        preparedStatement.close();
        connection.close();
    }

}
