package com.linmu.enum_;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * eunm关键字枚举类：
 * 1）enum代替class
 * 2）枚举类放在类体的最前面
 * 3）多个枚举类，用逗号分割，末尾用分号
 *
 * enum关键字枚举对象常用方法：name,ordinal,values,valuesOf,compareTo,equals,hashCode
 **/
@SuppressWarnings({"all"})
public class Enum_02 {

    @Test
    public void method01(){
        System.out.println("季节信息：" + Seasons.SPRING.ordinal());
        System.out.println("季节信息：" + Seasons.SUMMER);
        System.out.println("季节信息：" + Seasons.AUTUMN);
        System.out.println("季节信息：" + Seasons.WINTER);
        System.out.println("季节信息：" + Seasons.SER.ordinal());
    }

    @Test
    public void method02(){
//        返回枚举对象名称
        System.out.println("枚举对象名称：" + Seasons.SPRING.name());
//        返回枚举对象序号，序号从0开始
        System.out.println("枚举对象序号：" + Seasons.SPRING.ordinal());
//        返回数组
        System.out.println("枚举对象数组：" + Seasons.values());
//        字符串转枚举对象：前提是该枚举对象已经存在
        System.out.println("字符串转枚举对象:" + Seasons.valueOf("SPRING"));
//        返回编号差值
        System.out.println("返回编号差值:" + Seasons.SPRING.compareTo(Seasons.AUTUMN));
//        枚举对象比较
        System.out.println("枚举对象比较:" + Seasons.SUMMER.equals(Seasons.SUMMER));
//        返回hash值
        System.out.println("枚举对象的hash值：" + Seasons.AUTUMN.hashCode());
    }
}
enum Seasons{
    SPRING("spring"),
    SUMMER("summer"),
    AUTUMN("autumn"),
    WINTER("winter"),
    SER();


    private String name;

    private Seasons(){

    }
    private Seasons(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Seasons{" +
                "name='" + name + '\'' +
                '}';
    }


}