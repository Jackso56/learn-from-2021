package com.linmu.enum_;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 枚举类简介：是一组常量集合，是一种特殊的类，里面包含了有限特定对象
 * 枚举方式：自定义枚举，enum关键字枚举
 * 自定义枚举：
 * 1）构造器私有化，防止用户创建对象
 * 2）去除set方法，因为枚举对象通常只读
 * 3）创建枚举对象（public static final），大写字母命名
 * 4）枚举对象根据需求，可以有多个属性
 * 5）也可以用无参构造器
 *
 **/
@SuppressWarnings({"all"})
public class Enum_01 {
    @Test
    public void method01(){
        System.out.println("季节信息：" + Season.AUTUMN.toString());
        System.out.println("季节信息：" + Season.SPRING.toString());
        System.out.println("季节信息：" + Season.SUMMER.toString());
        System.out.println("季节信息：" + Season.WINTER.toString());
        System.out.println("季节信息：" + Season.SER.toString());
    }
}
class Season{
    public static final Season SPRING = new Season("Spring");
    public static final Season SUMMER = new Season("Summer");
    public static final Season AUTUMN = new Season("Autumn");
    public static final Season WINTER = new Season("Winter");
    public static final Season SER = new Season();
    private String name;

    private Season(){}

    private Season(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Season{" +
                "name='" + name + '\'' +
                '}';
    }
}