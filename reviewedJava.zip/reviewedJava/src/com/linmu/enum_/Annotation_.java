package com.linmu.enum_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 注解（Annotation）：
 * 1.@Override：限定某个方法，是重写父类方法，该注解只能用于方法
 *              @interface是一个注解类
 *              @Target(ElementType.METHOD)
 *              @Retention(RetentionPolicy.SOURCE)
 *              public @interface Override {
 *              }
 * 2.@Deprecated：表示某个程序元素（类、方法等）已经过时
 *      1)表示不推荐使用，但仍然可以使用
 *      2)可以修饰方法、类、字段、包、参数等等
 *      3)可以做版本升级的过渡使用
 * 3.@SuppressWarnings：抑制编译器警告
 *      1)放在方法和类中，用于忽略警告  一般放在具体的语句、方法、类的前面
 *          @SuppressWarnings({"all"}) 需要传入忽略的具体的警告类型关键字
 *
 *
 *  元注解：
 *  @Target：指定注解应用范围
 * 简介：用于修饰Annotation定义，用于指定被修饰的Annotation能用于修饰那些程序元素，
 *       @Target也包含一个名为value的成员变量，可以同时指定多个这样的成员变量
 * @Rentention的三种值：指定注解作用范围
 *     1.RententionPolicy.SOURCE：编译器使用后，直接丢弃
 *     2.RententionPolicy.CLASS：编译器将注释记录在class文件中，运行java程序时，JVM不会保留注释
 *     3.RententionPolicy.RUNTIME编译器将注释记录在class文件中，运行java程序时，JVM会保留注释，
 *      程序可以通过反射获取注释
 * @Documented
 * 简介： 被修饰的注解类将被javadoc工具提取成文档，即在生成文档时可以看到该注解
 *        其中定义为Documented的注解必须设置Retention值为RUBTIME
 * @Inherited
 * 简介：被它修饰的Annotation将具有继承性，如果某个类使用了被@Inherited修饰的Annotation，则其子类将自动具有该注解
 **/
@SuppressWarnings({"all"})
public class Annotation_ {

}
