package com.linmu.Exception_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

import java.util.Scanner;

/***
 * 异常简介：
 * 程序执行的过程中发生的不正常的情况（其中语法错误和逻辑错误不是异常）
 * 执行过程中的异常分为两大类：
 * 1.Error（错误）：JVM虚拟机无法解决的严重问题。例如：JVM系统内部错误、资源耗尽。
 *      比如：Stack OverflowError（栈溢出）和OOM（out of memory），Error是严重错误，程序会崩溃
 * 2.Exception：其他因编程错误或偶然的外在因素导致的一般性问题，可以使用针对性的代码进行处理。
 *      例如：空指针访问，试图读取不存在的文件，网络连接中断等等，Exception分为两大类：
         * 1)运行时异常（程序运行时，发生的异常）
         * 2)编译时异常（编程时，编译器检查出的异常）
 *
 * 小结：
 * 1.异常分为两大类，运行时异常和编译时异常
 * 2.运行时异常，编译器检查不出来。一般指编程时的逻辑错误，是程序员应该避免其出现的异常。
 *      Java.lang.RuntimeException类及它的子类都是运行时异常
 * 3.对于运行时的异常，可以不做处理，因为在这类异常很普遍，若全处理可能会对程序的可读性和运行效率产生影响
 * 4.编译时异常，是编译器要求必须处理的异常
 *
 * 常见的异常：
     * 运行异常（RuntimeException）：在运行过程中出现的异常
         * 1.NullPointerException空指针异常，当应用程序在需要使用对象的地方使用NULL时，抛出异常
         * 2.ArithmeticException算数异常，当运算条件异常时抛出异常
         * 3.ArrayIndexOutOfBoundsException数组下标越界，索引序号超出数组编号
         * 4.ClassCastException类型转换异常，试图将对象强转换为不是实例的子类时抛出异常
         * 5.NumberFormatException数字格式不正确异常，试图将字符串转换为数字，当字符串格式不正确
     * 编译异常（Exception）：在编译过程中必须处理的异常，否则就不能通过编译
         * 1.SQLException数据库操作异常
         * 2.IOException文件操作异常
         * 3.FileNotFoundException文件不存在异常
         * 4.ClassNotFoundException类不存在异常
         * 5.EOFException文件操作异常
         * 6.IIIegalArguentException参数异常
 *
 *
 * 异常处理分类
 * 异常处理的方式：
     * 1.try-catch-finally：程序员在代码中捕获发生的异常，自行处理
     * 2.throws：将发生的异常抛出，交给调用者（方法）来处理，JVM是最顶级的处理者
 *
 * 自定义异常：一般继承RuntimeException，一般使用有参构造器
 *
 * throw和throws的对比
 * 	                意义	                 位置	          后面跟的参数
 * throws	异常处理的一种方式	         方法的后面	            异常类型
 * throw	手动生成异常对象的关键字	 在方法体内	            异常对象
 *
 * 方法：getmassage(),printStackTrace()
 */

@SuppressWarnings({"all"})
public class Exception_01 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        if(number == 0){
            throw new NumberException("数据异常");
        }
        System.out.println("number=" + number);
    }
}

// 自定义异常:一般继承RuntimeException，一般使用有参构造器
class NumberException extends RuntimeException{
    public NumberException(String message) {
        super(message);
    }

    @Override
    public void printStackTrace() {
        super.printStackTrace();
    }
}
