package com.linmu.networkingprogramming_.tcpprogramming;

import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class TCPserver_01 {

    @Test
    public void method01() throws IOException {
//        创建Socket对象：端口号
        ServerSocket serverSocket = new ServerSocket(8887);
//        监听服务
        System.out.println("监听请求中...");
        Socket accept = serverSocket.accept();
//        获取数据流对象，获取数据通道中的数据
        InputStream inputStream = accept.getInputStream();
        byte[] bytes = new byte[1024];
        int length = 0;
        while((length = inputStream.read(bytes)) != -1){
            System.out.println(new String(bytes,0,length));
        }
//        关闭资源
        inputStream.close();
        accept.close();
        serverSocket.close();
    }
}
