package com.linmu.networkingprogramming_.tcpprogramming;


import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 端口号：0~65535，其中0~1024以经被占用，不可用
 * TCP协议：传输控制协议
 * 1）使用TCP协议之前，必须建立TCP连接，形成数据传输通道
 * 2）传输前，采用三次握手的方式，是可靠的
 * 3）TCP协议进行通信的两个应用进程：客户端、服务端
 * 4）在连接时可进行大数据的传输
 * 5）传输完毕后，需要释放已建立的连接，效率低下
 **/
@SuppressWarnings({"all"})
public class TCPserver_ {

    @Test
    public void method01() throws IOException {
        // 1）创建服务器，并给定端口，等待连接
        //        细节1：没有其他服务在使用的端口号监听
        //        细节2：serverSocket可以通过accept返回多个socket对象[多个客户端连接一个服务器：并发编程]
        ServerSocket serverSocket = new ServerSocket(8888);
        System.out.println("服务器端8888号端口等待连接...");
        // 2）当没有客户端连接8888端口号时，程序会阻塞；
        // 当有客户端连接时，则会返回Socket对象，程序继续
        Socket socket = serverSocket.accept();
        System.out.println("服务端 socket运行类型：" + socket.getClass());
//        3）通过socket.getInputStream()读取客户端写入到数据通道的数据
        InputStream inputStream = socket.getInputStream();
        byte[] bytes = new byte[1024];
        int readlen = 0;
        while ((readlen = inputStream.read(bytes)) != -1){
            System.out.println(new String(bytes,0,readlen));
        }
        // 4）关闭流和socket
        inputStream.close();
        socket.close();
        serverSocket.close();
        System.out.println("服务端关闭...");
    }
}
















































