package com.linmu.networkingprogramming_.tcpprogramming;

import org.testng.annotations.Test;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class TCPclient_ {

    @Test
    public void method01() throws IOException {
        // 1）连接服务器：服务器主机+端口号
        // 连接成功会返回socket对象
        Socket socket = new Socket(InetAddress.getLocalHost(),8888);
        System.out.println("服务器连接成功..." + socket.getClass());
        // 2）通过getOutputStream()获得输出流
        //      通过输出流，把数据写入到数据通道中
        OutputStream outputStream = socket.getOutputStream();
        outputStream.write("你好".getBytes());
        //3） 关闭数据流和socket
        outputStream.close();
        socket.close();
        System.out.println("客户端关闭...");
    }
}
