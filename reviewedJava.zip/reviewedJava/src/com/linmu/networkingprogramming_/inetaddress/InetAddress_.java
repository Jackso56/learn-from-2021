package com.linmu.networkingprogramming_.inetaddress;

import org.testng.annotations.Test;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * InetAddress类的静态方法：getLocalHost(),getByName()
 * InetAddress类的对象方法：getHostName(),getHostAddress()
 **/
@SuppressWarnings({"all"})
public class InetAddress_ {

    @Test
    public void method01() throws UnknownHostException {
        // 获取本机 InetAddress 对象
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println("本机 InetAddress 对象:" + localHost);
    }

    @Test
    public void method02() throws UnknownHostException {
        // 根据主机名，获得 InetAddress 对象
        InetAddress localHost = InetAddress.getByName("小新");
        System.out.println("本机 InetAddress 对象:" + localHost);
    }

    @Test
    public void method03() throws UnknownHostException {
        // 根据域名，获得 InetAddress 对象
        InetAddress localHost = InetAddress.getByName("www.baidu.com");
        System.out.println("www.baidu.com的InetAddress 对象:" + localHost);
    }

    @Test
    public void method04() throws UnknownHostException {
        // 根据InetAddress对象获得主机名
        InetAddress localHost = InetAddress.getLocalHost();
        String hostName = localHost.getHostName();
        System.out.println("根据InetAddress对象获得主机名：" + hostName);
    }

    @Test
    public void method05() throws UnknownHostException {
        // 根据InetAddress对象获得ip地址
        InetAddress localHost = InetAddress.getLocalHost();
        String hostName = localHost.getHostAddress();
        System.out.println("根据InetAddress对象获得ip地址：" + hostName);
    }
}
