package com.linmu.networkingprogramming_.soket;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Socket类：
 * 1）在网络编程中被广泛应用
 * 2）通信的两端都有Soket，是两台机器通信的端点
 * 3）网络通信实际上是Socket之间的通信
 * 4）Socket允许程序将网络连接当做一个流，数据以I\O流的形式在Socket之间传输
 * 5）一般情况下：主动发起通信请求的是客户端，等待通信请求的是服务端
 **/
@SuppressWarnings({"all"})
public class Socket_ {

    @Test
    public void method01(){

    }
}
