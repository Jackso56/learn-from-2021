package com.linmu.networkingprogramming_.udpprogramming;

import org.testng.annotations.Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class UDPreceive {

    @Test
    public void method01() throws IOException {
        // 创建DatagramSocket对象，在8888端口监听
        DatagramSocket datagramSocket = new DatagramSocket(8888);
        // 创建DatagramPacket对象，接收数据，（UDP数据包最大为64k）
        byte[] bytes = new byte[1024];
        DatagramPacket datagramPacket = new DatagramPacket(bytes, 0, bytes.length);
        // 调用方法接收数据到datagramPacket中，未接收到数据会阻塞
        System.out.println("等待接收数据...");
        datagramSocket.receive(datagramPacket);
        // 拆包取数据，并输出
        int length = datagramPacket.getLength();
        byte[] data = datagramPacket.getData();
        String string = new String(data, 0, length);
        System.out.println("读取到的数据：" + string);
        // 关闭资源
        System.out.println("数据接收完毕，关闭资源...");
        datagramSocket.close();
    }
}
