package com.linmu.networkingprogramming_.udpprogramming;

import org.testng.annotations.Test;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class UDPseceive_01 {

    @Test
    public void method01() throws IOException {
//        创建Socket对象
        DatagramSocket datagramSocket = new DatagramSocket(8888);
//        创建数据报，获取数据
        byte[] bytes = new byte[1024];
        DatagramPacket datagramPacket = new DatagramPacket(bytes,0,bytes.length);
        System.out.println("等待接收数据...");
        datagramSocket.receive(datagramPacket);
        byte[] data = datagramPacket.getData();
        int length = datagramPacket.getLength();
        String string = new String(bytes, 0, length);
        // 输出数据
        System.out.println(string);
        // 关闭资源
        System.out.println("关闭资源...");
        datagramSocket.close();
    }

}
