package com.linmu.networkingprogramming_.udpprogramming;

import org.testng.annotations.Test;

import java.io.IOException;
import java.net.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class UDPsend_01 {

    @Test
    public void method01() throws IOException {
//        创建Socket对象
        DatagramSocket datagramSocket = new DatagramSocket(8889);
//        创建数据报
        byte[] bytes = "林沐师弟".getBytes();
        DatagramPacket datagramPacket = new DatagramPacket(
                bytes,bytes.length, InetAddress.getLocalHost(), 8888);
//        发送数据
        datagramSocket.send(datagramPacket);
        System.out.println("数据发送完毕...");
//        关闭资源
        System.out.println("关闭资源...");
        datagramSocket.close();
    }
}
