package com.linmu.networkingprogramming_.udpprogramming;

import org.testng.annotations.Test;

import java.io.IOException;
import java.net.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * UDP协议：用户数据协议（用的少）
 * 1）将数据、源、目的地封装成数据包，不需要建立连接
 * 2）每个数据报的大小限制在64k内，不适合传输大量数据
 * 3）无需连接，不可靠
 * 4）发送数据结束时无需释放资源（不是面向连接，速度快）
 **/
@SuppressWarnings({"all"})
public class UDPsend_ {

    @Test
    public void method01() throws IOException {
        // 创建DatagramSocket对象，在8889接收数据
        DatagramSocket datagramSocket = new DatagramSocket(8889);
        byte[] bytes = "林沐大师兄".getBytes();
        // 创建DatagramPacket对象，需指定主机和端口号
        DatagramPacket datagramPacket = new DatagramPacket(
                bytes, bytes.length, InetAddress.getLocalHost(), 8888);
        // 发送数据
        datagramSocket.send(datagramPacket);
        // 关闭资源
        System.out.println("数据发送完毕，关闭资源...");
        datagramSocket.close();
    }
}
