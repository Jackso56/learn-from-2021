package com.linmu.commonlyUsedClass_.big;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

import java.math.BigDecimal;

/**
 * BigDecimal类常见方法:add,subtract,multiply,divide
 *                      其中divide方法需要指定精度，否则会报错
 */

@SuppressWarnings({"all"})
public class BigDecimal_ {
    public static void main(String[] args) {
        BigDecimal bigDecimal = new BigDecimal("1.234234535634675856");
        BigDecimal bigDecimal1 = new BigDecimal("3.14159265335434532452352354");
        System.out.println("两数相加：" + bigDecimal.add(bigDecimal1));
        System.out.println("两数相减：" + bigDecimal.subtract(bigDecimal1));
        System.out.println("两数相乘：" + bigDecimal.multiply(bigDecimal1));
        System.out.println("两数相除：" + bigDecimal1.divide(
                bigDecimal,BigDecimal.ROUND_FLOOR));
        System.out.println("两数相除：" + bigDecimal1.divide(
                bigDecimal,BigDecimal.ROUND_CEILING));
    }
}
