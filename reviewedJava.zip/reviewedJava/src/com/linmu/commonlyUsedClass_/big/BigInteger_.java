package com.linmu.commonlyUsedClass_.big;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

import java.math.BigInteger;

/**
 * BigInteger常用方法：add,subtract,multiply,divide
 */

@SuppressWarnings({"all"})
public class BigInteger_ {
    public static void main(String[] args) {
        BigInteger bigInteger = new BigInteger("12341154646547856865345");
        BigInteger bigInteger1 = new BigInteger("12341154646545223865345");
        System.out.println("两数相加：" + bigInteger1.add(bigInteger));
        System.out.println("两数相减：" + bigInteger1.subtract(bigInteger));
        System.out.println("两数相乘：" + bigInteger1.multiply(bigInteger));
        System.out.println("两数相除：" + bigInteger1.divide(bigInteger));
    }
}
