package com.linmu.commonlyUsedClass_.datetime;

import org.testng.annotations.Test;

import java.util.Date;
import java.time.Instant;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Instant_ {
    public static void main(String[] args) {
        Instant instant = Instant.now();
        Date date = Date.from(instant);
        System.out.println("instant转date: " + date);
    }

    @Test
    public void method_(){
        Date date = new Date();
        Instant instant = date.toInstant();
        System.out.println("date转Instant：" + instant);
    }
}
