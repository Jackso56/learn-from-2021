package com.linmu.commonlyUsedClass_.datetime;

import org.testng.annotations.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Date_ {
 /**
    时间对象格式化
    年：y
    月：M
    日：d
    时：H
    分：m
    秒：s
    毫秒：S
    星期：E
  */
    public static void main(String[] args) {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss-SS E");
        String format = sdf.format(date);
        System.out.println(format);
        System.out.println(date);
    }

    @Test
    public void method_(){
        String format = (new SimpleDateFormat("yyyy-MM-dd HH-mm-ss-SS E")).
                format(new Date());
        System.out.println(format);
        Date date = new Date();
        // Date 转 毫秒
        System.out.println(date.getTime());
    }
}
