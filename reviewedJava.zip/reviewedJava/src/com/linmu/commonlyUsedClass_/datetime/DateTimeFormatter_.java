package com.linmu.commonlyUsedClass_.datetime;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class DateTimeFormatter_ {
    public static void main(String[] args) {
        LocalDateTime locaalDateTime = LocalDateTime.now();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.
                ofPattern("yyyy-MM-dd HH-mm-ss-SS");
        String format = dateTimeFormatter.format(locaalDateTime);
        System.out.println("字符格式化的结果：" + format);
    }
}
