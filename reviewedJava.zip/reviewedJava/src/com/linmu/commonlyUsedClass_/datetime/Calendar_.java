package com.linmu.commonlyUsedClass_.datetime;

import java.util.Calendar;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Calendar_ {
    /**
     * Calendar类是一个抽象类,通过getInstance()创建对象
     * 提供字段来获取相关时间的信息：
     * Calendar.YEAR，
     * Calendar.MONTH，
     * Calendar.DAY_OF_MONTH，
     * Calendar.HOUR_OF_DAY，
     * Calendar.MINUTE，
     * Calendar.SECOND，
     * Calendar.MILLISECOND
     */
    
    public static void main(String[] args) {
        Calendar calendar = Calendar.getInstance();
        System.out.println("年：" + calendar.get(Calendar.YEAR));
        // 月的编号从0开始
        System.out.println("月：" + calendar.get(Calendar.MONTH) + 1);
        System.out.println("日：" + calendar.get(Calendar.DAY_OF_MONTH));
        System.out.println("时(12小时制)：" + calendar.get(Calendar.HOUR));
        System.out.println("时(24小时制)：" + calendar.get(Calendar.HOUR_OF_DAY));
        System.out.println("分：" + calendar.get(Calendar.MINUTE));
        System.out.println("秒：" + calendar.get(Calendar.SECOND));
        System.out.println("毫秒：" + calendar.get(Calendar .MILLISECOND));
        System.out.println(calendar.get(Calendar.YEAR) + "-" +
                calendar.get(Calendar.MONTH) + "-" + calendar.get(Calendar.DAY_OF_MONTH) +
                " " + calendar.get(Calendar.HOUR_OF_DAY) + "-" + calendar.get(Calendar.MINUTE) +
                "-" + calendar.get(Calendar.SECOND) + "-" + calendar.get(Calendar.MILLISECOND));
    }
}
