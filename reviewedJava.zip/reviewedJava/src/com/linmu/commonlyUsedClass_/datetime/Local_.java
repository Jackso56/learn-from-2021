package com.linmu.commonlyUsedClass_.datetime;

import org.testng.annotations.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Local_ {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.now();
        LocalTime localTime = LocalTime.now();
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println("localDate = " + localDate + "\n" +
                "localTime = " + localTime + "\nlocalDateTime = " + localDateTime);
        LocalDate now = LocalDate.now();
        System.out.println("当前日期：" + now);
        LocalDate of = LocalDate.of(1999, 2, 3);
        System.out.println(of);
    }

    @Test
    public void method_LocalDateTime(){
        /**
         * 相关get()方法：
         * getYear(),getMonthValue(),getMonth(),getDayOfMonth(),
         * getHour(),getMinute(),getSecond(),
         */
        LocalDateTime localDateTime = LocalDateTime.now();
        System.out.println("通过get()方法获取相关时间信息：" +
                localDateTime.getYear() + "-" + localDateTime.getMonthValue() +
                "-" + localDateTime.getDayOfMonth() + " " + localDateTime.getHour() +
                "-" + localDateTime.getMinute() + "-" + localDateTime.getSecond());
        System.out.println("getMonth()和getMonthValue()方法：" +
                localDateTime.getMonth() + "-" + localDateTime.getMonthValue());
    }

    @Test
    public void method_LocalDate(){
        /**
         * 相关get()方法：
         * getYear(),getMonthValue(),getMonth(),getDayOfMonth()
         */
        LocalDate localDate = LocalDate.now();
        System.out.println("通过get()方法获取相关时间信息：" +
                localDate.getYear() + "-" + localDate.getMonthValue() +
                "-" + localDate.getDayOfMonth());
        System.out.println("getMonth()和getMonthValue()方法：" +
                localDate.getMonth() + "-" + localDate.getMonthValue());
    }

    @Test
    public void method_LocalTime(){
        /**
         * 相关get()方法：
         * getHour(),getMinute(),getSecond()
         */
        LocalTime localTime = LocalTime.now();
        System.out.println("通过get()方法获取相关时间信息：" + localTime.getHour() +
                "-" + localTime.getMinute() + "-" + localTime.getSecond());
    }

    @Test
    public void method_Local(){
//        plus方法
        LocalDateTime localDateTime = LocalDateTime.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
        System.out.println("原时间：" + dtf.format(localDateTime));
        LocalDateTime localDateTime1 = localDateTime.plusDays(12);
        System.out.println("处理后的时间：" + dtf.format(localDateTime1));
        System.out.println("=====================================");
        LocalDateTime localDateTime2 = LocalDateTime.now();
        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
        System.out.println("原时间：" + dtf2.format(localDateTime));
        LocalDateTime localDateTime3 = localDateTime.plusMinutes(12);
        System.out.println("处理后的时间：" + dtf.format(localDateTime3));
    }

    @Test
    public void method_Local1(){
//        minus方法
        LocalDateTime localDateTime = LocalDateTime.now();
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
        System.out.println("原时间：" + dtf.format(localDateTime));
        LocalDateTime localDateTime1 = localDateTime.minusDays(12);
        System.out.println("处理后的时间：" + dtf.format(localDateTime1));
        System.out.println("=====================================");
        LocalDateTime localDateTime2 = LocalDateTime.now();
        DateTimeFormatter dtf2 = DateTimeFormatter.ofPattern("yyyy-MM-dd HH-mm-ss");
        System.out.println("原时间：" + dtf2.format(localDateTime));
        LocalDateTime localDateTime3 = localDateTime.minusMinutes(12);
        System.out.println("处理后的时间：" + dtf.format(localDateTime3));
    }
}
