package com.linmu.commonlyUsedClass_.system;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

import java.util.Arrays;

/**
 * System类的常用方法：arraycopy,gc,currentTimeMillis,
 *                      exit需要传入状态值，0 即可
 */

@SuppressWarnings({"all"})
public class System_ {
    public static void main(String[] args) {
        System.out.println("系统当前时间：" + System.currentTimeMillis());
        int[] numbers = {1,2,3,4,5,6,7,8,9};
        int[] newNumbers = new int[10];
        System.arraycopy(numbers,0,newNumbers,0,5);
        System.out.println("newNumbres的数据：" + Arrays.toString(newNumbers));
        System.out.println("程序结束...");
        System.exit(0);
        System.out.println("程序退出....");
    }
}
