package com.linmu.commonlyUsedClass_.random;


import java.util.Random;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
// TODO: 2022/11/10
@SuppressWarnings({"all"})
public class Randomcon {
    public static void main(String[] args) {
        me();
    }

    // constructor
    public static void constr() {
        // constructor 1
        Random random = new Random();
        // constructor 2    seed,随机数种子
        Random random1 = new Random(1);
    }

    // method
    public static void me() {
        Random random = new Random();
        // 设置随机数种子
        random.setSeed(1);
        int i = random.nextInt();
        System.out.println("随机数（范围int数值的范围）：" + i);
        int number = random.nextInt(100);
        System.out.println( "指定范围[0,100)范围内的随机数:" + number);
    }
}
