package com.linmu.commonlyUsedClass_.stringBu;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class StirngBuilder_ {
    public static void main(String[] args) {
//        构造器指定char[]数组大小,Debug方式查看数组大小
        StringBuilder stringBuilder = new StringBuilder();
        StringBuffer stringBuffer1 = new StringBuffer(10);
        StringBuilder stringBuffer2 = new StringBuilder("hello");
    }

    @Test
    public void method_(){
//        String对象转StringBuilder对象
        System.out.println("String对象转StringBuffer对象");
        String string = "hello,Jackson";
//        方式一:构造器
        StringBuilder stringBuilder = new StringBuilder(string);
        System.out.println("运行类型：" + stringBuilder.getClass());
//        方式二:使用append()方法
        StringBuilder stringBuilder1 = new StringBuilder();
        StringBuilder stringBuilder2 = stringBuilder1.append(string);
        System.out.println("运行类型：" + stringBuilder2.getClass());
//        StringBuilder对象转String对象
        System.out.println("StringBuffer对象转String对象");
        StringBuilder stringBuilder3 = new StringBuilder("hello,Jackson");
//        方式一：toString()方法
        String string1 = stringBuilder3.toString();
        System.out.println("运行类型：" + string1.getClass());
//        方式二：构造器
        String string2 = new String(stringBuilder3);
        System.out.println("运行类型：" + string2.getClass());
    }

    @Test
    public void method_1(){
        /***
         * StringBuilder类常用方法：
         *    append,delete,replace,indexOf,insert,length
         */
        StringBuilder stringBuilder = new StringBuilder();
        System.out.println("stringBuffer大小：" + stringBuilder.length());
        stringBuilder.append("Jackson");
        stringBuilder.append("Jack");
        stringBuilder.append("Mike");
        System.out.println("stringBuffer大小：" + stringBuilder.length());
        stringBuilder.delete(0,1);
        System.out.println("stringBuffer大小：" + stringBuilder.length());
        System.out.println("Jack的字符序号：" + stringBuilder.indexOf("Jack"));
        stringBuilder.insert(2,"Jhon");
        System.out.println("stringBuffer的内容：" + stringBuilder);
        stringBuilder.replace(0,2,"Jack");
        System.out.println("stringBuffer的内容：" + stringBuilder);
    }
}
