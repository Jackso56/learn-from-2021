package com.linmu.commonlyUsedClass_.stringBu;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class StringBuffer_ {
    /***
     * StringBuffer为可变字符序列，且无法被继承（是个final类）
     */
    public static void main(String[] args) {
//        构造器指定char[]数组大小,Debug方式查看数组大小
        StringBuffer stringBuffer = new StringBuffer();// 16
        StringBuffer stringBuffer1 = new StringBuffer(20);// 20
        StringBuffer stringBuffer3 = new StringBuffer("hello");// string.length() + 16
    }

    @Test
    public void method_(){
//        String对象转StringBuffer对象
        System.out.println("String对象转StringBuffer对象");
        String string = "hello,Jackson";
//        方式一:构造器
        StringBuffer stringBuffer = new StringBuffer(string);
        System.out.println("运行类型：" + stringBuffer.getClass());
//        方式二:使用append()方法
        StringBuffer stringBuffer1 = new StringBuffer();
        StringBuffer stringBuffer2 = stringBuffer1.append(string);
        System.out.println("运行类型：" + stringBuffer2.getClass());
//        StringBuffer对象转String对象
        System.out.println("StringBuffer对象转String对象");
        StringBuffer stringBuffer3 = new StringBuffer("hello,Jackson");
//        方式一：toString()方法
        String string1 = stringBuffer3.toString();
        System.out.println("运行类型：" + string1.getClass());
//        方式二：构造器
        String string2 = new String(stringBuffer3);
        System.out.println("运行类型：" + string2.getClass());
    }

    @Test
    public void method_1(){
        /***
         * StringBuffer类常用方法：
         *    append,delete,replace,indexOf,insert,length
         */
        StringBuffer stringBuffer = new StringBuffer();
        System.out.println("stringBuffer大小：" + stringBuffer.length());
        stringBuffer.append("Jackson");
        stringBuffer.append("Jack");
        stringBuffer.append("Mike");
        System.out.println("stringBuffer大小：" + stringBuffer.length());
        stringBuffer.delete(0,1);
        System.out.println("stringBuffer大小：" + stringBuffer.length());
        System.out.println("Jack的字符序号：" + stringBuffer.indexOf("Jack"));
        stringBuffer.insert(2,"Jhon");
        System.out.println("stringBuffer的内容：" + stringBuffer);
        stringBuffer.replace(0,2,"Jack");
        System.out.println("stringBuffer的内容：" + stringBuffer);
    }
}
