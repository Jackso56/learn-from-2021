package com.linmu.commonlyUsedClass_.stringBu;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class BufferAndBulider {
    /***
     * StringBuilder是StringBuffer的简易替换
     * String:不可变字符序列，效率低，复用率高
     * StringBuffer:可变字符序列，效率较高（增删），线程安全
     * StringBuilder：可变字符序列，效率高，线程不安全
     *  其中StringBuffer和StringBuilder的方法是一样的
     *
     * 存在大量修改，一般使用StringBuffer或StringBuilder
     * 存在大量修改，且是多线程，使用StringBuffer
     * 存在大量修改，且是单线程，使用StringBuilder
     */
    public static void main(String[] args) {

    }
}
