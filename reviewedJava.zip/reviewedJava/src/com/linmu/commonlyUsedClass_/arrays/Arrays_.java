package com.linmu.commonlyUsedClass_.arrays;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
/**
 * Arrays类的方法，均为静态方法：
 * toString，sort，binarySearch，copyOf，
 * fill，equals，asList
 */
@SuppressWarnings({"all"})
public class Arrays_ {
    public static void main(String[] args) {
        int[] numbers = new int[] {1,2,3,4,5,6,7,8,9};
        System.out.println("输出数组：" + Arrays.toString(numbers));
    }

    @Test
    public void method_sort(){
        int[] numbers = new int[] {1,2,3,67,5,6,34,8,9};
        Arrays.sort(numbers);
        System.out.println("输出排序后的数组：" + Arrays.toString(numbers));
    }

    @Test
    public void method_binarySearch(){
//        要求数组是有序的
        int[] numbers = new int[] {1,2,3,4,5,6,7,8,9};
        System.out.println("以二叉树方式查找元素：" + Arrays.binarySearch(numbers,6));
    }

    @Test
    public void method_copyOf(){
        int[] numbers = new int[] {1,2,3,4,5,6,7,8,9};
        int[] newNumbers = Arrays.copyOf(numbers,5);
        System.out.println("输出新数组：" + Arrays.toString(newNumbers));
    }

    @Test
    public void method_fill(){
        int[] numbers = new int[] {1,2,3,4,5,6,7,8,9};
        Arrays.fill(numbers,25);
        System.out.println("填充后的数组：" + Arrays.toString(numbers));
    }

    @Test
    public void method_equals(){
        int[] numbers = new int[] {1,2,3,4,5,6,7,8,9};
        int[] newNumbers = {12,34,65,87,54,23,10};
        System.out.println("数组比较：" + Arrays.equals(numbers,newNumbers));
        System.out.println("运行类型：" + numbers.getClass());
    }

    @Test
    public void method_asList(){
        List<Integer> integers = Arrays.asList(1, 2, 3, 4, 6, 5, 8, 9, 0);
        System.out.println("数值转list：" + integers);
        System.out.println("integer的运行类型：" + integers.getClass());
//        Arrays.sort(integers,new Comparator<Integer,Integer>(){
//            @Override
//            public int compare(Integer o1, Integer o2) {
//                 return o1 > o2 ? o1 : o2;
//            }
//        });
    }
}
