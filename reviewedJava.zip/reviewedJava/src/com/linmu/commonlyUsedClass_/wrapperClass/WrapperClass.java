package com.linmu.commonlyUsedClass_.wrapperClass;
//import java.lang.Integer;
/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class WrapperClass {
    public static void main(String[] args) {
        /***
         * 包装类：对应基本数据类型的引用类型，使其可以调用相关类的方法
         *      基本数据类型    包装类
         *      boolean         Boolean
         *      char            Character
         *      byte            Byte
         *      short           Short
         *      int             Integer
         *      long            Long
         *      float           Float
         *      double          Double
         *  装箱、拆箱
         */
        int number = 1;
        //手动装箱方式一
        Integer integer = new Integer(number);
        //手动装箱方式二
        Integer newInteger = number;
        //手动装箱方式三
        Integer new_Integer = Integer.valueOf(number);
        //手动拆箱方式一
        int newNumber = integer.intValue();
        System.out.println("integer的运行类型：" + integer.getClass() + "\n"
                + "newInteger的运行类型：" + newInteger.getClass() + "\n" +
                "new_Integer的运行类型：" + new_Integer.getClass());

    }
}
