package com.linmu.commonlyUsedClass_.wrapperClass;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class WrapperClassSwap {
    /***
     * String类和其他包装类的相互装换
     */
    public static void main(String[] args) {
        Integer integer = new Integer(1);
        //包装类转String类方式一
        String string = integer.toString();
        //包装类转String类方式二
        String value = String.valueOf(integer);
        System.out.println("包装类转String类方式一:" + string.getClass() + "\n" +
                "包装类转String类方式二:" + value.getClass());
        System.out.println("==============================================");
        //String类转包装类方式一
        Integer newInteger = new Integer(string);
        //String类转包装类方式二
        Integer newInteger1 = Integer.valueOf(string);
        System.out.println("String类转包装类方式一:" + newInteger.getClass() + "\n" +
                "String类转包装类方式二:" + newInteger1.getClass());
    }
}
