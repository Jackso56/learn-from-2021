package com.linmu.commonlyUsedClass_.wrapperClass;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class WrapperClassMetod {
    /***
     *Integer包装类和Character包装类的常用方法
     * Integer包装类：MAX_VALUE，MIN_VALUE
     * Character包装类:isDigit,isLetter,isLowerCase,isWhitespace,
     *                  toLowerCase,toUpperCase */
    public static void main(String[] args) {
        System.out.println("Integer包装类最大值：" + Integer.MAX_VALUE);
        System.out.println("Integer包装类最小值：" + Integer.MIN_VALUE);
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Character包装类判断数字：" + Character.isDigit('1'));
        System.out.println("Character包装类判断字母：" + Character.isLetter('1'));
        System.out.println("Character包装类判断小写字母：" + Character.isLowerCase('a'));
        System.out.println("Character包装类判断大写字母：" + Character.isUpperCase('a'));
        System.out.println("Character包装类判断空格：" + Character.isWhitespace('a'));
        System.out.println("++++++++++++++++++++++++++++++++++++++++++++++++");
        System.out.println("Character包装类转小写：" + Character.toLowerCase('A'));
        System.out.println("Character包装类转大写：" + Character.toUpperCase('a'));
    }
}
