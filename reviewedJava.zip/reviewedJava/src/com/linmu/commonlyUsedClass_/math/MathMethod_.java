package com.linmu.commonlyUsedClass_.math;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class MathMethod_ {
    /***
     * Math类的常用方法(均是静态方法)：
     * abs,pow,ceil,floor,round,random,
     * sqrt,max,min,
     */
    public static void main(String[] args) {
        System.out.println("Math.abs(-1)计算结果：" + Math.abs(-1));
        System.out.println("Math.pow(12,2)计算结果：" + Math.pow(12,2));
        System.out.println("Math.ceil(1.2)计算结果：" + Math.ceil(1.2));
        System.out.println("Math.floor(1.2)计算结果：" + Math.floor(1.2));
        System.out.println("Math.sqrt(169)计算结果：" + Math.sqrt(160));
        System.out.println("Math.max(12,3)计算结果：" + Math.max(12,3));
        System.out.println("Math.min(12,3)计算结果：" + Math.min(12,3));
        System.out.println("Math.round(4.5)计算结果：" + Math.round(4.4));
        System.out.print("随机数生成器：\t" );
        for (int i = 0; i < 5; i++) {
            System.out.print(Math.random() * 9 + 1 + "\t");
        }
    }
}
