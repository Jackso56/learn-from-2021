package com.linmu.commonlyUsedClass_.stringClass;

import org.testng.annotations.Test;

import java.util.Arrays;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Method_ {
    /***
     * String字符序列为不可变字符序列
     * String类常见方法
     * intern() 返回常量池中的地址（对象）
     * equals,equalsIgnoreCase,indexOf,lastIndexOf,
     * substring,length,charAt,toUpperCase,toLowerCase,
     * concat,replace,split,compareTo,toCharArray,format,
     * startsWith,endsWith,isEmpty,join
     * @param args
     */
    public static void main(String[] args) {
        String string = "jack";
        String string1 = "jack";
        String string2 = "Jackkak";
        String string3 = "   jack  ";
        String string4 = "hello,jack.I from China";
        System.out.println("判断字符内容是否相等：" + string.equals(string1));
        System.out.println("(忽略大小写)判断字符内容是否相等：" + string.equalsIgnoreCase(string2));
        System.out.println("返回字符串长度：" + string.length());
        System.out.println("返回字符在字符串中第一次出现的序号：" + string.indexOf("ck"));
        System.out.println("返回字符在字符串中最后出现的序号：" + string2.lastIndexOf('k'));
        System.out.println("截取指定范围字符串(前开后闭)：" + string2.substring(1, 3));
        System.out.print("去除字符串前后的空格：\t" + "去除空格之前的长度：" + string3.length());
        string3.trim();
        System.out.println("\t\t去除空格之后的长度：" + string.length());
        System.out.println("取字符串中的单个字符（不能索引方式取得）：" + string.charAt(1));
        System.out.println("字符串转大写：" + string.toUpperCase());
        System.out.println("字符串转小写：" + (string.toUpperCase()).toLowerCase());
        System.out.println("连接字符串：" + string.concat(string1));
        System.out.println("字符替换：" + string.replace('j', 'A'));
        String[] split = string4.split("[,. ]");
        System.out.println("分割字符串：" + Arrays.toString(split));
        System.out.println("比较字符串：" + "hello".compareTo("ahello"));
        System.out.println("字符串数组：" + Arrays.toString("hello".toCharArray()));
        int age = 19;
        String name = "林沐";
        String stringFormat = "我是%s,年龄%d";
        String format = String.format(stringFormat, name, age);
        System.out.println(format);
        System.out.println("以什么字符开头：" + "hello".startsWith("h"));
        System.out.println("以什么字符结束：" + "hello".endsWith("o"));
        System.out.println("字符串为空：" + "".isEmpty());
        System.out.println("以指定字符连接组成新的字符串：" +
                String.join("-","jack","jackson","black"));
    }
    @Test
    public static void me(){
        String str = "jack";
        System.out.println(str);
        String str1 = new String("jackson");
        System.out.println(str1);
    }
}
