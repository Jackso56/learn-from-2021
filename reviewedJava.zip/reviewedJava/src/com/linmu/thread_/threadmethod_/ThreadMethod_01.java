package com.linmu.thread_.threadmethod_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 线程方法：setName,getName,start,setPriority,getPriority,join,yield，getState
 * 优先级：
 * public final static int MIN_PRIORITY = 1;
 * public final static int NORM_PRIORITY = 5;
 * public final static int MAX_PRIORITY = 10;
 *
 **/
@SuppressWarnings({"all"})
public class ThreadMethod_01 {
    public static void main(String[] args) throws InterruptedException {
        // 创建线程，需要对象
        Thread thread = new Thread(new People());
        // 设置线程名称
        thread.setName("次线程");
        Thread.currentThread().setName("主线程");
        // 启动线程
        thread.start();
        // 获取线程优先级
        int priority = thread.getPriority();
        System.out.println("次线程线程优先级：" + priority);
        System.out.println("主线程优先级：" + Thread.currentThread().getPriority());
        // 设置线程优先级
        thread.setPriority(Thread.MAX_PRIORITY);
        int priority1 = thread.getPriority();
        System.out.println("次线程优先级：" + priority1);
        for (int i = 0; i < 30; i++) {
            Thread.sleep(1000);
            // 获取线程名称
            System.out.println(thread.currentThread().getName() + "运行中..." + i);
            if (i == 5){
                System.out.println("调用yeild方法...");
                // 线程插队，插队线程优先制行
                // thread.join();
                // 让出cpu，礼让是否成功，是随机的
                thread.yield();
            }
        }
    }
}
class People implements Runnable{
    @Override
    public void run() {
        for (int i = 0; i < 30; i++) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(Thread.currentThread().getName() + "线程运行中..." + i);
        }
    }
}
