package com.linmu.thread_.threadmethod_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 守护线程：
 * 1）用户线程：也叫工作线程，当线程执行完成或以通知的方式结束
 * 2）守护线程：一般是为工作线程服务的，当所有工作线程结束，守护线程自动结束
 * 3）常见的守护线程：垃圾回收机制
 **/
@SuppressWarnings({"all"})
public class GuardThread_ {
    public static void main(String[] args) throws InterruptedException {
        Thread thread = new Thread(new Guard());
        // 设置守护线程，需要在启动线程之前设置
        thread.setDaemon(true);
        thread.start();
        for (int i = 0; i < 10; i++) {
            Thread.sleep(1000);
            System.out.println(Thread.currentThread().getName() + "运行中...");
        }
    }
}
@SuppressWarnings({"all"})
class Guard implements Runnable{
    @Override
    public void run() {
        for (;;) {
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            System.out.println(Thread.currentThread().getName() + "运行中...");
        }
    }
}
