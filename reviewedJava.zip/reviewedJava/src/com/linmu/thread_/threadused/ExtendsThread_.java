package com.linmu.thread_.threadused;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 线程使用方式一：继承Thread方法，重写run方法
 * 1）当一个类继承了Thread类就可以当做线程来使用
 * 2）往往重写run方法，并写上自己的业务代码
 * 3）Thread类实现了Runnable接口，重写了Runnable接口的run方法
 * class Thread implements Runnable
     * @Override public void run() {
     *  if (target != null) {
     *      target.run();
     *      }
     *  }
 **/
@SuppressWarnings({"all"})
public class ExtendsThread_ {
    public static void main(String[] args) throws InterruptedException {
        Cat tom = new Cat("thread01","tom");
        // 启动线程，线程会自动调用run方法，此时该方法为进程的实体
        // 未启动线程时，手动调用方法，该方法会被当做普通方法
        tom.start();
        for (int i = 0; i < 10; i++) {
            // Thread.currentThread().getName()返回当前线程的名称
            System.out.println(i + Thread.currentThread().getName());
            // 线程休眠1秒
            Thread.sleep(1000);
        }
    }
    @Test
    public void method01() throws InterruptedException {
        Cat tom = new Cat("thread01","tom");
       tom.start();
        for (int i = 0; i < 10; i++) {
            System.out.println(i + Thread.currentThread().getName());
            Thread.sleep(1000);
        }
    }
}

class Cat extends Thread {
    private final String name;

    public Cat(String name, String name1) {
        super(name);
        this.name = name1;
    }

    @Override
    public void run() {
        super.run();
        for (int i = 0; i < 10; i++) {
            System.out.println(name + "喵喵叫..." + Thread.currentThread().getName());
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
