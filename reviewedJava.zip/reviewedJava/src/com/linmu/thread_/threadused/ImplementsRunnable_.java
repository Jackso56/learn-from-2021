package com.linmu.thread_.threadused;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 线程实现方式二：实现Runnable接口,实现Runnable方法
 * 1）弥补了java单继承机制的不足
 *
 * 实现Runnable接口VS继承Thread类
 * 1）二者本质上是一样的，Thread类本身实现类Runnable接口
 * 2）实现Runnable接口的方式更加适合多个线程共享一个资源的情况，
 *      且避免了java单继承机制的不足，建议使用
 *
 **/
@SuppressWarnings({"all"})
public class ImplementsRunnable_ {
    public static void main(String[] args) throws InterruptedException {
        // 传入对象，创建线程
        Thread thread = new Thread(new Dog());
        // 启动线程
        thread.start();
        Thread thread1 = new Thread(new Dog());
        thread1.start();
        for (int i = 0; i < 10; i++) {
            Thread.sleep(1000);
            System.out.println(i + Thread.currentThread().getName() + "运行中...");
        }
    }
}
class Dog implements Runnable{

    @Override
    public void run() {
        for (int i = 0; i < 10; i++) {
            System.out.println(i + Thread.currentThread().getName() + "线程运行中...");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }
}
