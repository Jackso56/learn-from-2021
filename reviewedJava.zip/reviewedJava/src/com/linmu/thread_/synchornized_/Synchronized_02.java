package com.linmu.thread_.synchornized_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 互斥锁：
 * 1）java引入了对象互斥锁的概念，来保证数据操作的完整性
 * 2）每个对象都对应一个“互斥锁”的标记，这个标记保证了在同一时刻只能有一个线程访问该对象
 * 3）synchronized用来维护与对象互斥锁联系，保证了在同一时刻只能有一个线程访问该对象
 * 4）同步局限性：导致程序的执行效率低下
 * 5）同步方法（非静态）的锁可以是this，也可以是其他对象（要求是同一个对象）
 * 6）同步方法（静态）的锁为当前类本身
 *
 * 细节：
 * 1）同步方法没有static修饰，默认锁对象为this
 * 2）如果方法使用static修饰，默认锁对象为当前类.class
 *
 **/
@SuppressWarnings({"all"})
public class Synchronized_02 {
    public static void main(String[] args) {
        Human1 human1 = new Human1();
        (new Thread(human1)).start();
        (new Thread(human1)).start();
        (new Thread(human1)).start();
    }
}
class Human1 implements Runnable{
    @Override
    public void run() {
        try {
            method();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    // 同步代码块，这时锁在this对象上
    public synchronized void method01(){
        System.out.println();
    }
    // 同步代码块，这时锁在this对象上
    public  void method() throws InterruptedException {
        synchronized(this){
            for (int i = 0; i < 10; i++) {
                Thread.sleep(1000);
                System.out.println(Thread.currentThread().getName() + "运行中...");
            }
        }
    }
}
class Student implements Runnable{
    @Override
    public void run() {

    }
    // 此时锁在类上
    public static synchronized void method01(){
        System.out.println("静态方法...");
    }
    // 此时锁在类上，代码块中需要填入类的class对象 类.class
    public static void method02(){
        synchronized (Student.class){
            System.out.println("静态方法中的代码块...");
        }
    }
}