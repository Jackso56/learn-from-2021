package com.linmu.thread_.synchornized_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 线程同步：在同一时刻，不允许多个线程(同一对象)同时访问同一个内存地址，
 *              同一内存地址在同一时刻只允许被一个线程访问
 * 线程同步实现语法：
 * 1）同步代码块
 *      synchronized (对象){
 *          业务代码
 *      }
 * 2）同步方法
 *      public synchronized void method() throws InterruptedException {
 *              业务代码
 *          }
 **/
@SuppressWarnings({"all"})
public class Synchronized_01 {
    public static void main(String[] args) {
        // 要求操作的是同一个对象
        Human human = new Human();
        (new Thread(human)).start();
        (new Thread(human)).start();
        (new Thread(human)).start();
    }
}
class Human implements Runnable{
    @Override
    public void run() {
        try {
            method();
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
    // 同步方法，这时锁在this对象上
    public synchronized void method() throws InterruptedException {
        for (int i = 0; i < 10; i++) {
            Thread.sleep(1000);
            System.out.println(Thread.currentThread().getName() + "运行中...");
        }
    }
}
