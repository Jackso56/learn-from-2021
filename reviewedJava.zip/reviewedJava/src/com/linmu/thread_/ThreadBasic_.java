package com.linmu.thread_;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 线程基础：
 * 1）进程：一个程序就是一个进程
 *      启动QQ就是启动了一个进程，启动腾讯视频也是一个进程
 * 2）线程：由进程创建，是进程的实体，一个进程可以有多个线程
 *      QQ里面你可以同时和多个人聊天，和每一个人的聊天，即为一个线程
 * 3）单线程：每一时刻只允许执行一个线程
 * 4）多线程：每一时刻允许执行多个线程（同时存在多个线程在同时执行）
 * 5）并发（交替进行）：同一时刻，多个任务交替执行，形成并行的假象，即 单核cpu实现了多任务并发
 * 6）并行（同时进行）：同一时刻，多个任务同时执行，多核cpu实现了多任务的并行
 **/
@SuppressWarnings({"all"})
public class ThreadBasic_ {

    @Test
    public void method01(){

    }
}
