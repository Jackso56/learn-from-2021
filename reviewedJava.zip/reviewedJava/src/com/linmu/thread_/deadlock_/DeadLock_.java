package com.linmu.thread_.deadlock_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 死锁：多个线程占用对方资源，互不相让，导致BLOCKED，程序无法继续执行，编程需要避免
 **/
@SuppressWarnings({"all"})
public class DeadLock_ {
    public static void main(String[] args) {
        Thread thread1 = new Thread(new Teacher(false));
        Thread thread2 = new Thread(new Teacher(true));
        thread1.start();
        thread2.start();
    }
}
@SuppressWarnings({"all"})
class Teacher implements Runnable{
    static Object o1 = new Object();
    static Object o2 = new Object();
    boolean flag;
    public  Teacher(boolean flag){
        this.flag = flag;
    }
    @Override
    public void run() {
        // 两个线程走不同的分支，就会出现死锁
        if(flag){
            synchronized (o1){
                System.out.println(Thread.currentThread().getName() + "运行中...");
                synchronized (o2){
                    System.out.println(Thread.currentThread().getName() + "运行中...");
                }
            }
        }else{
            synchronized (o2){
                System.out.println(Thread.currentThread().getName() + "运行中...");
                synchronized (o1){
                    System.out.println(Thread.currentThread().getName() + "运行中...");
                }
            }
        }
    }
}