package com.linmu.thread_.Threadlifecycle;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * public enum State {  线程六大状态
 *      NEW,
 *      RUNNABLE,
 *      BLOCKED,
 *      WAITING,
 *      TIMED_WAITING,
 *      TERMINATED;
 *   }
 *   线程状态。 线程可以处于以下状态之一：
 * NEW
 * 尚未启动的线程处于此状态。
 * RUNNABLE（READY,RUNNING）
 * 在Java虚拟机中执行的线程处于此状态。
 * BLOCKED
 * 被阻塞等待监视器锁定的线程处于此状态。
 * WAITING
 * 正在等待另一个线程执行特定动作的线程处于此状态。
 * TIMED_WAITING
 * 正在等待另一个线程执行动作达到指定等待时间的线程处于此状态。
 * TERMINATED
 * 已退出的线程处于此状态。
 **/
@SuppressWarnings({"all"})
public class LifeCycle_ {
    public static void main(String[] args) {

    }
}
