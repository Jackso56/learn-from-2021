package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 局部内部类：定义在外部类的局部位置上，比如方法中、代码块中，并且有类名
 *特点：
 * 1.	局部内部类可以直接使用外部类的全部成员，包括私有的
 * 2.	局部内部类不能使用访问修饰符，但可以使用final关键字，使类不被继承
 * 3.	局部内部类作用域：在定义它的方法或代码块中（局部内部类的地位类似于局部变量）
 * 4.	局部内部类可以直接访问外部类的所有成员
 * 5.	局部内部类的成员，可以通过在外部类局部内部类定义处实例化局部内部类对象被调用
 * 6.	外部其他类无法访问局部内部类
 * 7.	当外部类成员和内部类成员重名时，遵循就近原则，若要访问外部的成员，则可以使用类名.this.成员名  的方式来调用
 *
 **/
@SuppressWarnings({"all"})
public class ObjectOriented12_ {
    public static void main(String[] args) {
        OuterClass jack = new OuterClass("jack", 18);
        jack.innerclass();
    }
}

class OuterClass{
    private String name;
    private int age;

    public OuterClass(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void method01(){
        System.out.println("外部类的public方法...");
    }

    private void method02(){
        System.out.println("外部类的private方法...");
    }


    public void method04(){
        System.out.println("外部类的method04方法被调用...");
    }

//    局部内类仅可以使用final关键字
//    局部内部类的低位类似于局部变量
    public void innerclass(){
        class InnerClass {
            private int number1;

            public InnerClass(int number1) {
                this.number1 = number1;
            }

            //        局部内部类可以访问外部类的所有成员
            //    当外部类成员和内部类成员重名时，遵循就近原则，若要访问外部的成员，则可以使用类名.this.成员名  的方式来调用
            public void method03() {
                System.out.println("局部内部类调用外部类的方法...");
                method01();
                method02();
                method04();
                OuterClass.this.method04();
            }

            public void method04() {
                System.out.println("成员内部类的method04方法被调用...");
            }
        }
        InnerClass innerClass = new InnerClass(1);
        innerClass.method04();
        innerClass.method03();
    }
}
