package com.linmu.objectoriented_;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 自定义泛型类：
 * 基本语法:class Student<T,F>{}
 * 使用细节：
 * 1）普通成员可以使用泛型（属性、方法）
 * 2）静态属性和方法不能使用泛型（与类加载有关）
 * 3）使用泛型的数组不能初始化
 * 4）泛型类的类型是在创建对象时确定的，未确定是默认为Object
 *
 **/
@SuppressWarnings({"all"})
public class AutoGenericityClass_ {

    @Test
    public void method01(){
        Student stringStudent = new Student<String,Double>("jack",19);
        stringStudent.method02("jacksom");
        System.out.println("泛型方法：" + stringStudent.method01());
    }
}

//泛型类
class Student<T,F>{
    private String name;
    private int age;
//    泛型属性
    private T id;
//    泛型数组不能初始化
    T[] ts;

    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

//    泛型方法
    public T method01(){
        return id;
    }

//    使用了泛型的方法
    public void method02(T t){
        System.out.println("使用泛型的方法...");
    }
}
