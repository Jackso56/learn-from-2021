package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 模板设计模式：
 * 1.	创建抽象父类
 * 2.	将公共功能做成一个方法
 * 3.	将特殊部分做成一个抽象方法
 * 4.	在子类中具体实现抽象方法
 **/
@SuppressWarnings({"all"})
public class ObjectOriented10_ {
    public static void main(String[] args) {
        F f = new F();
        f.cry();
        f.eat();
        G g = new G();
        g.cry();
        g.eat();
    }
}

abstract class E{
    void cry(){}
    void eat(){}
}
class F extends E{
    @Override
    void cry() {
        System.out.println("F重写cry方法...");
    }

    @Override
    void eat() {
        System.out.println("F重写eat方法...");
    }
}
class G extends E{
    @Override
    void cry() {
        System.out.println("G重写cry方法...");
    }

    @Override
    void eat() {
        System.out.println("G重写eat方法...");
    }
}
