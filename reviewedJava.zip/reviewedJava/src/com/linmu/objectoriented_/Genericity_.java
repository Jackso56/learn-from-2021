package com.linmu.objectoriented_;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 泛型简介：
     * 1）泛型又叫参数化类型，解决了数据安全问题，是jdk5.0后出现的特性
     * 2）在类声明或实例化对象时需要指定具体的类型
     * 3）泛型可以作为参数、属性
 *
 * 泛型优势;
     * 1）解决了数据安全问题
     * 2）减少了数据转换次数，提高了效率
     * 3）代码具有简洁性、健壮性
 *
 * 泛型声明：interface 接口 <T,K>{}  和  class 类 <T,K>{}
     * 1）T,K表示数据类型（泛型）
     * 2）泛型可以是任意大写字母
 * 泛型实例化：Iterator<Dog> iterator = arrayList.iterator();
     * 1）需要具体指定泛型的具体数据类型
 * 使用细节：interface 接口 <T,K>{}
     * 1）T,K只能是引用数据类型（类，对象）
     * 2）泛型具体化后，可以传入该类型及该类型的子类型
     * 3）泛型使用形式：Iterator<Dog> iterator = arrayList.iterator();
     * 4）没有使用泛型，默认为Object
 *
 *
 *
 *
 **/
@SuppressWarnings({"all"})
public class Genericity_ {

    @Test
    public void method01(){
        ArrayList<Dog1> arrayList = new ArrayList<>();
        arrayList.add(new Dog1("jack",3));
        arrayList.add(new Dog1("jackson",3));
        arrayList.add(new Dog1("black",2));
        Iterator<Dog1> iterator = arrayList.iterator();
        for (Dog1 dog : arrayList) {
            System.out.println("元素信息：" + dog.getName() + ":" + dog.getAge());
        }
    }
}
class Dog1{
    private String name;
    private int age;

    public Dog1(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

//泛型类
class Cat<T,F>{
//    泛型属性
    T t;
    private String name;
    private int age;

    public Cat(String name, int age) {
        this.name = name;
        this.age = age;
    }

//    泛型方法
    public T method01(){
        return t;
    }
}
