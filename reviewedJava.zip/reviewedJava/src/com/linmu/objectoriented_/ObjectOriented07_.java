package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

/***
 * 单例模式：在整个软件系统下，对于某个类只有一个实例化对象，
 * 并且该类只提供一个获取该类的方法
 *
 * 单例模式之饿汉模式（步骤）
 * 1.	.私有化构造器
 * 2.	.创建私有静态对象（因为方法静态）
 * 3.	.创建静态方法，以调用静态属性（在主方法中可以通过类直接调用此方法）
 * 特点：对象创建与类加载同步进行
 * 缺点：创建了对象，若没有使用，导致资源浪费---》懒汉式
 *
 * 单例模式之懒汉模式（步骤）
 * 1.	.私有化构造器
 * 2.	.创建私有静态对象
 * 3.	.创建成员方法
 * 特点：对象创建由用户通过调用方法来实现
 * 缺点：存在线程安全问题
 */

@SuppressWarnings({"all"})
public class ObjectOriented07_ {
    public static void main(String[] args) {
        System.out.println(Tiger.getObject().toString());
        System.out.println(House.getObject().toString());
    }
}

class Tiger{
    private String name;
    private int age;

    //    构造器私有化
    private Tiger(String name, int age) {
        this.name = name;
        this.age = age;
    }

    //    创建静态对象
    private static Tiger tiger = new Tiger("tom",3);

    //    创建静态方法返回创建的对象
    public static Tiger getObject(){
        return tiger;
    }

    @Override
    public String toString() {
        return "Tiger:{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

class House{
    private String address;
    private double price;

    //    构造器私有化
    private House(String address, double price) {
        this.address = address;
        this.price = price;
    }

    //    创建静态对象（未初始化）
    private static House house;

    //    创建对象
    public static House getObject(){
        if (house == null){
            house = new House("jackson",16);
        }
        return house;
    }

    @Override
    public String toString() {
        return "House:{" +
                "address='" + address + '\'' +
                ", price=" + price +
                '}';
    }
}
