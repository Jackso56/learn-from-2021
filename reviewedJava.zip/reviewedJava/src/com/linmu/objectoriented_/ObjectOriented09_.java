package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 抽象类和抽象方法（abstract）
 * 抽象类的使用细节：
 * 1.	抽象类不能被实例化
 * 2.	抽象类不一定包含抽象方法
 * 3.	抽象方法所在的类一定是抽象类
 * 4.	abstract只能修饰类和方法
 * 5.	抽象类仍然是一个类
 * 6.	抽象方法没有方法体，即 不能实现
 * 7.	如果一个类想要继承一个抽象类，那这个类必须是一个抽象类，或者该类实现抽象类的所有抽象方法
 * 8.	抽象方法不能用private，final，static来修饰，因为这3个关键字与重写相违背
 **/
@SuppressWarnings({"all"})
public class ObjectOriented09_ {
    public static void main(String[] args) {
        Lion lion = new Lion();
        lion.cry();
    }
}
abstract class Animals{
    void cry(){}
    void eat(){}
    void run(){}
}
class Lion extends Animals{
    @Override
    void cry() {
        System.out.println("河东狮吼...");
    }

    @Override
    void eat() {
        System.out.println("狮子捕食...");
    }
}
