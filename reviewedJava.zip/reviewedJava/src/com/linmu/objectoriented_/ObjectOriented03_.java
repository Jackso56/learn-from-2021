package com.linmu.objectoriented_;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

/***
 * 面向对象之继承：继承父类的属性、方法、构造器
 * 优点：减少代码冗余，
 *       提高代码复用性、扩展性、维护性
 */
@SuppressWarnings({"all"})
public class ObjectOriented03_ {
    public static void main(String[] args) {
        Human teacher = new Teacher("Jackson",29,10000,"330601");
        System.out.println("teacher信息：" + teacher.toString());
    }
}

@SuppressWarnings({"all"})
class Human{
    private String name;
    private int age;

    public Human(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Human{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

@SuppressWarnings({"all"})
class Teacher extends Human{
    private double salary;
    private String workId;

    public Teacher(String name,int age,double salary,String workId){
        super(name,age);
        this.salary = salary;
        this.workId = workId;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getWorkId() {
        return workId;
    }

    public void setWorkId(String workId) {
        this.workId = workId;
    }

    @Override
    public String toString() {
        return "Teacher{" + super.toString() +
                "salary=" + salary +
                ", workId='" + workId + '\'' +
                '}';
    }
}

@SuppressWarnings({"all"})
class Headteacher extends Human{
    private double salary;
    private String workId;
    private double bonus;

    public Headteacher(String name,int age,double salary,String workId,double bonus){
        super(name,age);
        this.salary = salary;
        this.workId = workId;
        this.bonus = bonus;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public String getWorkId() {
        return workId;
    }

    public void setWorkId(String workId) {
        this.workId = workId;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    @Override
    public String toString() {
        return "Headteacher{" + super.toString() +
                "salary=" + salary +
                ", workId='" + workId + '\'' +
                ", bonus=" + bonus +
                '}';
    }
}

