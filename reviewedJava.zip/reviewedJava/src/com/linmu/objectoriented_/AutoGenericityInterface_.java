package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 泛型接口
 * 接口基本语法：interface People <T>{}
 * 使用细节：
 * 1）静态成员不能使用泛型
 * 2）泛型接口的类型，是在接口继承或实现接口的时候确定的
 * 3）没有指定类型，默认为Object
 *
 *  泛型方法：
 *  1）可以定义在普通类和泛型类中
 *  2）泛型放在访问修饰符的后面
 *  3）泛型在方法调用是确定
 *
 *  泛型通配符：
 *  1）泛型不具备继承性
 *  2）<?>：支持任意泛型
 *  3）<? extends Student>：支持Student类及其子类，决定上限
 *  4）<? super Student>：支持Student类及其父类，不限于直接父类，决定下线
 **/
@SuppressWarnings({"all"})
public class AutoGenericityInterface_ {

}

//泛型接口
interface People <T>{
//    泛型方法
    <T> void get();
//    默认泛型方法
    default T method01(T t){
        return t;
    }
}

interface Man extends People<String>{

}

class Human1 implements People<String>{
    @Override
    public void get() {

    }
}
interface A{
    default String getname(String name){
        return name;
    }
}