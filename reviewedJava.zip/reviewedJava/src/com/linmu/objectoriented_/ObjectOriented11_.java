package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 接口使用细节：
 * 1.	接口无法实例化
 * 2.	接口中的所有方法都是默认public的，其中接口中的抽象方法可以不用abstract修饰
 * 3.	一个普通类实现接口，要实现该接口的所有方法  快捷键：alt+enter
 * 4.	抽象类实现接口，可以不用实现接口的方法
 * 5.	一个类可以同时实现多个接口
 * 6.	接口的属性只能是final的，且只能是public static final来修饰，必须初始化          （int number = 1; 等价于 public static final int number = 1;）
 * 7.	接口属性的访问形式：接口名.属性名
 * 8.	接口不能继承类，但可以继承其他的多个接口
 * 9.	接口的修饰符只能是public和默认修饰符来修饰，与类的修饰符规则一样
 *
 * 继承和接口的关系：可以理解为接口是对单继承机制的补充
 * 各自的优点：
 * 1.	继承：解决了代码的复用性和可维护性
 * 2.	接口：设计好各种规范（方法），让类取具体实现其功能，更加灵活，实现了代码解耦
 *
 * 接口的多态特性
 * 1.	接口类型的变量可以指向实现了接口的类的实例化对象
 * 2.	多态数组，接口类型的数组存放实现了该接口的类的实例化对象（设计向下转型）
 * 3.	接口的多态传递现象（对于实现接口，同时也要求实现该接口继承的接口的全部方法）
 **/
@SuppressWarnings({"all"})
public class ObjectOriented11_ {
    public static void main(String[] args) {
        H h = new H();
        System.out.println("接口Job中number的值为：" + h.number+1);
        System.out.println("接口Job中number的值为：" + Job.number+3);
        Job job = new H();
        System.out.println("接口Job中number的值为：" + job.number);
    }
}

interface Job{
//    接口属性必须赋值，修饰符只能是public final static
    public final static int number = 1;
//    接口自行实现方法只有default修饰的方法和静态方法
    default public void method01(){
        System.out.println("默认方法...");
    }
    public static void method02(){
        System.out.println("静态方法...");
    }
//    普通方法
    void method();
}

class H implements Job{
    @Override
    public void method() {
        System.out.println("重写Job接口的method方法...");
    }
}
