package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

/***
 * 访问修饰符的权限依次递减：本类，同包，子类，不同包
 * public, protected, 默认, private
 */
@SuppressWarnings({"all"})
public class ObjectOriented02_ {
    /***
     * 面向对象之封装：私有化属性
     * 优点：隐藏实现细节，
     *       对数据进行验证，保证数据安全合理
     */
    public static void main(String[] args) {
        Student1 student = new Student1("Jackson",18,"3301001");
        System.out.println("学生信息：" + student.toString());
    }
}

class Student1{
    private String name;
    private int age;
    private String id;

    public Student1(String name,int age,String id){
        setName(name);
        setAge(age);
        setId(id);
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getId() {
        return id;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", id='" + id + '\'' +
                '}';
    }
}