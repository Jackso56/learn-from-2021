package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 成员内部类
 * 简介：成员内部类是定义在外部类的成员位置上，并且没有static修饰
 * 特点：
 * 1.	成员内部类可以直接访问外部类的所有成员，包括私有的
 * 2.	可以添加任何访问修饰符（public、protect、默认、private）
 * 3.	其地位是一个成员
 * 4.	成员内部类的作用域：和其他成员一样是整个类体
 * 5.	成员内部类可以直接访问外部类的所有成员，包括私有的成员
 * 6.	外部类访问成员内部类的方式，在方法中创建对象，再调用方法
 * 7.	外部其他类访问成员内部类方式（2种）
 *      1)	外部类类名.内部类类名 对象名 = 外部类的对象名.new 内部类名()
 *       	Person.Student student = person.new Student();
 *      2)	在外部类中写一个方法，返回成员内部类的对象，并结合第一种方式来创建对象
 *      	Person.Student student = person.方法名;
 * 8.	如果内外部类的成员重名了，会遵守就近原则，如果想要访问外部类的成员，可以使用
 *      外部类名.this.成员名  的方式来访问
 **/
@SuppressWarnings({"all"})
public class ObjectOriented14_ {
    public static void main(String[] args) {
        // 创建对象方式一
        System.out.println("创建对象方式一...");
        CC cc = new CC("jack");
        CC.DD dd = cc.createDD();
        dd.method01();
//        创建对象方式二
        System.out.println("创建对象方式二...");
        CC.DD dd1 = cc.new DD();
        dd1.method01();
    }
}
class CC{
    public String name;

    public CC(String name) {
        this.name = name;
    }
    public DD createDD(){
        DD dd = new DD();
        return dd;
    }

    public void method(){
        System.out.println("CC method()...");
    }

    class DD{
        public String id;
        public void method01(){
            System.out.println("DD method01()...");
        }
    }
}

