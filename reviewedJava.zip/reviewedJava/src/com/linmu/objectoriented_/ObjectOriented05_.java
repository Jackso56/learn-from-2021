package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

/***
 * 静态变量、静态方法
 * 类方法（静态方法）不能使用this和super关键字，而成员方法（普通方法）
 * 可以使用this和super关键字
 */


@SuppressWarnings({"all"})
public class ObjectOriented05_ {
    public static void main(String[] args) {
        Cat1 tom = new Cat1("tom", 3);
        for (int i = 0; i < 4; i++) {
            tom.counter();
        }
        System.out.println("count的值：" + tom.getCount());
    }
}

class Cat1{
//    非静态属性
    private String name;
    private int age;
//    静态属性
    private static int count = 0;

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public static int getCount() {
        return count;
    }

    public Cat1(String name, int age) {
        this.name = name;
        this.age = age;
    }

//    非静态方法可以访问静态成员和非静态成员
    public void method(){
        System.out.println("非静态方法被调用...");
    }

//    静态方法可以访问静态成员
    public static int counter(){
        return count ++;
    }
}
