package com.linmu.objectoriented_;

import org.testng.annotations.Test;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 匿名内部类：(本质：是一个类,一个内部类,没有类名[类名在系统底层,由系统来创建],也是一个对象) (仅仅使用一次)
 *           类仅仅使用一次,对象可以反复使用
 * 简介：定义在外部类的局部位置上，比如方法中、代码块中，没有类名（仅仅使用一次）
 * 使用细节
 * 1.	匿名内部类既是类的定义，它本身又是一个对象，因此它既有类的特征，又有对象的特征，其调用方法的方式也有两种
 * 2.	匿名内部类可以直接访问外部类的全部成员，包括私有属性
 * 3.	匿名内部类不能使用访问修饰符，其地位是一个局部变量
 * 4.	匿名内部类的作用域：仅仅在定义它的方法或代码块中
 * 5.	外部其他类不能访问匿名内部类
 * 6.	当外部类成员和内部类成员重名时，遵循就近原则，若要访问外部的成员，则可以使用类名.this.成员名  的方式来调用
 * 作用：当做实参直接传递，简洁高效
 * 优点：可以根据需求而重写方法的方式满足不同的需求，且只会影响当前对象，灵活性较高
 **/
@SuppressWarnings({"all"})
public class ObjectOriented13_ {
    public static void main(String[] args) {
        System.out.println("基于接口的匿名内部类");
        // 基于接口的匿名内部类
        new IA() {
            @Override
            public void Job() {
                System.out.println("基于接口的匿名内部类的方法重写...方式1");
            }
        }.Job();
        IA teacher = new IA() {
            @Override
            public void Job() {
                System.out.println("基于接口的匿名内部类的方法重写...方式2");
            }
        };
        /**
         * 底层更具体实现
         * class Xxxxx implements IA{
         *  @Override
         *  public void Job() {
         *  System.out.println("My job is teacher...");
         *  }
         * }
         */
        teacher.Job();
        System.out.println("teacher的运行类型：" + teacher.getClass());
        // 基于类的匿名内部类
        System.out.println("基于类的匿名内部类");
        new Person_(){
            @Override
            public void anonMethod(){
                System.out.println("基于类的匿名内部类的方法...方式1");
            }
        }.anonMethod();
        Person_ person_ = new Person_(){
            @Override
            public void anonMethod(){
                System.out.println("基于类的匿名内部类的方法...方式2");
            }
        };
        /**
         * 底层实现
         * class Xxxxx extends Person_{
         *     @Override
         *     public void anonMethod(){
         *      System.out.println("基于类的匿名内部类的方法...");
         *     }
         * }
         */
        person_.anonMethod();
        System.out.println("person_的运行类型：" + person_.getClass());
        System.out.println("基于抽象类的匿名内部类");
        new Teachers() {
            @Override
            void teach() {
                System.out.println("基于抽象类的匿名内部类的方法...方式1");
            }
        }.teach();
        Teachers teachers = new Teachers() {
            @Override
            void teach() {
                System.out.println("基于抽象类的匿名内部类的方法...方式2");
            }
        };
        /**
         * 底层实现
         * class Xxxxx extends Teachers{
         *     @Override
         *     void teach() {
         *      System.out.println("基于抽象类的匿名内部类的方法...");
         *     }
         * }
         */
        teachers.teach();
        System.out.println("teachers的运行类型：" + teachers.getClass());
    }
}
interface IA{
    void Job();
}
class Person_{
    public void anonMethod(){

    }
}
abstract class Teachers{
    abstract void teach();
}


