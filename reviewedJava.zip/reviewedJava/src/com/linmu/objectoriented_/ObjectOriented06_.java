package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

/***
 * 静态和非静态代码块
 * 存在继承关系下的创建子类对象，代码块等的调用顺序
 * a)	父类静态代码块和静态变量，二者定义顺序决定调用顺序
 * b)	子类静态代码块和静态变量，二者定义顺序决定调用顺序
 * c)	父类非静态代码块和非静态变量，二者定义顺序决定调用顺序
 * d)	父类构造器
 * e)	子类非静态代码块和非静态变量，二者定义顺序决定调用顺序
 * f)	子类构造器
 */
@SuppressWarnings({"all"})
public class ObjectOriented06_ {
    public static void main(String[] args) {
        Rabbit mike = new Rabbit("Mike", 2, 5);
    }
}

class Animal{

    static{
        System.out.println("Animal调用静态代码块...");
    }

    {
        System.out.println("Animal调用非静态代码块...");
    }
    private String name;
    private int age;

    public Animal(String name, int age) {
        this.name = name;
        this.age = age;
        System.out.println("Animal构造器被调用...");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void method(){
        System.out.println("Animal非静态方法被调用...");
    }
    public static void method3(){
        System.out.println("Animal静态方法被调用...");
    }
}

class Rabbit extends Animal{
    static{
        System.out.println("Rabbit调用静态代码块...");
    }

    {
        System.out.println("Rabbit调用非静态代码块...");
    }

    private double weight;

    public Rabbit(String name,int age,double weight){
        super(name,age);
        this.weight = weight;
        System.out.println("Rabbit构造器被调用...");
    }

    public void method1(){
        System.out.println("Rabbit非静态方法被调用...");
    }

    public static void method2(){
        System.out.println("Rabbit静态方法被调用...");
    }
}
