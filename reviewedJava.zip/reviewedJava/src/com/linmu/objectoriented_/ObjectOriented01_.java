package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class ObjectOriented01_ {
    public static void main(String[] args) {
        Person person = new Person("jack", 18);
        Person person1;
        person1 = person;
        System.out.println("年龄：" + person1.age);
        System.out.println("递归结果：" + person.result(2));
        System.out.println("方法重载：" + person.result(3, 4));
        System.out.println("方法处理后的值：" + person.createObject());
        System.out.println("方法处理后的值：" + person.name);
    }
}

class Person {
    //字段
    public String name;
    public int age;

    //    无参构造器，构造器也存在重载的现象
    public Person(String jackson, int i, String s) {

    }

    //    构造器
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    //    递归方法
    public int result(int number) {
        if (number < 10) {
            return result(number + 1);
        } else {
            return number;
        }
    }
    @SuppressWarnings({"all"})
    //    方法重载，可变参数
    public int result(int number1, int number2) {
        return number1 > number2 ? number1 : number2;
    }

    public int createObject() {
        this.name = "jackson"; // this关键字访问字段
        return this.result(9); // this关键字访问方法
    }

}
