package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * final关键字的使用(无法修改)：
 * 修饰类、成员，不能修饰构造器
 **/
@SuppressWarnings({"all"})
public class ObjectOriented08_ {
    public static void main(String[] args) {
        A1 a = new A1();
        System.out.println("MAX_NUMBER=" + a.MAX_NUMBER);
        a.method();
    }
}

// 类无法被继承
final class A1{
    //    MAX_NUMBER的值无法被修改，即 MAX_NUMBER 变成了常量
//    final和static往往一起使用
    public final static int MAX_NUMBER = 10;
    //    method方法无法被重写
    public final void method(){
        System.out.println("final关键字修饰方法...");
    }
}

/***
 1.	final修饰的属性又叫常量,一般全部大写，中间用下划线隔开
 2.	final修饰的属性可以在以下几个位置赋值（非静态属性）
 1)	定义属性时
 2)	代码块中
 3)	构造器中
 3.	final修饰的属性可以在以下几个位置赋值（静态属性）
 1)	定义属性时
 2)	静态代码块中
 */

class B{
    //    定义时传值
    private final int NUMBER = 1;
    //    代码块中传值
    private final int NUMBER1;
    //    构造器中传值
    private final int NUMBER2;

    {
        NUMBER1 = 2;
    }

    public B(int NUMBER2) {
        this.NUMBER2 = NUMBER2;
    }
}

class C{
    //    定义时传值
    private final static int NUMBER1 = 1;
    //    代码块中传值
    private final static int NUMBER2;

    static{
        NUMBER2 = 2;
    }
}
