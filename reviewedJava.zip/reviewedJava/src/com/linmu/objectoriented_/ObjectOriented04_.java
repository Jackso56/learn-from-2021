package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/


/***
 * 面向对象之多态:上下转型，方法调用机制
 * 向上转型只能调用父类方法，向下转型可以调用父类和子类的方法
 * 上下转型就是类的绑定（即编译类型的绑定）
 * 常用方法：==,equals,instanceof,hashCode
 */

@SuppressWarnings({"all"})
public class ObjectOriented04_ {
    public static void main(String[] args) {
        Dog dog = new Shepherd("tom",3,18,"China");
        System.out.println("牧羊犬详细信息：" + dog.toString());
        System.out.println(dog.getClass());
//        dog.

        Shepherd newdog = (Shepherd)dog;
//        newdog.get
    }
}

class Dog{
    private String name;
    private int age;

    public Dog(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Dog{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

class Shepherd extends Dog{
    private double weight;
    private String region;

    public Shepherd(String name,int age,double weight,String region){
        super(name,age);
        this.weight = weight;
        this.region = region;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @Override
    public String toString() {
        return "Shepherd{" + super.toString() +
                "weight=" + weight +
                ", region='" + region + '\'' +
                '}';
    }
}
