package com.linmu.objectoriented_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 静态内部类
 * 简介：成员内部类是定义在外部类的成员位置上，并且有static修饰
 * 使用细节：
 * 1.	静态内部类可以直接访问外部类的全部静态成员，包括私有的，但不能访问非静态成员
 * 2.	静态内部类地位是一个成员，可以任意加访问修饰符（public、protect、默认、private）
 * 3.	静态内部类的作用域是整个外部类的类体
 * 4.	静态内部类可以直接访问外部类的全部静态成员
 * 5.	外部类访问静态内部类，创建对象之后再访问（可以以方法为媒介）
 * 6.	外部其他类访问静态内部类
 * 7.	当外部类和静态内部类的静态成员重名时，遵循就近原则，
 *      可以通过外部类名.成员名的方式来访问外部静态成员
 **/
@SuppressWarnings({"all"})
public class ObjectOriented15_ {
    public static void main(String[] args) {
        EE ee = new EE();
        EE.FF ff = ee.method03();
        ff.method();
    }
}
class EE{
    public static int age;
    public void method01(){
        System.out.println("EE  method01...");
    }

    public static void method02(){
        System.out.println("EE  method02...");
    }

    static class FF{
        public static int prize;
        public void method(){
            System.out.println("FF method...");
        }
    }
    @SuppressWarnings({"all"})
    public FF method03(){
        FF ff = new FF();
        return ff;
    }
}