package com.linmu.paper_.java_12_16;

import java.util.Calendar;

/**
 * @author 03 严林
 * @version The past cannot be redeemed, the future can be changed.
 * @CreateTime 2022/12/16 10:22:35
 **/
@SuppressWarnings({"all"})
public class Code01 {

    public static void main(String[] args) {
        Coding01 coding01 = new Coding01();
        Thread thread = new Thread(coding01);
        thread.start();
    }

    public static class Coding01 implements Runnable{
        @Override
        public void run() {
            long start = System.currentTimeMillis();
            while ((System.currentTimeMillis() - start)/1000 <= 3){
                Calendar now = Calendar.getInstance();
                System.out.println(now.get(Calendar.HOUR)+ "-" + now.get(Calendar.MINUTE) +
                        "-" +now.get(Calendar.SECOND));
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    throw new RuntimeException(e);
                }
            }
            System.out.println(Thread.currentThread().getName() +
                    "is over...\treturn main thread");
        }
    }
}
