package com.linmu.paper_.java_12_16;/**
* @author Jackson Black
* @version The past cannot be redeemed, the future can be changed.
* @CreateTime 2022/12/16 10:45:22
**/
@SuppressWarnings({"all"})
public class Code02 {
    public static void main(String args[]){
        Road road = new Road();
        Thread police,driver;
        police = new Thread(road);
        driver = new Thread(road);
        police.setName("妈妈");
        driver.setName("儿子");
        road.setAttachThread(driver);
        driver.start();
        police.start();
    }
}

class Road implements Runnable{

    Thread attachThread;

    public void setAttachThread(Thread attachThread) {
        this.attachThread = attachThread;
    }

    @Override
    public void run() {
        String name = Thread.currentThread().getName();
        if(name.equals("儿子")){
            try {
                System.out.println("我是"+name+"在睡觉.");
                System.out.println("想睡上一个小时后起床");
                Thread.sleep(1000*60*60);
            }catch (Exception e){
                System.out.println(name+"被妈妈叫醒了");
            }
            System.out.println(name+"起床");
        }
        else if(name.equals("妈妈")){
            for(int i = 1;i<=3;i++){
                System.out.println(name+"喊：起床！");
                try{
                    Thread.sleep(50);
                }catch (Exception e){

                }
            }
            attachThread.interrupt();//吵醒driver
        }
    }
}


