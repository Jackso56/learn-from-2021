package com.linmu.paper_.work11_4.problem3;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public interface Calculate {
    public double calculate(double length, double width);
}
