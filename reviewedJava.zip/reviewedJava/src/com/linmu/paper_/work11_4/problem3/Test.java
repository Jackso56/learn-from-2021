package com.linmu.paper_.work11_4.problem3;

/**
 * @author 林沐 --- 22 cnp
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Test {
    public static void main(String[] args) {
        Calculate calculate = new Calculate(){
            @Override
            public double calculate(double length, double width) {
                return length * width;
            }
        };
        System.out.println(calculate.calculate(14, 17));

    }
}
