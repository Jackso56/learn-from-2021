package com.linmu.paper_.work11_4.problem2;
/**
 * @author 林沐 --- 22 cnp
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Test {
    public static void main(String[] args) {
        Triangle triangle = new Triangle() {
            @Override
            public void calculate(double width, double height) {
                System.out.println("area=" + (width * height) / 2);
            }
        };
        IsoscelesTriangle isoscelesTriangle = new IsoscelesTriangle();
        triangle.calculate(13, 13);
    }
}
