package com.linmu.paper_.work11_4.problem2;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Triangle {

    private double width;
    private double height;

    public Triangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public Triangle() {

    }

    public void printInfo() {
        System.out.println( "Triangle{" +
                "width=" + width +
                ", height=" + height +
                '}');
    }

    public void calculate(double width, double height){
        System.out.println();
    }

}
