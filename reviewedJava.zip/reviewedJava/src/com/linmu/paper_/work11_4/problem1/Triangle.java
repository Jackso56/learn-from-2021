package com.linmu.paper_.work11_4.problem1;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/

// TODO: 2022/11/4

@SuppressWarnings({"all"})
public class Triangle {
    private double width;
    private double height;

    public Triangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    public void printInfo() {
        System.out.println( "Triangle{" +
                "width=" + width +
                ", height=" + height +
                '}');
    }

    public void isoscelesRightTriangle(){
        class IsoscelesRightTriangle{
            private double width;
            private double height;

            public IsoscelesRightTriangle(double width, double height) {
                this.width = width;
                this.height = height;
            }


            public void printInfo() {
                System.out.println( "IsoscelesRightTriangle{" +
                        "width=" + width +
                        ", height=" + height +
                        '}');
            }
        }
        IsoscelesRightTriangle isoscelesRightTriangle = new IsoscelesRightTriangle(31, 37);
        isoscelesRightTriangle.printInfo();
    }
}
