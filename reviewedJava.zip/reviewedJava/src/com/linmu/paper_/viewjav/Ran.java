package com.linmu.paper_.viewjav;

import java.util.Random;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
@SuppressWarnings({"all"})
public class Ran {
    public static void main(String[] args) {
        Random random = new Random();
        int i = random.nextInt(100);
        System.out.println(i);
        String string = new String();
    }
}
