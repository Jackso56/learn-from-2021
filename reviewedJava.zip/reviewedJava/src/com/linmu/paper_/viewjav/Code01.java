package com.linmu.paper_.viewjav;

import com.google.common.base.Supplier;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
@SuppressWarnings({"all"})
public class Code01 {
    public static void main(String[] args) throws ParseException {
        Date date = new Date();
        // Date 转 毫秒
        System.out.println(date.getTime());
        String str = "2000-2-29 12-12-34-456 ";
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
        // str转Date
        Date date1 = sdf.parse(str);
        System.out.println(date1);
//        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
//        System.out.println(sdf1.format(str));

    }
}

interface AI {
//    void me();

    void me(int a,int b);
}
