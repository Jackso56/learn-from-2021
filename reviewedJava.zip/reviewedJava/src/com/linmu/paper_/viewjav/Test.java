package com.linmu.paper_.viewjav;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Test {
    public static void main(String[] args) {
//        DD dd = new DD{
//
//        };
    }
}
