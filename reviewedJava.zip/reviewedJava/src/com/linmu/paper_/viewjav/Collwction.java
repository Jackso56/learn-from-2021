package com.linmu.paper_.viewjav;

import org.testng.annotations.Test;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
// TODO: 2022/11/5
@SuppressWarnings({"all"})
public class Collwction {
    public static void main(String[] args) {
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("jack",1);
        hashMap.put("jackson",2);
        hashMap.put("mike",3);
        hashMap.put("jhon",4);
        System.out.println(hashMap.containsKey("jack"));
        System.out.println(hashMap.containsValue(3));
        System.out.println(hashMap.isEmpty());

        System.out.println(hashMap.get("jack"));
        System.out.println(hashMap.size());
        System.out.println(hashMap.values());
        System.out.println(hashMap.keySet());
        System.out.println("获取值的方式一：");
        Set<Map.Entry<String, Integer>> entries = hashMap.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            System.out.println(entry.getKey() + "\t" + entry.getValue());
        }
        System.out.println("获取值的方式二：");
        Set<String> strings = hashMap.keySet();
        for (String string : strings) {
            System.out.println(string + "\t" + hashMap.get(string));
        }
    }

    @Test
    public void review2(){
//
//         * List接口基本方法：add(),addAll(),   增加元素
//                *                   remove(),  删除元素
//                *                   set(), 修改元素
//                *                   get(),subList(),indexOf(),lastIndexOf()    查找元素
        ArrayList<Object> objects = new ArrayList<>();
        objects.add(1);
        objects.add(2);
        objects.add(3);
        objects.add(4);
        objects.add(5);
        objects.remove(4);
        objects.set(0,3);
        System.out.println(objects.get(0));
        System.out.println(objects.subList(0,2));
        System.out.println(objects.indexOf(3));
        System.out.println(objects.lastIndexOf(3));
        System.out.println(objects);
        System.out.println("迭代器遍历元素：");
        Iterator<Object> iterator = objects.iterator();
        while (iterator.hasNext()){
            System.out.println(iterator.next());
        }
        System.out.println("增强for循环遍历元素：");
        for (Object object : objects) {
            System.out.println(object);
        }
    }

    @Test
    public void collection__(){
        ArrayList objects = new ArrayList();
        objects.add(1);
        objects.add(2);
        objects.add(3);
        objects.add(4);
        objects.add(5);
        ArrayList object = new ArrayList();
        objects.add(7);
        objects.add(8);

        System.out.println(Collections.max(objects));
        System.out.println(Collections.min(objects));
        Collections.shuffle(objects);
        System.out.println(objects);
        Collections.sort(objects);
        System.out.println(objects);
        Collections.copy(objects,object);
        System.out.println(objects);
        Collections.swap(objects,3,0);
        System.out.println(objects);
    }
}
