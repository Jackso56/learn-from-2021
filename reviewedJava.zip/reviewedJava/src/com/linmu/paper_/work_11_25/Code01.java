package com.linmu.paper_.work_11_25;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
@SuppressWarnings({"all"})
public class Code01 {
    public static void main(String[] args) {

    }
}
