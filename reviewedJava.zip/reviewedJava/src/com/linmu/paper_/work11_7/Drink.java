package com.linmu.paper_.work11_7;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public abstract class Drink {

    public static final int MILK = 1;
    public static final int COFFEE = 2;
    public static final int BEER = 3;

    abstract void taste();

}
