package com.linmu.paper_.work11_7;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class DrinkNotFoundException extends RuntimeException{
    public DrinkNotFoundException(String message) {
        super(message);
    }

    public DrinkNotFoundException() {

    }

    @Override
    public void printStackTrace() {
        super.printStackTrace();
    }
}
