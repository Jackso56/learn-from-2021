package com.linmu.paper_.work11_7;

import java.util.Scanner;

/**
 * @author 林沐 --- 22 cnp
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Test {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("输入饮品编号：");
        int drinkType = scanner.nextInt();
        switch (drinkType){
            case 1:
                Milk milk = new Milk();
                milk.taste();
                break;
            case 2:
                Coffee coffee = new Coffee();
                coffee.taste();
                break;
            case 3:
                Beer beer = new Beer();
                beer.taste();
                break;
            default:
                throw new DrinkNotFoundException("\n未找到该饮品...");
        }
    }
}
