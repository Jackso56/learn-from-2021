package com.linmu.paper_.work11_7;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Milk extends Drink{
    @Override
    void taste() {
        System.out.println("味道-奶香...");
    }

}
