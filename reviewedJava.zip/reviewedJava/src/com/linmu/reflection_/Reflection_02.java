package com.linmu.reflection_;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
/**
getDeclaredConstructor(String.class,int.class,args.class...) --> 获取任意定义的构造器，需要传入相应的参数
getConstructor(String.class,int.class,args.class...) --> 只能获取public类型的构造器
getDeclaredConstructors() --> 获取已经定义的所有构造器，返回一个数组
 */
@SuppressWarnings({"all"})
public class Reflection_02 {
    public static void main(String[] args) throws Exception {
        Class<?> aClass = Class.forName("com.linmu.reflection_.Student");
        // 获取构造器,参数类型也要求一致
        Constructor<?> declaredConstructor = aClass.getDeclaredConstructor(
                String.class, int.class);
        // 设置访问权限，使用有参构造器创建对象
        Object jackson = declaredConstructor.newInstance("jackson", 12);
        System.out.println("有参构造器：" + declaredConstructor);
        // 获取构造器的几种方法:public构造器，所有构造器，构造器个数（返回数组）
        Constructor<?> constructor = aClass.getConstructor();
        System.out.println("无参构造器：" + constructor);
        Constructor<?> declaredConstructor1 = aClass.getDeclaredConstructor();
        System.out.println("无参参构造器：" + declaredConstructor1);
        Constructor<?>[] declaredConstructors = aClass.getDeclaredConstructors();
        for (int i = 0; i < declaredConstructors.length; i++) {
            System.out.println( "所有定义的构造器：" + declaredConstructors[i]);
        }
    }
}
