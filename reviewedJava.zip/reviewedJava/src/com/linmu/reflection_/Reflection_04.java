package com.linmu.reflection_;

import org.testng.annotations.Test;

import java.lang.reflect.Method;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
@SuppressWarnings({"all"})
public class Reflection_04 {
    public static void main(String[] args) throws Exception {
        Class<?> aClass = Class.forName("com.linmu.reflection_.Student");
        Student jackson = (Student)aClass.newInstance();
        // 获取方法
        Method setAge = aClass.getMethod("setAge", int.class);
        // 设置参数
        Object invoke = setAge.invoke(jackson, 12);
        System.out.println(jackson.getAge());
    }

    // 获取方法的几种方法
    @Test
    public void getMe() throws Exception{
        Class<?> aClass = Class.forName("com.linmu.reflection_.Student");
        Student jackson = (Student)aClass.newInstance();
        // 获取public方法
        Method setAge = aClass.getMethod("setAge", int.class);
        System.out.println("获取public方法：" + setAge);
        // 获取所有public方法,包含父类方法
        Method[] methods = aClass.getMethods();
        for (Method method : methods) {
            System.out.println(method);
        }
        // 获取已定义方法
        Method declaredMethod = aClass.getDeclaredMethod("getName");
        System.out.println("获取已定义方法：" + declaredMethod);
        // 获取所有已定义方法,不含父类方法
        Method[] declaredMethods = aClass.getDeclaredMethods();
        for (Method method : declaredMethods) {
            System.out.println(method);
        }
    }
}
