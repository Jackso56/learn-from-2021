package com.linmu.reflection_;

import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
@SuppressWarnings({"all"})
public class Reflection_03 {
    public static void main(String[] args) throws Exception{
        Class<?> aClass = Class.forName("com.linmu.reflection_.Student");
        Constructor<?> constructor = aClass.getConstructor();
        // 获取属性创建必须创建对象
        Student jackson = (Student)constructor.newInstance();
        Field field = aClass.getDeclaredField("name");
        // 设置属性时,设置访问权限
        field.setAccessible(true);
        // set(Object o, args a)
        field.set(jackson,"jack");
        System.out.println(jackson.getName());
    }

    // 获取属性的几种方法
    @Test
    public void getFeild_() throws Exception{
        Class<?> aClass = Class.forName("com.linmu.reflection_.Student");
        Constructor<?> constructor = aClass.getConstructor();
        Student jackson = (Student)constructor.newInstance();
        // 获取public属性
        Field id = aClass.getField("id");
        id.set(jackson,12);
        System.out.println(jackson.getId());
        // 获取所有public属性
        Field[] fi = aClass.getFields();
        for (int i = 0; i < fi.length; i++) {
            System.out.println(fi[i]);
        }
        // 获取已定义的属性
        Field name = aClass.getDeclaredField("name");
        name.setAccessible(true);
        name.set(jackson,"jack");
        System.out.println(jackson.getName());
        // 获取已定义的属性 --> 返回数组
        Field[] declaredFields = aClass.getDeclaredFields();
        for (int i = 0; i < declaredFields.length; i++) {
            System.out.println(declaredFields[i]);
        }

    }

}
