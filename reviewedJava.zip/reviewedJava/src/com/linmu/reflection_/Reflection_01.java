package com.linmu.reflection_;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/

// 反射：在程序运行时动态加载类并获取类的详细信息，从而操作类
//    属性和方法，本质是JVM得到class对象之后，在通过class对象进行反编译，从而获取对象的各种信息
@SuppressWarnings({"all"})
public class Reflection_01 {
    public static void main(String[] args) throws Exception{
        // 加载类
        Class<?> aClass = Class.forName("com.linmu.reflection_.Student");
        // 创建对象
        Object o = aClass.newInstance();
        System.out.println(o);
    }
}
