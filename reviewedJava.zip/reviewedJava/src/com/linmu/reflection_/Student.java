package com.linmu.reflection_;

/**
 * @author 苏御
 * @version 流苏飘动，冯虚御风
 **/
@SuppressWarnings({"all"})
public class Student {
//    public static void main(String[] args) {
//        Student student = new Student();
//        System.out.println(student.getClass());
//    }
    private String name;
    private int age;
    public int id;
    public String adress;
    public Student(){

    }
    public Student(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAdress() {
        return adress;
    }

    public void setAdress(String adress) {
        this.adress = adress;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
