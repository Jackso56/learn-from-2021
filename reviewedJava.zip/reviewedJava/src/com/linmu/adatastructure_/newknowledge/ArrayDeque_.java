package com.linmu.adatastructure_.newknowledge;


import org.testng.annotations.Test;

import java.util.ArrayDeque;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * ArrayDeque的特性----可以创建栈、堆、队列  （左头右尾）
     * deque（double-ended queue）双端队列，是一种具有队列和栈的性质的数据结构。
     * 双端队列中的元素可以从两端弹出，其限定插入和删除操作在表的两端进行。假设两端分别为端点A和端点B，在实际应用中：
     *
     * 可以有输出受限的双端队列（即端点A允许插入和删除，端点B只允许插入的双端队列）；
     * 可以有输入受限的双端队列（即端点A允许插入和删除，端点B只允许删除的双端队列）；
     * 如果限定双端队列从某个端点插入的元素只能从该端点删除，则该双端队列就蜕变为两个栈底相邻的栈；
     * 可调整大小的数组的实现的Deque接口。
     * 数组deques没有容量限制; 他们根据需要增长以支持使用。
     * 它们不是线程安全的; 在没有外部同步的情况下，它们不支持多线程的并发访问。
     * 零元素被禁止。 当用作堆栈时，此类可能会比Stack快，并且当用作队列时速度高于LinkedList 。
 * 构造方法
     * ArrayDeque()
     * 构造一个空数组deque，初始容量足以容纳16个元素。
     * ArrayDeque(Collection<? extends E> c)
     * 构造一个包含指定集合元素的deque，按照它们由集合的迭代器返回的顺序。
     * ArrayDeque(int numElements)
     * 构造一个空数组deque，初始容量足以容纳指定数量的元素。
 *
//public interface Deque<E> extends java.util.Queue<E> {
///**
// * 添加元素
// */
/*

双端队列：添加元素，删除元素，取元素（双端队列也可以当做栈来使用）

添加元素
在队列前边 添加元素，返回是否添加成功
boolean offerFirst( E e);
在队列后边 添加元素，返回是否添加成功
        boolean offerLast( E e);
在队列前边 添加元素
        void addFirst(E e);
在队列后边添加元素
        void addLast( E e);
向队列中添加一个元素。若添加成功则返回true；若因为容量限制添加失败则返回false是。
        boolean offer(E e);
向队列中添加一个元素。若添加成功则返回true；若因为容量限制添加失败，则抛出IllegalStateException异常。
        boolean add(E e);


删除元素
删除第一个元素，返回删除元素的值；如果元素为null，将返回null；
        E pollFirst();
删除最后一个元素，返回删除元素的值；如果为null，将返回null；
        E pollLast();
删除第一个元素，返回删除元素的值；如果元素为null，将抛出异常；
        E removeFirst();
删除最后一个元素，返回删除元素的值；如果为null，将抛出异常；
        E removeLast();
删除第一次出现的指定元素
        boolean removeFirstOccurrence( java.lang.Object o);
删除最后一次出现的指定元素
        boolean removeLastOccurrence( java.lang.Object o);
删除队列头的元素，如果队列为空，则返回null；
        E poll();
删除队列头的元素，如果队列为空，则抛出异常；
        E remove();


取数据
获取第一个元素，没有返回null；
        E peekFirst();
获取最后一个元素，没有返回null；
        E peekLast();
获取第一个元素,如果没有则抛出异常;
        E getFirst();
获取最后一个元素，如果没有则抛出异常；
        E getLast();
返回队列头的元素，如果队列为空，则返回null；
        E peek();
返回队列头的元素，如果队列为空，将抛异常；
        E element();


栈方法
栈顶添加一个元素
        void push( E e);
移除栈顶元素,如果栈顶没有元素将抛出异常
        E pop();
        }
*/
@SuppressWarnings({"all"})
public class ArrayDeque_ {
    public static void main(String[] args) { // 队列
        // 扩容机制：初始化16，按两倍扩容
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        for (int i = 0; i < 10; i++) {
            queue.offer(i);
        }
//        普通for循环无效，原因未知
//        for (Integer integer : queue) {
//            System.out.println(queue.remove());
//        }
        for (Integer integer : queue) {
            System.out.println(queue.poll());
        }
    }

    @Test
    public void method_01(){ // 队列
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        for (int i = 0; i < 10; i++) {
            queue.add(i);
        }
        for (int i = 0; i < queue.size(); i++) {
            System.out.println(queue.remove());
        }
//        普通for循环无效，原因未知
//        for (Integer integer : queue) {
//            System.out.println(queue.remove());
//        }
    }

    @Test
    public void method_02(){
        ArrayDeque<Integer> deque = new ArrayDeque<>();
        for (int i = 0; i < 10; i++) {
            deque.push(i);
        }
//        普通for循环无效，原因未知
//        for (int i = 0; i < deque.size(); i++) {
//            System.out.println(deque.remove());
//        }
        for (Integer integer : deque) {
            System.out.println(deque.pop());
        }
    }

    @Test
    public void method_03(){
        ArrayDeque<Integer> integers = new ArrayDeque<>();
        integers.push(12);
        integers.push(13);
        integers.push(14);
        integers.push(15);
        System.out.println(integers.peekFirst());
        System.out.println(integers.peekLast());
    }
}

