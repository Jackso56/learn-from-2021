package com.linmu.adatastructure_.practice_offer_;

import java.util.ArrayDeque;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构：栈
 * <p>
 * 剑指 Offer 30. 包含 min 函数的栈
 * <p>
 * 定义栈的数据结构，请在该类型中实现一个能够得到栈的最小元素的 min 函数在该栈中，
 * 调用 min、push 及 pop 的时间复杂度都是 O(1)。
 * <p>
 * 示例:
 * <p>
 * MinStack minStack = new MinStack();
 * minStack.push(-2);
 * minStack.push(0);
 * minStack.push(-3);
 * minStack.min();   --> 返回 -3.
 * minStack.pop();
 * minStack.top();      --> 返回 0.
 * minStack.min();   --> 返回 -2.
 **/
@SuppressWarnings({"all"})
public class Practice_06 {
}

@SuppressWarnings({"all"})

// 思路1：借助辅助栈实现：
class MinStack {

    ArrayDeque<Integer> A;
    ArrayDeque<Integer> B;

    /**
     * initialize your data structure here.
     */
    public MinStack() {
        A = new ArrayDeque<>();
        B = new ArrayDeque<>();
    }

    public void push(int x) {
        A.push(x);
        if (B.isEmpty() || B.peekFirst() >= x) {
            B.push(x);
        }
    }

    public void pop() {
        /*
        错误代码：查栈A为主站，包含着所有元素，调用pop时对于栈A一定会实现元素的剔除
          对于辅助栈B，包含着非严格排序的部分元素，调用pop时不一定会实现元素的剔除
        if (A.peekFirst().equals(B.peekFirst())){
            B.pop();
            A.pop();
        }
        */
        if (A.pop().equals(B.peekFirst())){
            B.pop();
        }
    }

    public int top() {
        return A.peekFirst();
    }

    public int min() {
        return B.peekFirst();
    }
}
