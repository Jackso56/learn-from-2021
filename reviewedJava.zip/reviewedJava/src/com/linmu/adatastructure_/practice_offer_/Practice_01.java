package com.linmu.adatastructure_.practice_offer_;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构--静态数组
 *
 * 剑指 Offer 05. 替换空格
 * 请实现一个函数，把字符串 s 中的每个空格替换成"%20"。
 *
 * 示例 1：
 * 输入：s = "We are happy."
 * 输出："We%20are%20happy."
 *
 **/
@SuppressWarnings({"all"})
public class Practice_01 {
    public static void main(String[] args) {
        String str = "hello word he";
        System.out.println(replaceSpace_03(str));
    }
    // 练习思路
    public String replaceSpace_01(String string) {
        return string.replace(" ", "%");
    }

    // 面试思路1（较差，内存消耗大）
    public String replaceSpace_02(String string) {
        // 字符串转数组
        char[] chars = string.toCharArray();
        // 创建可变数组
        StringBuffer stringBuffer = new StringBuffer();
         // 循环替换空格
        for (char aChar : chars) {
            if (aChar == ' ') {
                // append()方法可将String直接转为StringBuffer
                stringBuffer.append("%20");
            } else {
                stringBuffer.append(aChar);
            }
        }
//        return new String(stringBuffer);
        return stringBuffer.toString();
    }

    // 面试思路2(优解,内存消耗小）
    public static String replaceSpace_03(String string){
        // 获取字符串长度
        int length = string.length();
        // 根据字符串长度创建数组
        char[] chars = new char[3 * length];
        // 循环替换空格存入chars数组中
        char ch = ' ';
        int size = 0;
        for (int i = 0; i < length; i++) {
            ch = string.charAt(i);
            if(ch == ' '){
                // ++ 的前置和后置不一样
                chars[size++] = '%';
                chars[size++] = '2';
                chars[size++] = '0';
            }else {
                chars[size++] = ch;
            }
        }
        // 创建字符串，使用String(char[] ch,int off,int count)构造器
        return new String(chars,0,size);
    }

    // 面试思路3
    public String replaceSpace(String string){
        // 循环获取新数组的大小，减少浪费
        int length = string.length();
        int count = 0;
        for (int i = 0; i < length; i++) {
            if(string.charAt(i) == ' '){
                count ++;
            }
        }
        // 创建新数组
        char[] chars = new char[length + 2 * count];
        // 循环替换空格
        int size = 0;
        for (int i = 0; i < length; i++) {
            if (string.charAt(i) == ' '){
                chars[size++] = '%';
                chars[size++] = '2';
                chars[size++] = '0';
            } else {
                chars[size++] = string.charAt(i);
            }
        }
        return new String(chars);
    }
}
