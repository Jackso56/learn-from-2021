package com.linmu.adatastructure_.practice_offer_;

import org.testng.annotations.Test;

import java.util.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构--栈（先进后出）
 *
 * 剑指 Offer 06. 从尾到头打印链表
 * 输入一个链表的头节点，从尾到头反过来返回每个节点的值（用数组返回）。
 *
 * 示例 1：
 * 输入：head = [1,3,2]
 * 输出：[2,3,1]
 **/
@SuppressWarnings({"all"})
public class Practice_02 {
    @Test
    public void Test_() {
        ListNode listNode = new ListNode(1);
        ListNode listNode1 = new ListNode(2);
        ListNode listNode2 = new ListNode(3);
        listNode.next = listNode1;
        listNode1.next = listNode2;
        System.out.println(Arrays.toString(reversePrint_01(listNode)));
    }

    // 面试思路1:辅助栈法
    public int[] reversePrint_01(ListNode head) {
        // 创建链表
        LinkedList<Integer> stack = new LinkedList<>();
        // 记录链表大小
        int size = 0;
        // 元素入栈
        while (head != null) {
            stack.addLast(head.val);
            size++;
            head = head.next;
        }
        // 创建与链表等大小的数组
        int[] nums = new int[size];
        // 链表元素出栈
        for (int i = 0; i < size; i++) {
            nums[i] = stack.removeLast();
        }
        stack = null;
        return nums;
    }
}

class ListNode {
    int val;
    ListNode next;

    ListNode(int val) {
        this.val = val;
    }
}
