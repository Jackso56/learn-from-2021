package com.linmu.adatastructure_.practice_offer_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 剑指 Offer 10- I. 斐波那契数列
 * 写一个函数，输入 n ，求斐波那契（Fibonacci）数列的第 n 项（即 F(N)）。斐波那契数列的定义如下：
 *
 * F(0) = 0, F(1)= 1
 * F(N) = F(N - 1) + F(N - 2), 其中 N > 1.
 * 斐波那契数列由 0 和 1 开始，之后的斐波那契数就是由之前的两数相加而得出。
 *
 * 答案需要取模 1e9+7（1000000007 2147483647），如计算初始结果为：1000000008，请返回 1。
 *
 * 示例 1：
 *
 * 输入：n = 2
 * 输出：1
 * 示例 2：
 *
 * 输入：n = 5
 * 输出：5
 **/
@SuppressWarnings({"all"})
public class Practice_12 {
    // 思路1：数组存储累加
    public int fib_01(int n) {
        if (n == 0){
            return 0;
        }
        if (n == 1 || n == 2){
            return 1;
        }
        int[] numbers = new int[n + 1];
        numbers[0] = 0;
        numbers[1] = 1;
        numbers[2] = 1;
        for (int i = 3 ; i <= n ; i++) {
            numbers[i] = (numbers[i-1] + numbers[i-2]) % 1000000007;
        }
        return numbers[n];
    }

    // 思路2：变量存储累加
    public int fib(int n){
        if (n == 0){
            return 0;
        }
        if (n == 1 || n == 2){
            return 1;
        }
        int a = 1;
        int b = 1;
        int sum = 0;
        for (int i = 3; i <= n; i++) {
            sum = (a + b) % 1000000007;
            a = b;
            b = sum;
        }
        return sum;
    }
}

