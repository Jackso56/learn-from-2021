package com.linmu.adatastructure_.practice_offer_;

import org.testng.annotations.Test;
import java.util.ArrayDeque;
import java.util.Arrays;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 剑指 Offer 59 - I. 滑动窗口的最大值
 * 给定一个数组 nums 和滑动窗口的大小 k，请找出所有滑动窗口里的最大值。
 *
 * 示例:
 *
 * 输入: nums = [1,3,-1,-3,5,3,6,7], 和 k = 3
 * 输出: [3,3,5,5,6,7]
 * 解释:
 *
 *   滑动窗口的位置                最大值
 * ---------------               -----
 * [1  3  -1] -3  5  3  6  7       3
 *  1 [3  -1  -3] 5  3  6  7       3
 *  1  3 [-1  -3  5] 3  6  7       5
 *  1  3  -1 [-3  5  3] 6  7       5
 *  1  3  -1  -3 [5  3  6] 7       6
 *  1  3  -1  -3  5 [3  6  7]      7
 **/
@SuppressWarnings({"all"})
public class Practice_09 {

    @Test
    public void method01(){
        int[] nums = {1,3,-1,-3,5,3,6,7};
        System.out.println(Arrays.toString(maxSlidingWindow_01(nums,3)));
    }

    // 思路1：数组+队列
    public int[] maxSlidingWindow_01(int[] nums, int k){
        // 排除特殊情况
        if(nums.length == 0 || k == 0) return new int[0];
        // 创建队列存取区间值，方便取得区间最大值
        ArrayDeque<Integer> arrayDeque = new ArrayDeque();
        // 创建数组，存储区间最大值
        int[] newNums = new int[nums.length - k + 1];
        //j = 1 - k 确保[j,i]区间中的j从-2开始，确保区间大小为k
        for (int i = 0,j = 1 - k ; i < nums.length; i++,j++) {
            // delete nums[j - 1]
            if (j > 0 && nums[j - 1] == arrayDeque.peekFirst()){
                arrayDeque.removeFirst();
            }
            // add nums[i + 1]
            while (!arrayDeque.isEmpty() && arrayDeque.peekLast() < nums[i]){
                arrayDeque.removeLast();
            }
            arrayDeque.addLast(nums[i]);
            // 存放区间最大值
            if (j >= 0){
                // 队列内部实现了数据递减
                newNums[j] = arrayDeque.peekFirst();
            }
        }
        return nums;
    }
}
