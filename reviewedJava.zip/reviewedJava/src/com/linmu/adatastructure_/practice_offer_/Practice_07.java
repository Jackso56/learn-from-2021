package com.linmu.adatastructure_.practice_offer_;

import java.util.HashMap;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 * <p>
 * 数据结构：链表
 * <p>
 * 剑指 Offer 35. 复杂链表的复制
 * <p>
 * 请实现 copyRandomList 函数，复制一个复杂链表。在复杂链表中，]
 * 每个节点除了有一个 next 指针指向下一个节点，
 * 还有一个 random 指针指向链表中的任意节点或者 null。
 * <p>
 * 示例 1：
 * <p>
 * 输入：head = [[7,null],[13,0],[11,4],[10,2],[1,0]]
 * 输出：[[7,null],[13,0],[11,4],[10,2],[1,0]]
 * <p>
 * 示例 2：
 * <p>
 * 输入：head = [[1,1],[2,1]]
 * 输出：[[1,1],[2,1]]
 * <p>
 * 示例 3：
 * <p>
 * 输入：head = [[3,null],[3,0],[3,null]]
 * 输出：[[3,null],[3,0],[3,null]]
 * <p>
 * 示例 4：
 * <p>
 * 输入：head = []
 * 输出：[]
 * 解释：给定的链表为空（空指针），因此返回 null。
 **/
@SuppressWarnings({"all"})
public class Practice_07 {
    // 思路1:哈希表
    public Node copyRandomList_01(Node head) {
        // 排除特殊情况
        if (head == null) {
            return null;
        }
        // 存储复制到的数据
        HashMap<Node, Node> nodes = new HashMap<>();
        // 存储首节点，方便后面设置其next和random属性
        Node current = head;
        // 创建映射数据
        while (current != null) {
            nodes.put(current, new Node(current.value));
            current = current.next;
        }
        // 设置数据的next和random属性
        current = head;
        while (current != null) {
            // 设置next
            nodes.get(current).next = nodes.get(current.next);
            // 设置random
            nodes.get(current).random = nodes.get(current.random);
            current = current.next;
        }
        return nodes.get(head);
    }

    // 思路2：拼接+拆分
    public Node copyRandomList_02(Node head) {
        // 排除特殊情况
        if (head == null) {
            return null;
        }
        // 插入节点,拼接链表
        Node cur = head;
        Node temp = null;
        while (cur != null) {
            temp = new Node(cur.value);
            temp.next = cur.next;
            cur.next = temp;
            cur = temp.next;
        }
        // 创建新的random指引
        cur = head;
        while (cur != null){
            // 排除random属性指向null的情况
            if (cur.random != null){
                cur.next.random = cur.random.next;
            }
            cur = cur.next.next;
        }
        // 拆分链表
        cur = head;
        Node pre = head.next;
        Node result = head.next;
        while (pre.next != null){
            cur.next = cur.next.next;
            pre.next = pre.next.next;
            cur = cur.next;
            pre = pre.next;
        }
        cur.next = null;
        return result;
    }
}

@SuppressWarnings({"all"})
class Node {
    public int value;
    public Node next, random;

    public Node(int value) {
        this.value = value;
        this.next = null;
        this.random = null;
    }
}
