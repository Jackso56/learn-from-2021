package com.linmu.adatastructure_.practice_offer_;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedList;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构--栈->队列
 *
 * 剑指 Offer 09. 用两个栈实现队列
 * 用两个栈实现一个队列。队列的声明如下，请实现它的两个函数 appendTail 和 deleteHead ，分别完成在队列尾部插入整数
 * 和在队列头部删除整数的功能。(若队列中没有元素，deleteHead 操作返回 -1 )
 *
 * 示例 1：
 *
 * 输入：
 * ["CQueue","appendTail","deleteHead","deleteHead","deleteHead"]
 * [[],[3],[],[],[]]
 * 输出：[null,null,3,-1,-1]
 * 示例 2：
 *
 * 输入：
 * ["CQueue","deleteHead","appendTail","appendTail","deleteHead","deleteHead"]
 * [[],[],[5],[2],[],[]]
 * 输出：[null,-1,null,null,5,2]
 **/
@SuppressWarnings({"all"})
public class Practice_03 {

}

@SuppressWarnings({"all"})
// 面试思路1
class CQueue_{
    //    声明两个栈
    private LinkedList<Integer> stack1;
    private LinkedList<Integer> stack2;
    // 创建两个栈
    public CQueue_() {
//        stack1用于在尾部插入元素
        this.stack1 = new LinkedList<>();
//        stack2用于在首部删除元素
        this.stack2 = new LinkedList<>();
    }
    //    尾部添加元素
    public void appendTail(int value) {
//        stack1中没有元素，则插入元素；反之将元素反转到stack2中，再插入元素
        while(! stack2.isEmpty()) {
            stack1.offer(stack2.poll());
        }
        stack1.offer(value);
    }
    //    首部删除元素
    public int deleteHead() {
//        stack1中没有元素，则开始删除元素；反之先将元素反转到stack2中，再删除元素
        while (! stack1.isEmpty()) {
            stack2.offer(stack1.poll());
        }
        if(stack2.isEmpty())
            return -1;
        return stack2.poll();
    }
}

// 面试思路2：优化思路1
@SuppressWarnings({"all"})
class Queue_{
    private LinkedList<Integer> stack1;
    private LinkedList<Integer> stack2;

    public Queue_(){
        stack1 = new LinkedList<>();
        stack2 = new LinkedList<>();
    }

//    元素可以直接添加
    public void appendElement(int value){
        stack1.offer(value);
    }

//    删除元素时，只需要判断相应的队列是否为空；
//    元素倒置的缘故，上面的元素就是头元素
    public int deleteElement(){
        if (stack2.isEmpty()){
            while (! stack1.isEmpty()){
                stack2.offer(stack1.poll());
            }
        }

        if (stack2.isEmpty()){
            return -1;
        }
        return stack2.poll();
    }
}

// 官方思路：使用 Deque，ArrayDeque
@SuppressWarnings({"all"})
class CQueue {
    Deque<Integer> inStack;
    Deque<Integer> outStack;

    public CQueue() {
        inStack = new ArrayDeque<Integer>();
        outStack = new ArrayDeque<Integer>();
    }

    public void appendTail(int value) {
        inStack.push(value);
    }

    public int deleteHead() {
        if (outStack.isEmpty()) {
            if (inStack.isEmpty()) {
                return -1;
            }
            in2out();
        }
        return outStack.pop();
    }

    private void in2out() {
        while (!inStack.isEmpty()) {
            outStack.push(inStack.pop());
        }
    }
}

