package com.linmu.adatastructure_.practice_offer_;

import java.util.HashMap;
import java.util.Map;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构：散列表
 *
 * 剑指 Offer 67. 把字符串转换成整数
 * 写一个函数 StrToInt，实现把字符串转换成整数这个功能。不能使用 atoi 或者其他类似的库函数。
 *
 *
 * 首先，该函数会根据需要丢弃无用的开头空格字符，直到寻找到第一个非空格的字符为止。
 *
 * 当我们寻找到的第一个非空字符为正或者负号时，则将该符号与之后面尽可能多的连续数字组合起来，
 * 作为该整数的正负号；假如第一个非空字符是数字，则直接将其与之后连续的数字字符组合起来，形成整数。
 *
 * 该字符串除了有效的整数部分之后也可能会存在多余的字符，这些字符可以被忽略，
 * 它们对于函数不应该造成影响。
 *
 * 注意：假如该字符串中的第一个非空格字符不是一个有效整数字符、字符串为空或字符串仅包含空白字符时，
 * 则你的函数不需要进行转换。
 *
 * 在任何情况下，若函数不能进行有效的转换时，请返回 0。
 *
 * 说明：
 *
 * 假设我们的环境只能存储 32 位大小的有符号整数，那么其数值范围为[−231,231− 1]。如果数值超过这个范围，
 * 请返回 INT_MAX (231− 1) 或INT_MIN (−231) 。
 **/
@SuppressWarnings({"all"})
public class Practice_11 {
    // 思路1：有限状态机
    public int strToInt_01(String str) {
        if (str.length() <= 0){
            return 0;
        }
        Automaton automaton = new Automaton();
        int length = str.length();
        for (int i = 0; i < length; ++i) {
            automaton.get(str.charAt(i));
        }
        return (int) (automaton.sign * automaton.ans);
    }
    @SuppressWarnings({"all"})
    class Automaton {
        public int sign = 1;
        public long ans = 0;
        private String state = "start";
        // 状态机：通过不执行核心代码的形式来保持结果的准确性
        private Map<String, String[]> table = new HashMap<String, String[]>() {{
            put("start", new String[]{"start", "signed", "in_number", "end"});
            put("signed", new String[]{"end", "end", "in_number", "end"});
            put("in_number", new String[]{"end", "end", "in_number", "end"});
            put("end", new String[]{"end", "end", "end", "end"});
        }};

        public void get(char c) {
            state = table.get(state)[get_col(c)];
            if ("in_number".equals(state)) {
                // 数字对应Unicode字符序号为48-57，所以要减去字符0的序号
                ans = ans * 10 + c - '0';
                // 大于 2147483648 则取 2147483648，小于 -2147483648 则取 -2147483648
                // 此时的sns尚未乘上符号位，均为正数
                ans = sign == 1 ? Math.min(ans, (long) Integer.MAX_VALUE) : Math.min(ans, -(long) Integer.MIN_VALUE);
            } else if ("signed".equals(state)) {
                sign = c == '+' ? 1 : -1;
            }
        }

        private int get_col(char c) {
            if (c == ' ') {
                return 0;
            }
            if (c == '+' || c == '-') {
                return 1;
            }
            if (Character.isDigit(c)) {
                return 2;
            }
            return 3;
        }
    }

    // 思路2：数组循环判断（优解）
    public int strToInt_02(String str) {
        char[] c = str.trim().toCharArray();
        if(c.length == 0) {
            return 0;
        }
        // 防止数据溢出
        int res = 0, bndry = Integer.MAX_VALUE / 10;
        int i = 1, sign = 1;
        // 正数从下标0开始，负数从下标1开始
        if(c[0] == '-') {
            sign = -1;
        }
        else if(c[0] != '+') {
            i = 0;
        }
        // 核心代码：循环遍历寻找数据
        for(int j = i; j < c.length; j++) {
            if(c[j] < '0' || c[j] > '9') {
                break;
            }
            if(res > bndry || res == bndry && c[j] > '7') {
                return sign == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE;
            }
            res = res * 10 + c[j] - '0';
        }
        return sign * res;
    }
}

