package com.linmu.adatastructure_.practice_offer_;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 * <p>
 *
 * 数据结构：链表
 *
 * 剑指 Offer 24. 反转链表
 * 定义一个函数，输入一个链表的头节点，反转该链表并输出反转后链表的头节点。
 * <p>
 * 示例:
 * <p>
 * 输入: 1->2->3->4->5->NULL
 * 输出: 5->4->3->2->1->NULL
 **/
@SuppressWarnings({"all"})
public class Practice_05 {
    // 思路1：迭代（双指针）
    public ListNode reverseList_01(ListNode head) {
        ListNode previous = null;
        ListNode behind = head;
        ListNode temp = null;
        while (behind  != null) {
           temp = behind.next; // 存储下一个节点
           behind.next = previous; // 指向新的节点
           previous = behind; // 节点后移
           behind = temp; // 节点后移
        }
        return previous;
    }

    // 思路2：递归回溯(创建用于内部的private方法)
    public ListNode reverseList_02(ListNode head) {
        return reback(null,head); // 调用递归并返回
    }
    private ListNode reback(ListNode previous,ListNode behind){
        if (behind == null){ // 终止条件
            return previous;
        }
        ListNode result = reback(behind,behind.next); // 递归后继节点
        behind.next = previous; // 修改节点指向
        return result; // 返回反转链表的头节点
    }
}


@SuppressWarnings({"All"})
class ListNode_ {
    int val;
    ListNode next;

    ListNode_(int val) {
        this.val = val;
    }
}