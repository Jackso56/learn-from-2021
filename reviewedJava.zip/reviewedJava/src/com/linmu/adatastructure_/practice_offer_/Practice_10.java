package com.linmu.adatastructure_.practice_offer_;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构：普通队列，单调队列
 *
 * 剑指 Offer 59 - II. 队列的最大值
 *
 * 请定义一个队列并实现函数 max_value 得到队列里的最大值，
 * 要求函数max_value、push_back 和 pop_front 的均摊时间复杂度都是O(1)。
 *
 * 若队列为空，pop_front 和 max_value需要返回 -1
 *
 * 示例 1：
 *
 * 输入:
 * ["MaxQueue","push_back","push_back","max_value","pop_front","max_value"]
 * [[],[1],[2],[],[],[]]
 * 输出: [null,null,null,2,1,2]
 * 示例 2：
 *
 * 输入:
 * ["MaxQueue","pop_front","max_value"]
 * [[],[],[]]
 * 输出:[null,-1,-1]
 *
 **/
@SuppressWarnings({"all"})
public class Practice_10 {
    Deque<Integer> deque ;
    Deque<Integer> queue;
    public Practice_10() {
        // 普通队列
        deque = new ArrayDeque<>();
        // 双端队列
        queue = new ArrayDeque<>();
    }
    // 返回单调队列中的最大值，
    public int max_value() {
        return queue.isEmpty() ? -1 : queue.peekFirst();
    }
    // 向两个队列中添加元素
    public void push_back(int value) {
        deque.addLast(value);
        while (!queue.isEmpty() && queue.peekLast() < value){
            queue.pollLast();
        }
        queue.addLast(value);
    }
    // 删除两个队列中的元素
    public int pop_front() {
        if (deque.isEmpty()){
            return -1;
        }
        // 当两个队列的头元素相等时执行
        if (deque.peekFirst().equals(queue.peekFirst())){
            queue.removeFirst();
        }
        return deque.removeFirst();
    }
}
