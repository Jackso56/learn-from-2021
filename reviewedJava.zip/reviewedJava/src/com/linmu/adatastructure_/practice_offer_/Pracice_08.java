package com.linmu.adatastructure_.practice_offer_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构：字符串
 *
 * 剑指 Offer 58 - II. 左旋转字符串
 *
 * 字符串的左旋转操作是把字符串前面的若干个字符转移到字符串的尾部。
 * 请定义一个函数实现字符串左旋转操作的功能。比如，输入字符串"abcdefg"和数字2，
 * 该函数将返回左旋转两位得到的结果"cdefgab"。
 *
 * 示例 1：
 *
 * 输入: s = "abcdefg", k = 2
 * 输出: "cdefgab"
 * 示例 2：
 *
 * 输入: s = "lrloseumgh", k = 6
 * 输出: "umghlrlose"
 **/
@SuppressWarnings({"all"})
public class Pracice_08 {
    // 思路1：字符串切片,子串拼接（上解）
    public String reverseLeftWords_01(String s, int n) {
        // 前闭后开
       return s.substring(n,s.length()) + s.substring(0,n);
    }

    // 思路2：遍历+可变字符串（StringBuffer,StringBuilder）
    public String reverseLeftWords_02(String s, int n) {
        StringBuffer sb = new StringBuffer();
        for (int i = n; i < s.length(); i++) {
            sb.append(s.charAt(i));
        }
        for (int i = 0; i < n; i++) {
            sb.append(s.charAt(i));
        }
        return sb.toString();
    }

    // 思路2的简化版（取余）,时间和空间复杂度增加
    public String reverseLeftWords_03(String s, int n){
        StringBuffer sb = new StringBuffer();
        for (int i = n; i < n + s.length(); i++) {
            sb.append(s.charAt(i % s.length()));
        }
        return sb.toString();
    }

    // 思路3：遍历+不可变字符串（下解）
    public String reverseLeftWords_04(String s, int n){
        String str = "";
        for (int i = n; i < s.length(); i++) {
            str += s.charAt(i);
        }
        for (int i = 0; i < n; i++) {
            str += s.charAt(i);
        }
        return str;
    }

    // 思路3优化，取余（下下解）
    public String reverseLeftWords_05(String s, int n){
        String str = "";
        for (int i = n; i < s.length() + n; i++) {
            str += s.charAt(i % s.length());
        }
        return str;
    }
}
