package com.linmu.adatastructure_.course_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 递归的底层是一个多叉树，每个节点会存储相应的变量
 *
 * master公式：T(N)=a*T(N/b)+O(N^d)（用于递归时间复杂度的估算）
 * T(N):表示母问题数据规模
 * T(N/b):表示子问题数据规模,要求子问题的数据规模一致
 * a：表示子问题的调用次数
 * O(N^d)：其他步骤（决策步骤）的时间复杂度
 * 时间复杂度：
 * 1）logb a < d --> O(N^d)
 * 1）logb a > d --> O(N^logb a)
 * 1）logb a == d --> O(N^d * logN)
 **/
@SuppressWarnings({"all"})
public class Course_03 {
    public static void main(String[] args) {
        // 返回最大值 getMax
        int[] arr = {8,4,6,9,2,1};
        System.out.println(getMax(arr));
        // 归并排序 mergeSort
//        mergeSort(arr);
//        for (int data : arr) {
//            System.out.println(data);
//        }
    }
    // T(N) = 2*T(N/2)+O(1) --> O(N)
    // 递归返回数组最大值，先左再右，逐一返回
    public static int getMax(int[] array_){
        return process(array_,0,array_.length - 1);
    }
    public static int process(int[] array_,int pre,int bhd){
        // leftMax和rightMax的终止条件
        if (pre == bhd){
            return array_[pre];
        }
        // 取中点
        int mid = pre + ((bhd - pre) >> 1);
        // 递归返回左侧最大值
         int leftMax = process(array_,pre,mid);
        // 递归返回右侧最大值
        int rightMax = process(array_,mid+1,bhd);
        return Math.max(leftMax,rightMax);
    }
    // 归并排序 O(N*logN)
    public static void mergeSort(int[] array_){
        // 边界条件
        if (array_ == null || array_.length < 2){
            return;
        }
        // 归并排序
        mergeprocess(array_,0, array_.length - 1);
    }
    public static void mergeprocess(int[] array_,int pre,int bhd){
        // 结束某一个递归
        if (pre == bhd){
            return;
        }
        // 防止溢出
        int mid = pre + ((bhd - pre) >> 1);
        // 拆分
        mergeprocess(array_,pre,mid);
        mergeprocess(array_,mid+1,bhd);
        // 合并
        merge(array_,pre,mid,bhd);
    }
    public static void merge(int[] array_,int pre,int mid,int bhd){
        // help array
        int[] helpArray = new int[bhd - pre + 1];
        // helpArray Index
        int i = 0;
        // pre index
        int pre_index = pre;
        // bhd index
        int bhd_index = mid + 1;
        // add data to helpArray
        while (pre_index <= mid && bhd_index <= bhd){
            helpArray[i++] = array_[pre_index] >= array_[bhd_index] ? array_[pre_index++] :
                    array_[bhd_index++];
        }
        // bhd_index out of bandary
        while (pre_index <= mid){
            helpArray[i++] = array_[pre_index++];
        }
        // pre_index out of bandary
        while (bhd_index <= bhd){
            helpArray[i++] = array_[bhd_index++];
        }
        // copy helpArray to array_
        for (int j = 0; j < helpArray.length; j++) {
            // pre to bhd is orderly
            array_[pre+j] = helpArray[j];
        }
    }
}
