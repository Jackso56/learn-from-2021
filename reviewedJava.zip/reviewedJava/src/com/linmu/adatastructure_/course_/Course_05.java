package com.linmu.adatastructure_.course_;

import java.util.Arrays;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Course_05 {
    public static void main(String[] args) {
        QuickSort quickSort = new QuickSort();
        int[] arr = {9, 1, 4, 8, 2, 7};
        quickSort.quickSort(arr);
        System.out.println(Arrays.toString(arr));
    }

    // 快排：O(NlogN)
    static class QuickSort {

        // 快排主方法
        public void quickSort(int[] array_) {
            if (array_ == null || array_.length < 2) {
                return;
            }
            quickSort(array_, 0, array_.length - 1);
        }

        // 快排辅助方法
        public void quickSort(int[] array_, int L, int R) {
            if (L < R) {
                // 随机选数，放到最后，作为边界值
                swap(array_, L + (int) (Math.random() * (R - L + 1)), R);
                // 此时下标为right的位置上就是那个随机数
                int[] part = partition(array_, L, R);
                // <边界值区域
                quickSort(array_, L, part[0] - 1);
                // >边界值区域
                quickSort(array_, part[1] + 1, R);
            }
        }

        // 快排的核心代码
        public int[] partition(int[] array_, int L, int R) {
            // 左边界
            int leftD = L - 1;
            // 右边界
            int rightD = R;
            // 开始划分边界
            while (L < rightD) {
                // 当前值<边界值
                if (array_[L] < array_[R]) {
                    swap(array_, ++leftD, L++);
                    // 当前值>边界值
                } else if (array_[L] > array_[R]) {
//                    待定
                    swap(array_, --rightD, L);
                } else {
                    L++;
                }
            }
            swap(array_, rightD, R);
            // 返回左右边界
            return new int[]{leftD + 1, rightD - 1};
        }

        // 某些情况下异或运算会出现严重的错误，
        // 在这里就不适合使用异或运算
        public void swap(int[] array_, int left, int right) {
            int temp = array_[left];
            array_[left] = array_[right];
            array_[right] = temp;
        }
    }
}
