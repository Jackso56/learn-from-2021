package com.linmu.adatastructure_.course_;

import org.testng.annotations.Test;

import java.util.Arrays;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 * <p>
 * 基于比较的排序：冒泡，选择，插入，快排，归并，堆排
 * 非基于比较的排序：桶排
 * <p>
 * 具有数据稳定性：冒泡，选择，插入，归并，桶排（其中相等时不交换，才符合）
 * 无数据稳定性：选择排序，堆排，快排
 **/
@SuppressWarnings({"all"})
public class A_LogarithmicDetector {

    // 对数器：核对算法的准确性（仅正数）
    @Test
    public void Test_1() {
        int testTime = 500000;
        int maxValue = 100;
        int maxSize = 100;
        boolean flag = true;
        for (int i = 0; i < testTime; i++) {
            // 创建随机数组
            int[] array_ = generateRandomArray_1(maxValue, maxSize);
            // 拷贝数组
            int[] copyArray = copyArray_(array_);
            // 自定义算法
            radiusSort_(array_);
            // 系统算法
            Arrays.sort(copyArray);
            // 判断结果是否相等
            if (!isEqual_(array_, copyArray)) {
                flag = false;
                break;
            }
        }
        // 完全正确输出“Nice!”,有错误输出“Failed...”
        System.out.println(flag ? "Nice!" : "Failed...");
    }

    // 对数器：核对算法的准确性（有正负）
    @Test
    public void Test_() {
        int testTime = 500000;
        int maxValue = 100;
        int maxSize = 100;
        boolean flag = true;
        for (int i = 0; i < testTime; i++) {
            // 创建随机数组
            int[] array_ = generateRandomArray(maxValue, maxSize);
            // 拷贝数组
            int[] copyArray = copyArray_(array_);
            // 自定义算法
            mergeSort(array_);
            // 系统算法
            Arrays.sort(copyArray);
            // 判断结果是否相等
            if (!isEqual_(array_, copyArray)) {
                flag = false;
                break;
            }
        }
        // 完全正确输出“Nice!”,有错误输出“Failed...”
        System.out.println(flag ? "Nice!" : "Failed...");
    }

    // 随机数据生成器（有正负）
    public int[] generateRandomArray(int maxSize, int maxValue) {
        // 数组长度随机
        int[] array_ = new int[(int) ((maxSize + 1) * Math.random())];
        // 产生随机数据
        for (int i = 0; i < array_.length; i++) {
            array_[i] = (int) ((maxValue + 1) * Math.random()) - (int) (maxValue * Math.random());
        }
        return array_;
    }

    // 随机数据生成器（仅正数）
    public int[] generateRandomArray_1(int maxSize, int maxValue) {
        // 数组长度随机
        int[] array_ = new int[(int) ((maxSize + 1) * Math.random())];
        // 产生随机数据
        for (int i = 0; i < array_.length; i++) {
            array_[i] = (int) ((maxValue + 1) * Math.random());
        }
        return array_;
    }

    // 拷贝数组
    public int[] copyArray_(int[] array_) {
        if (array_ == null) {
            return null;
        }
        int[] arr = new int[array_.length];
        for (int i = 0; i < array_.length; i++) {
            arr[i] = array_[i];
        }
        return arr;
    }

    // 数据相等判断
    public boolean isEqual_(int[] arr1, int[] arr2) {
        boolean flag = true;
        for (int i = 0; i < arr1.length; i++) {
            flag = arr1[i] == arr2[i] ? true : false;
        }
        return flag;
    }

    // 自定义算法-插入排序：O(N^2) 存在特殊数据的情况，时间复杂度可能下降
    public static void insertSort(int[] array_) {
        // 使0-i上有序,其中0-0上已经有序
        for (int i = 1; i < array_.length; i++) {
            // 开始排序,使当前位置上的数与前一位上的数进行比较
            for (int j = i - 1; j >= 0 && array_[j] > array_[j + 1]; j--) {
                insertSortSwap(array_, j, j + 1);
            }
        }
    }

    public static void insertSortSwap(int[] array_, int oldIndex, int newIndex) {
        array_[oldIndex] = array_[oldIndex] ^ array_[newIndex];
        array_[newIndex] = array_[oldIndex] ^ array_[newIndex];
        array_[oldIndex] = array_[oldIndex] ^ array_[newIndex];
    }

    // 自定义算法-冒泡排序：O(N^2)
    public static void bobbleSortSwap(int[] array, int oldIndex, int newIndex) {
        /*^:异或运算，又称无进位相加
            异或运算的特性：1)0^N=N   2)N^N=0   3)异或运算满足交换律和结合律
            例如：a = 甲，b = 乙；a和b交换值
            a = a ^ b  ==》 a = 甲^乙
            b = a ^ b  ==》 b = 甲^乙^乙  --> b = 甲
            a = b ^ a  ==》 a =  甲^甲^乙 --> a = 乙
        */
        array[oldIndex] = array[oldIndex] ^ array[newIndex];
        array[newIndex] = array[oldIndex] ^ array[newIndex];
        array[oldIndex] = array[oldIndex] ^ array[newIndex];
    }

    public static void bobbleSort(int[] array_) {
        // 特殊情况
        if (array_ == null || array_.length < 2) {
            return;
        }
        // 确保array_[i] < array[i+1]...array_[array_.length - 1]
        // 双循环是否都从0开始，具体问题具体分析
        for (int i = 0; i < array_.length - 1; i++) {
            for (int j = 0; j < array_.length - 1 - i; j++) {
                if (array_[j] > array_[j + 1]) {
                    bobbleSortSwap(array_, j, j + 1);
                }
            }
        }
    }

    // 自定义算法-选择排序：O(N^2)
    public static void selectMathSwap(int[] array_, int oldIndex, int newIndex) {
        int temp = 0;
        temp = array_[oldIndex];
        array_[oldIndex] = array_[newIndex];
        array_[newIndex] = temp;
    }

    public static void selectMath(int[] array_) {
        // 特殊情况
        if (array_ == null || array_.length < 2) {
            return;
        }
        // i~array_.length - 1
        for (int i = 0; i < array_.length - 1; i++) {
            int minIndex = i;
            // i+1~array_length
            for (int j = i + 1; j < array_.length; j++) {
                // 返回数组较小值的下标
                minIndex = array_[j] > array_[minIndex] ? minIndex : j;
            }
            selectMathSwap(array_, minIndex, i);
        }
    }

    // 自定义算法-归并排序：O(NlogN)
    public static void mergeSort(int[] array_) {
        // 边界条件
        if (array_ == null || array_.length < 2) {
            return;
        }
        // 归并排序
        mergeprocess(array_, 0, array_.length - 1);
    }

    public static void mergeprocess(int[] array_, int pre, int bhd) {
        // 结束某一个递归
        if (pre == bhd) {
            return;
        }
        // 防止溢出
        int mid = pre + ((bhd - pre) >> 1);
        // 拆分
        mergeprocess(array_, pre, mid);
        mergeprocess(array_, mid + 1, bhd);
        // 合并
        merge(array_, pre, mid, bhd);
    }

    public static void merge(int[] array_, int pre, int mid, int bhd) {
        // help array
        int[] helpArray = new int[bhd - pre + 1];
        // helpArray Index
        int i = 0;
        // pre index
        int pre_index = pre;
        // bhd index
        int bhd_index = mid + 1;
        // add data to helpArray
        while (pre_index <= mid && bhd_index <= bhd) {
            helpArray[i++] = array_[pre_index] <= array_[bhd_index] ? array_[pre_index++] :
                    array_[bhd_index++];
        }
        // bhd_index out of bandary
        while (pre_index <= mid) {
            helpArray[i++] = array_[pre_index++];
        }
        // pre_index out of bandary
        while (bhd_index <= bhd) {
            helpArray[i++] = array_[bhd_index++];
        }
        // copy helpArray to array_
        for (int j = 0; j < helpArray.length; j++) {
            // pre to bhd is orderly
            array_[pre + j] = helpArray[j];
        }
    }

    // 自定义算法-快排：O(NlogN)
    // 快排主方法
    public void quickSort(int[] array_) {
        if (array_ == null || array_.length < 2) {
            return;
        }
        quickSort(array_, 0, array_.length - 1);
    }

    // 快排辅助方法
    public void quickSort(int[] array_, int L, int R) {
        if (L < R) {
            // 随机选数，放到最后，作为边界值
            swap(array_, L + (int) (Math.random() * (R - L + 1)), R);
            // 此时下标为right的位置上就是那个随机数
            int[] part = partition(array_, L, R);
            // <边界值区域
            quickSort(array_, L, part[0] - 1);
            // >边界值区域
            quickSort(array_, part[1] + 1, R);
        }
    }

    // 快排的核心代码
    public int[] partition(int[] array_, int L, int R) {
        // 左边界
        int leftD = L - 1;
        // 右边界
        int rightD = R;
        // 开始划分边界
        while (L < rightD) {
            // 当前值<边界值
            if (array_[L] < array_[R]) {
                swap(array_, ++leftD, L++);
                // 当前值>边界值
            } else if (array_[L] > array_[R]) {
//                    待定
                swap(array_, --rightD, L);
            } else {
                L++;
            }
        }
        swap(array_, rightD, R);
        // 返回左右边界
        return new int[]{leftD + 1, rightD - 1};
    }

    // 某些情况下异或运算会出现严重的错误，
    // 在这里就不适合使用异或运算
    public void swap(int[] array_, int left, int right) {
        int temp = array_[left];
        array_[left] = array_[right];
        array_[right] = temp;
    }

    // 自定义算法-堆排：O(NlogN)
    // 堆排
    public void heapSort(int[] array_) {
        // 特殊情况
        if (array_ == null || array_.length < 2) {
            return;
        }
        // 插入数据，形成大根堆
        for (int i = 0; i < array_.length; i++) {
            heapInsert(array_, i);
        }
            /*
            时间复杂度有所下降
            for (int i = array_.length;i > 0; i--){
                heapify(array_,i, array_.length);
            }
            */
        // 记录数组长度，以便变换堆的高度
        int heapsize = array_.length;
        // 交换堆中最大和最小的元素
        heapSwap(array_, 0, --heapsize);
        // 循环堆排，不断heapify()，再去除最后一个元素
        while (heapsize > 0) {
            heapify(array_, 0, heapsize);
            heapSwap(array_, 0, --heapsize);
        }
    }

    // 堆中插入数据，并形成大堆根
    public void heapInsert(int[] array_, int index) {
        while (array_[index] > array_[(index - 1) / 2]) {
            heapSwap(array_, index, (index - 1) / 2);
            index = (index - 1) / 2;
        }
    }

    // 元素变动，恢复大堆根的形式
    public void heapify(int[] array_, int index, int heapsize) {
        // 左子节点序号
        int left = index << 1 + 1;
        // 存在子节点
        while (left < heapsize) {
            // 返回较大的子节点的下标
            int largest = left + 1 < heapsize && array_[left + 1] > array_[left] ?
                    left + 1 : left;
            // 返回子节点和父节点中较大值的下标
            largest = array_[index] > array_[largest] ? index : largest;
            // 当值达到适当位置时停止位置交换
            if (index == largest) {
                break;
            }
            // 确定下标，交换位置
            heapSwap(array_, index, largest);
            // 重置参数
            index = largest;
            left = index << 1 + 1;
        }
    }

    // 元素交换
    public void heapSwap(int[] array_, int lIndex, int rIndex) {
        int temp = array_[lIndex];
        array_[lIndex] = array_[rIndex];
        array_[rIndex] = temp;
    }

    // 桶排主方法：O(N)
    public void radixSort(int[] array_) {
        if (array_ == null || array_.length < 2) {
            return;
        }
        radixSort(array_, 0, array_.length - 1, maxDigit(array_));
    }

    // 返回最大值的位数
    public int maxDigit(int[] array_) {
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < array_.length; i++) {
            max = Math.max(array_[i], max);
        }
        int count = 0;
        while (max != 0) {
            count++;
            max /= 10;
        }
        return count;
    }

    // 循环桶排[left...right]
    public void radixSort(int[] array_, int left, int right, int digit) {
        final int radix = 10;
        int j = 0;
        int i = 0;
        // 辅助数组
        int[] helpArray_ = new int[right - left + 1];
        // 循环进桶出桶
        for (int d = 1; d <= digit; d++) {
            // 计数数组
            int[] count = new int[radix];
            // 数组计数
            for (i = left; i <= right; i++) {
                j = getDigit(array_[i], d);
                count[j]++;
            }
            // 计数累加
            for (i = 1; i < radix; i++) {
                count[i] = count[i] + count[i - 1];
            }
            // 进桶出桶的逻辑
            for (i = right; i >= left; i--) {
                j = getDigit(array_[i], d);
                helpArray_[count[j] - 1] = array_[i];
                count[j]--;
            }
            // 拷贝数据，进入下次循环
            for (i = left, j = 0; i <= right; i++, j++) {
                array_[i] = helpArray_[j];
            }
        }
    }

    // 返回元素的低位值
    public int getDigit(int digit_, int number) {
        return ((digit_ / ((int) Math.pow(10, number - 1))) % 10);
    }

    public void radiusSort_(int[] array_) {
        // 特殊情况
        if (array_ == null || array_.length < 2) {
            return;
        }
        sort(array_, 0, array_.length - 1, maxNum(array_));
    }

    public void sort(int[] array_, int before, int after, int maxNum) {
        final int size = 10;
        int[] helpArray = new int[after-before+1];
        int i = 0;
        int j = 0;
        for (int d = 1; d <= maxNum; d++) {
            // 词频表
            int[] counter = new int[size];
            // 词频计数
            for (i = before;i < after; i++) {
                // 取个位上的数字
                j = getDigit_(d, array_[i]);
                // 计数词频
                counter[j] ++;
            }
            // 词频累加
            for (i = 1; i < size; i++) {
                counter[i] = counter[i-1] + counter[i];
            }
            //完成一次入桶出桶
            for (i = after; i >= before; i--) {
                j = getDigit_(array_[i], d);
                helpArray[counter[j] - 1] = array_[i];
                counter[j]--;
            }
            // 拷贝数组
            for (i = before, j = 0; i < after; i++, j++) {
                array_[i] = helpArray[i];
            }
        }
    }

    public int maxNum(int[] array_) {
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < array_.length; i++) {
            max = Math.max(array_[i], max);
        }
        int count = 0;
        while (max != 0) {
            count++;
            max /= 10;
        }
        return count;
    }

    public int getDigit_(int d, int number) {
        return ((number / ((int)Math.pow(10, d-1))) % 10);
    }
}
