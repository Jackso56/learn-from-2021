package com.linmu.adatastructure_.course_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据稳定：排序后，其相对位置不变
 *
 * 排序算法总结：
 *  排序算法    时间复杂度   空间复杂度    数据稳定性
 *  选择          O(N^2)          O(1)        无
 *  冒泡          O(N^2)          O(1)        有
 *  插入          O(N^2)          O(1)        有
 *  归并          O(NlogN)        O(N)        有
 *  快排          O(NlogN)        O(logN)     无
 *  堆排          O(NlogN)        O(1)        无
 *
 * 算法注意要点：
 *  1）基于比较的排序：时间复杂度目前无法低于O(NlogN)
 *  2）基于比较的排序：时间复杂度为O(NlogN)，空间复杂度低于O(N)，并且保持数据稳定，
 *     目前无法实现
 *  算法优化：
 *  算法嵌套：比如大范围使用快排，时间复杂度低；小方位内使用插入排序，空间复杂度低
 *
 *
 **/
@SuppressWarnings({"all"})
public class Course_09 {
}
