package com.linmu.adatastructure_.course_;

import org.testng.annotations.Test;

import java.util.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 * 链表
 **/
@SuppressWarnings({"all"})
public class Course_10_Datastract {

    @Test  // 哈希表，无序表，单列数据
    public void Hashs(){
        HashSet hashSet = new HashSet();
        // 增加元素
        hashSet.add("jackson");
        hashSet.add("jack");
        hashSet.add("mike");
        // 删除元素
        hashSet.remove("jack");
        // 返回长度
        System.out.println(hashSet.size());
        // 查找元素是否存在
        System.out.println(hashSet.contains("jack"));
        // 清空集合
        System.out.println(hashSet);
        hashSet.clear();
        System.out.println(hashSet);
    }

    @Test // 哈希表，无序表，双列数据
    public void Hashm(){
        HashMap hashMap = new HashMap();
        // 增加数据
        hashMap.put(1,"jack");
        hashMap.put(2,"jackson");
        hashMap.put(3,"mike");
        System.out.println(hashMap);
        // 删除元素
        hashMap.remove(1);
        hashMap.remove(2,"jackson");
        System.out.println(hashMap);
        // 修改元素
        hashMap.put(3,"black");
        System.out.println(hashMap);
        // 查找元素
        System.out.println(hashMap.get(3));
        // 返回大小
        System.out.println(hashMap.size());
        // 清空集合
        hashMap.clear();
        System.out.println(hashMap);
    }

    @Test // 有序表，单列数据
    public void treeSet(){
        TreeSet treeSet = new TreeSet();
        // 增加元素
        treeSet.add(1);
        treeSet.add(2);
        treeSet.add(6);
        treeSet.add(7);
        treeSet.add(8);
        // 删除元素
        treeSet.remove(1);
        System.out.println(treeSet);
        // 查询元素是否存在
        System.out.println(treeSet.contains(2));
        // 最大值、最小值
        System.out.println(treeSet.last());
        System.out.println(treeSet.first());
        // 元素附近查找
        System.out.println(treeSet.floor(5));
        System.out.println(treeSet.ceiling(5));
    }

    @Test // 有序表，双列数据
    public void treeMap(){
        TreeMap treeMap = new TreeMap();
        // 增加元素
        treeMap.put(1,"林沐");
        treeMap.put(2,"林羽");
        treeMap.put(3,"林轩");
        treeMap.put(4,"林尧");
        treeMap.put(6,"宇轩");
        // 删除元素
        treeMap.remove(1);
        System.out.println(treeMap);
        // 查找、查询元素
        System.out.println(treeMap.get(2));
        System.out.println(treeMap.containsKey(2));
        // 返回第一、最后元素的key
        System.out.println(treeMap.firstKey());
        System.out.println(treeMap.lastKey());
        // 附近查找元素
        System.out.println(treeMap.floorKey(5));
        System.out.println(treeMap.ceilingKey(5));
        // 返回键值对
        System.out.println(treeMap.firstEntry());
        System.out.println(treeMap.lastEntry());
        System.out.println(treeMap.floorEntry(5));
        System.out.println(treeMap.ceilingEntry(5));
    }
}
