package com.linmu.adatastructure_.course_;


/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Course_11_Datastract {

    // 反转单向链表1（使用少数几个变量）
    public Node reversedListSingle_1(Node head){
        // 1->2->3->null    ===>   3->2->1->null
        Node left =  null;
        Node right = head;
        Node temp = null;
        // 当下一节点为空时，退出循环
        while (right != null){
            // 保存下一节点
            temp = right.next;
            // 改变节点指向
            right.next = left;
            // 节点前进
            left = right;
            right = temp;
        }
        return left;
    }

    // 反转双向链表（使用少数几个变量）
    public NodeDouble reversedListDouble(NodeDouble head){
        NodeDouble left = null;
        NodeDouble right = null;
        while (head.right != null){
            right = head.right;
            left = head.left;
            head.left = right;
            head.right = left;
            head = right;
        }
        return head;
    }

    // 链表回文结构判断（使用快慢指针）
    public boolean isBackList(Node head){
        if (head == null || head.next == null){
            return true;
        }
        if (head != null && head.next != null && head.next.next == null){
            return head.value == head.next.value ? true : false;
        }
        // 利用快慢指针找中点的位置
        Node n1 = head;
        Node n2 = head;
        while (n2.next != null && n2.next.next != null){
            n1 = n1.next;
            n2 = n2.next.next;
        }
        // 反转一半的链表元素
        Node n3 = null;
        n2 = n1.next;
        n1.next = null;
        while (n2 != null){
            n3 = n2.next;
            n2.next = n1;
            n1 = n2;
            n2 = n3;
        }
        // 比较
        n3 = n1;
        n2 = head;
        boolean flag = true;
        while (n1 != null && n2 != null){
            if (n1.value != n2.value){
                flag = false;
                break;
            }
            n1 = n1.next;
            n2 = n2.next;
        }
        // 恢复链表
        n1 = n3.next;
        n3.next = null;
        while (n1 != null){
            n2 = n1.next;
            n1.next = n3;
            n3 = n1;
            n1 = n2;
        }
        return flag;
    }
}
@SuppressWarnings({"all"})
class Node{
    Node next;
    int value;
    public Node(int value){
        this.value = value;
    }
}
@SuppressWarnings({"all"})
class NodeDouble{
    NodeDouble left;
    NodeDouble right;
    int value;

    public NodeDouble(int value) {
        this.value = value;
    }
}
