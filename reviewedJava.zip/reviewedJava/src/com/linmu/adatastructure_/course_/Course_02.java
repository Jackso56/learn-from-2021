package com.linmu.adatastructure_.course_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 给定数组,求指定数
 * 1)给定数组，仅有一个数出现类奇数次，其他数都出现了偶数次，求该数
 * 2)给定数组，有两个数出现奇数次，其他数都出现了偶数次，求该数
 **/
@SuppressWarnings({"all"})
public class Course_02 {
    public static void main(String[] args) {
        int[] numbers = {4, 4, 5, 4, 6, 7, 4, 8, 7, 6, 8, 9, 5, 1};
        System.out.println(selectNumbers(numbers));
    }

    // 给定数组，仅有一个数出现奇数次，其他数都出现了偶数次，求该奇数
    public static int selectNumber(int[] numbers) {
        int number = 0;
        for (int num : numbers) {
            number = number ^ num;
        }
        return number;
    }

    //给定数组，有两个数出现奇数次，其他数都出现了偶数次，求两数
    public static String selectNumbers(int[] numbers) {
        // 求a^b
        int number = 0;
        for (int num : numbers) {
            number ^= num;
        }
        // 求最右边的1,常用（重点）
        int rightOne = number & (~number + 1);
        // 求出a或b的其中一个数
        int onlyOne = 0;
        for (int num : numbers) {
            // &运算保证了只异或上最右边的1在同一个位置上的数
            if ((num & rightOne) == 0) {
                onlyOne ^= num;
            }
        }
        return onlyOne + "\t" + (number ^ onlyOne);
    }
}
