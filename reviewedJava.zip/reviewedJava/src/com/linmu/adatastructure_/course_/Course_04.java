package com.linmu.adatastructure_.course_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 小和：[1,3,4,2,5]  1的小和为0，3的小和为1,4的小和为4（1+3=4）...
 * 求数组的小和：所有小和相加
 *
 * 思路：拆分到两两比较求小和--->范围逐渐扩大到两个数组的整体（层层递归）
 **/
@SuppressWarnings({"all"})
public class Course_04 {
    public static void main(String[] args) {
        int[] arr = {1, 3, 4, 2, 5};
        System.out.println(mergeSort(arr));
    }

    public static int mergeSort(int[] array_) {
        // 边界条件
        if (array_ == null || array_.length < 2) {
            return 0;
        }
        // 归并排序
        return mergeprocess(array_, 0, array_.length - 1);
    }

    public static int mergeprocess(int[] array_, int pre, int bhd) {
        // 结束某一个递归
        if (pre == bhd) {
            return 0;
        }
        // 防止溢出
        int mid = pre + ((bhd - pre) >> 1);
        return mergeprocess(array_, pre, mid) + mergeprocess(array_, mid + 1, bhd) + merge(array_, pre, mid, bhd);
    }

    public static int merge(int[] array_, int pre, int mid, int bhd) {
        // help array
        int[] helpArray = new int[bhd - pre + 1];
        // helpArray Index
        int i = 0;
        // pre index
        int pre_index = pre;
        // bhd index
        int bhd_index = mid + 1;
        int res = 0;
        // add data to helpArray
        while (pre_index <= mid && bhd_index <= bhd) {
            res += array_[pre_index] < array_[bhd_index] ? (bhd - bhd_index + 1) * array_[pre_index] : 0;
            // 不符合条件，先拷贝右边的数据
            helpArray[i++] = array_[pre_index] < array_[bhd_index] ? array_[pre_index++] :
                    array_[bhd_index++];
        }
        // bhd_index out of bandary
        while (pre_index <= mid) {
            helpArray[i++] = array_[pre_index++];
        }
        // pre_index out of bandary
        while (bhd_index <= bhd) {
            helpArray[i++] = array_[bhd_index++];
        }
        // copy helpArray to array_
        for (int j = 0; j < helpArray.length; j++) {
            // pre to bhd is orderly
            array_[pre + j] = helpArray[j];
        }
        return res;
    }
}
