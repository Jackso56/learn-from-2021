package com.linmu.adatastructure_.course_;

import java.util.PriorityQueue;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 * 堆排:
 * 左子节点：i << 2 + 1
 * 右子节点：i << 2 + 2
 * 父节点：(i - 1) / 2
 **/
@SuppressWarnings({"all"})
public class Course_06 {
    public static void main(String[] args) {
        // 小根堆:O(logN)
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();
        // 添加元素
        priorityQueue.add(2);
        priorityQueue.add(5);
        priorityQueue.add(1);
        priorityQueue.add(8);
        priorityQueue.add(9);
        priorityQueue.add(4);
        while (!priorityQueue.isEmpty()){
            // 删除元素
            System.out.println(priorityQueue.poll());
        }
    }
    class Heap {

        // 堆排
        public void heapSort(int[] array_){
            // 特殊情况
            if (array_ == null || array_.length < 2){
                return;
            }
            // 插入数据，形成大根堆
            for (int i = 0; i < array_.length; i++) {
                heapInsert(array_,i);
            }
            /*
            时间复杂度有所下降
            for (int i = array_.length;i > 0; i--){
                heapify(array_,i, array_.length);
            }
            */
            // 记录数组长度，以便变换堆的高度
            int heapsize = array_.length;
            // 交换堆中最大和最小的元素
            swap(array_,0,--heapsize);
            // 循环堆排，不断heapify()，再去除最后一个元素
            while (heapsize > 0){
                heapify(array_,0,heapsize);
                swap(array_,0,--heapsize);
            }
        }

        // 堆中插入数据，并形成大堆根
        public void heapInsert(int[] array_, int index) {
            while (array_[index] > array_[(index - 1) / 2]) {
                swap(array_, index, (index - 1) / 2);
                index = (index - 1) / 2;
            }
        }

        // 元素变动，恢复大堆根的形式
        public void heapify(int[] array_, int index, int heapsize) {
            // 左子节点序号
            int left = index << 1 + 1;
            // 存在子节点
            while (left < heapsize) {
                // 返回较大的子节点的下标
                int largest = left + 1 > heapsize && array_[left + 1] > array_[left] ?
                        left + 1 : left;
                // 返回子节点和父节点中较大值的下标
                largest = array_[index] > array_[largest] ? index : largest;
                // 当值达到适当位置时停止位置交换
                if (index == largest) {
                    break;
                }
                // 确定下标，交换位置
                swap(array_,index,largest);
                // 重置参数
                index = largest;
                left = index << 1 + 1;
            }
        }

        // 元素交换
        public void swap(int[] array_, int lIndex, int rIndex) {
            int temp = array_[lIndex];
            array_[lIndex] = array_[rIndex];
            array_[rIndex] = temp;
        }
    }
}
