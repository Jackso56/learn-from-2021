package com.linmu.adatastructure_.course_;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 比较器：
 * 实质上是比较重载运算符
 * 可以很好的应用于特殊标准的排序上
 * 可以很好的应用于特殊标准的排序的结构上
 **/
@SuppressWarnings({"all"})
public class Course_07 {
    public static void main(String[] args) {
        Student student1 = new Student("A",4,20);
        Student student2 = new Student("B",6,24);
        Student student3 = new Student("C",2,22);
        Student[] students = {student1,student2,student3};
        Arrays.sort(students,new idDescComparator());
        for (Student student : students) {
            System.out.println(student);
        }
    }

    // 通过比较器，转换大小根堆
    @Test
    public void method_01(){
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>(new Upper_());
        priorityQueue.add(9);
        priorityQueue.add(6);
        priorityQueue.add(3);
        priorityQueue.add(10);
        while (!priorityQueue.isEmpty()){
            System.out.println(priorityQueue.poll());
        }
    }
}
class Upper_ implements Comparator<Integer>{
    // 比较器默认升序，互换参数位置即可降序排序
    public int compare(Integer num1,Integer num2){
        return num2 - num1;
    }
}
@SuppressWarnings({"all"})
class Student{
    public String name;
    public int id;
    private int age;
    public Student(String name,int id,int age){
        this.name = name;
        this.id = id;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name='" + name + '\'' +
                ", id=" + id +
                ", age=" + age +
                '}';
    }
}
@SuppressWarnings({"all"})
class idDescComparator implements Comparator<Student>{
    /*
    * 比较器：实现Comparator接口
    * 所有比较器的潜台词：
    * 返回负数时，第一个数放在前面
    * 返回正数时，第二个数放在前面
    * 返回0时，那个数在前面无所谓
    * */
    @Override
    public int compare(Student o1, Student o2) {
        return o1.id - o2.id;
    }
}
