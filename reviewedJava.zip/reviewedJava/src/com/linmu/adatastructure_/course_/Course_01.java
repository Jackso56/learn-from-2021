package com.linmu.adatastructure_.course_;


import java.util.Arrays;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Course_01 {
    public static void main(String[] args) {
        System.out.println("选择排序");
        int[] array_ = {4, 8, 3, 9, 2, 1};
        selectMath(array_);
        for (int i = 0; i < array_.length; i++) {
            System.out.println(array_[i]);
        }
        System.out.println("冒泡排序");
        int[] array_1 = {4, 8, 3, 9, 2, 1};
        bobbleSort(array_1);
        for (int i = 0; i < array_1.length; i++) {
            System.out.println(array_1[i]);
        }
        System.out.println("插入排序");
        int[] array_2 = {4, 8, 3, 9, 2, 1};
        insertSort(array_2);
        for (int i = 0; i < array_2.length; i++) {
            System.out.println(array_2[i]);
        }
        int[] array_3 = {4, 8, 3, 9, 2, 1};
        Arrays.sort(array_3);
        for (int i = 0; i < array_3.length; i++) {
            System.out.println(array_3[i]);
        }
    }

    // 选择排序 O(N^2)
    public static void selectMathSwap(int[] array_, int oldIndex, int newIndex) {
        int temp = 0;
        temp = array_[oldIndex];
        array_[oldIndex] = array_[newIndex];
        array_[newIndex] = temp;
    }

    public static void selectMath(int[] array_) {
        // 特殊情况
        if (array_ == null || array_.length < 2) {
            return;
        }
        // i~array_.length - 1
        for (int i = 0; i < array_.length - 1; i++) {
            int minIndex = i;
            // i+1~array_length
            for (int j = i + 1; j < array_.length; j++) {
                // 返回数组较小值的下标
                minIndex = array_[j] < array_[minIndex] ? minIndex : j;
            }
            selectMathSwap(array_, minIndex, i);
        }
    }

    // 冒泡排序（涉及异或运算）O(N^2)
    public static void bobbleSortSwap(int[] array, int oldIndex, int newIndex) {
        /*^:异或运算，又称无进位相加
            异或运算的特性：1)0^N=N   2)N^N=0   3)异或运算满足交换律和结合律
            例如：a = 甲，b = 乙；a和b交换值
            a = a ^ b  ==》 a = 甲^乙
            b = a ^ b  ==》 b = 甲^乙^乙  --> b = 甲
            a = b ^ a  ==》 a =  甲^甲^乙 --> a = 乙
        */
        array[oldIndex] = array[oldIndex] ^ array[newIndex];
        array[newIndex] = array[oldIndex] ^ array[newIndex];
        array[oldIndex] = array[oldIndex] ^ array[newIndex];
    }

    public static void bobbleSort(int[] array_) {
        // 特殊情况
        if (array_ == null || array_.length < 2) {
            return;
        }
        // 确保array_[i] < array[i+1]...array_[array_.length - 1]
        // 双循环是否都从0开始，具体问题具体分析
        for (int i = 0; i < array_.length - 1; i++) {
            for (int j = 0; j < array_.length - 1 - i; j++) {
                if (array_[j] < array_[j + 1]) {
                    bobbleSortSwap(array_, j, j + 1);
                }
            }
        }
    }

    // 插入排序 O(N^2) 存在特殊数据的情况，时间复杂度可能下降
    public static void insertSort(int[] array_) {
        // 使0-i上有序,其中0-0上已经有序
        for (int i = 1; i < array_.length; i++) {
            // 开始排序,使当前位置上的数与前一位上的数进行比较
            for (int j = i - 1; j >= 0 && array_[j] < array_[j + 1]; j--) {
                insertSortSwap(array_, j, j + 1);
            }
        }
    }

    public static void insertSortSwap(int[] array_, int oldIndex, int newIndex) {
        array_[oldIndex] = array_[oldIndex] ^ array_[newIndex];
        array_[newIndex] = array_[oldIndex] ^ array_[newIndex];
        array_[oldIndex] = array_[oldIndex] ^ array_[newIndex];
    }
}
