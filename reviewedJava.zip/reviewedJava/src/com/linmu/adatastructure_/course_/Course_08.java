package com.linmu.adatastructure_.course_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 * 桶排（优化版）：非比较排序
 **/
@SuppressWarnings({"all"})
public class Course_08 {

    // 桶排主方法：O(N)
    public void radixSort(int[] array_){
        if (array_ == null || array_.length < 2){
            return;
        }
        radixSort(array_,0,array_.length - 1,maxDigit(array_));
    }

    // 返回最大值的位数
    public int maxDigit(int[] array_){
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < array_.length; i++) {
            max = Math.max(array_[i],max);
        }
        int count = 0;
        while (max != 0){
            count ++;
            max /= 10;
        }
        return count;
    }

    // 循环桶排[left...right]
    public void radixSort(int[] array_,int left,int right,int digit){
        final int radix = 10;
        int j = 0;
        int i = 0;
        // 辅助数组
        int[] helpArray_ = new int[right - left + 1];
        // 循环进桶出桶
        for (int d = 1; d <= digit; d++) {
            // 计数数组
            int[] count = new int[radix];
            // 数组计数
            for (i = left; i <= right; i++) {
                j = getDigit(array_[i],d);
                count[j]++;
            }
            // 计数累加
            for (i = 1; i < radix; i++) {
                count[i] = count[i] + count[i - 1];
            }
            // 进桶出桶的逻辑
            for (i = right; i >= left ; i--) {
                j = getDigit(array_[i],d);
                helpArray_[count[j] - 1] = array_[i];
                count[j]--;
            }
            // 拷贝数据，进入下次循环
            for (i = left, j = 0; i <= right; i++,j++){
                array_[i] = helpArray_[j];
            }
        }
    }

    // 返回元素的低位值
    public int getDigit(int digit_,int number){
        return ((digit_ / ((int)Math.pow(10,number - 1))) % 10);
    }
}
