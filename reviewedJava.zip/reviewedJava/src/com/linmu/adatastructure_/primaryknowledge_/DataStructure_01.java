
package com.linmu.adatastructure_.primaryknowledge_;

import org.testng.annotations.Test;

import java.util.*;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 数据结构简介：
 * 要点----只要符合对应数据结构的使用，就可以当做相应的数据结构来使用
 * 数据结构是为实现对计算机数据有效使用的各种数据组织形式，服务于各类计算机操作。
 * 不同的数据结构具有各自对应的适用场景，旨在降低各种算法计算的时间与空间复杂度，
 * 达到最佳的任务执行效率。
 *  (Array,Linked List,Stack,Queue,Heap,Hashing,Graph)
 * 常见的数据结构可分为「线性数据结构」与「非线性数据结构」：
 * 「线性数据结构」：「数组」、「链表」、「栈」、「队列」
 * 「非线性数据结构」：「树」、「图」、「散列表」、「堆」
 **/
@SuppressWarnings({"all"})
public class DataStructure_01 {

    /*
    数组(Array):
    数组是将相同类型的元素存储于连续内存空间的数据结构，其长度不可变。
    构建此数组需要在初始化时给定长度，并对数组每个索引元素赋值
    */
    @Test
    public void method01(){ // 静态数组
        // 创建时给定数组大小
        int[] array = new int[5];
        for (int i = 0;i < 5;i++){
            array[i] = i;
        }
        for (int i : array) {
            System.out.print(i + "\t");
        }
        System.out.println();
        // 赋值时自动检测数组大小
        int[] array1 = {1,6,3,8,2};
        for (int i : array1) {
            System.out.print(i + "\t");
        }
    }
    @Test
    public void method02(){ // 动态数组
//        「可变数组」是经常使用的数据结构，其基于数组和扩容机制实现，
//        相比普通数组更加灵活。常用操作有：访问元素、添加元素、删除元素。
        List<Integer> arrayList = new ArrayList<>();
        // 元素添加到数组的尾部
        arrayList.add(12);
        arrayList.add(2);
        arrayList.add(42);
        arrayList.add(90);
        for (Integer integer : arrayList) {
            System.out.print(integer + "\t");
        }
    }

    /*链表(Linked List)
    链表以节点为单位，每个元素都是一个独立对象，在内存空间的存储是非连续的。
    链表的节点对象具有两个成员变量：「值 val」，「后继节点引用 next」 。*/
    @Test
    public void method03(){
        // 实例化节点
        ListNode listNode = new ListNode(3); // head 节点
        ListNode listNode1 = new ListNode(5);
        ListNode listNode2 = new ListNode(7);
        // 创建节点的next索引
        listNode.next = listNode1;
        listNode1.next = listNode2;
    }

    /*栈(Stack)
     栈是一种具有 「先入后出」 特点的抽象数据结构，可使用数组或链表实现。数据出口只有一个
     通过常用操作「入栈 push()」,「出栈 pop()」，展示了栈的先入后出特性。
     注意：
     通常情况下，不推荐使用 Java 的 Vector 以及其子类 Stack ，而一般将 LinkedList 作为栈来使用。
     详情见：https://blog.csdn.net/cartoon_/article/details/87992743*/
    @Test
    public void method04(){
//        元素先入后出
        LinkedList<Integer> stack = new LinkedList<>();
        stack.addLast(1);   // 元素 1 入栈
        stack.addLast(2);   // 元素 2 入栈
//        元素的遍历和出栈不一样
        for (Integer integer : stack) {
            System.out.println("遍历元素：" + integer);
        }
        System.out.println("元素出栈：" + stack.removeLast()); // 出栈 -> 元素 2
        System.out.println("元素出栈：" + stack.removeLast()); // 出栈 -> 元素 1
    }

    /*队列(Queue)
     队列是一种具有 「先入先出」 特点的抽象数据结构，可使用链表实现。相当于一个管道
     通过常用操作「入队 offer()」,「出队 poll()」，展示了队列的先入先出特性。
     */
    @Test
    public void mrthod05(){
        LinkedList<Integer> queue = new LinkedList<>();
        queue.offer(2); // 元素2入队
        queue.offer(3); // 元素3入队
        queue.offer(4); // 元素4入队
        System.out.println(queue.poll()); // 元素2出队
        System.out.println(queue.poll()); // 元素3出队
        System.out.println(queue.poll()); // 元素4出队
    }

    /*树(Tree)
      树是一种非线性数据结构，根据子节点数量可分为 「二叉树」 和 「多叉树」，
      最顶层的节点称为「根节点 root」。以二叉树为例，
      每个节点包含三个成员变量：「值 val」、「左子节点 left」、「右子节点 right」 。
     */
    @Test
    public void method06(){
        // 初始化节点
        TreeNode n1 = new TreeNode(3); // 根节点 root
        TreeNode n2 = new TreeNode(4);
        TreeNode n3 = new TreeNode(5);
        TreeNode n4 = new TreeNode(1);
        TreeNode n5 = new TreeNode(2);
        // 构建引用指向
        n1.left = n2;
        n1.right = n3;
        n2.left = n4;
        n2.right = n5;
    }

    /*
    图（Graph）
    图是一种非线性数据结构，由「节点（顶点）vertex」和「边 edge」组成，
    每条边连接一对顶点。根据边的方向有无，图可分为「有向图」和「无向图」。
    本文 以无向图为例 开展介绍。
    此无向图的 顶点 和 边 集合分别为：
    顶点集合： vertices = {1, 2, 3, 4, 5}
    边集合： edges = {(1, 2), (1, 3), (1, 4), (1, 5), (2, 4), (3, 5), (4, 5)}
    表示图的方法通常有两种：
    1）邻接矩阵： 使用数组 vertices 存储顶点，edges 存储边；
        edges[i][j]代表节点 i + 1和 节点 j + 1 之间是否有边(用1表示有边，0表示无边)
        vertices = [1, 2, 3, 4, 5]
        edges = [[0, 1, 1, 1, 1],
                 [1, 0, 0, 1, 0],
                 [1, 0, 0, 0, 1],
                 [1, 1, 0, 0, 1],
                 [1, 0, 1, 1, 0]]
     2）邻接表（每一条边都有编号）： 使用数组 vertices1 存储顶点，邻接表 edges 存储边。
         edges1 为一个二维容器，
         第一维 i 代表顶点索引，第二维 edges1[i] 存储此顶点对应的边集和；
         例如 edges1[0] = [1, 2, 3, 4] 代表 vertices1[0]的边集合为 [1, 2, 3, 4]
        vertices = [1, 2, 3, 4, 5]
        edges = [[1, 2, 3, 4],
                 [0, 3],
                 [0, 4],
                 [0, 1, 4],
                 [0, 2, 3]]
    */
    @Test
    public void method07(){

        int[] vertices = {1,2, 3, 4, 5};
        int[][] edges = {
            {0, 1, 1, 1, 1},
            {1, 0, 0, 1, 0},
            {1, 0, 0, 0, 1},
            {1, 1, 0, 0, 1},
            {1, 0, 1, 1, 0}
        };
        // 这里把边的集合的数据元素编号从0开始
        int[] vertices1 = {1, 2, 3, 4, 5};
        int[][] edges1 = {
            {1, 2, 3, 4},
            {0, 3},
            {0, 4},
            {0, 1, 4},
            {0, 2, 3}
        };
    }

    /*散列表
    散列表是一种非线性数据结构，通过利用 Hash 函数将指定的「键 key」映射至对应的「值 value」，
    以实现高效的元素查找。*/
    @Test
    public void method08(){
        // 设想一个简单场景：小力、小特、小扣的学号分别为 10001, 10002, 10003 。
        //现需求从「姓名」查找「学号」。
        //则可通过建立姓名为 key ，学号为 value 的散列表实现此需求
        Map<String,Integer> hashMap = new HashMap();
        hashMap.put("小力",10001);
        hashMap.put("小特",10002);
        hashMap.put("小扣",10003);
        System.out.println(hashMap.get("小力"));
        System.out.println(hashMap.get("小特"));
        System.out.println(hashMap.get("小扣"));
    }

    /*堆(heap)：
    堆是一种基于「完全二叉树」的数据结构，可使用数组实现。
    以堆为原理的排序算法称为「堆排序」，基于堆实现的数据结构为「优先队列」。
    堆分为「大顶堆」和「小顶堆」，大（小）顶堆：任意节点的值不大于（小于）其父节点的值。
    完全二叉树定义： 设二叉树深度为 kk ，
    若二叉树除第 kk 层外的其它各层（第 11 至 k-1k−1 层）的节点达到最大个数，
    且处于第 kk 层的节点都连续集中在最左边，则称此二叉树为完全二叉树。
    */
    @Test
    public void method09(){
        // 大顶堆：元素由大到小     小顶堆（PriorityQueue）：元素由小到大
//        初始化大顶堆
        Queue<Integer> queue = new PriorityQueue<>(new Comparator<Integer>() {
            @Override
            public int compare(Integer o1, Integer o2) {
                return o2 - o1;
            }
        }); // 默认为小顶堆，可出入比较器初始化大顶堆
//        元素入堆
        queue.add(1);
        queue.add(4);
        queue.add(6);
        queue.add(2);
        queue.add(8);
        queue.add(3);
//        元素出堆
        System.out.println("元素出堆：" + queue.poll());
        System.out.println("元素出堆：" + queue.poll());
        System.out.println("元素出堆：" + queue.poll());
        System.out.println("元素出堆：" + queue.poll());
        System.out.println("元素出堆：" + queue.poll());
        System.out.println("元素出堆：" + queue.poll());
    }
}
class ListNode{
    int val;  // 接收节点的值
    ListNode next;  // 节点的唯一后继
    ListNode(int val){
        this.val = val;
    }
}
class TreeNode {
    int val;        // 节点值
    TreeNode left;  // 左子节点
    TreeNode right; // 右子节点
    TreeNode(int x) { val = x; }
}
