package com.linmu.adatastructure_.DatastructureBasics;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashSet;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class BinarySearch {  // 二分查找
    @Test
    public void Test() {
        int[] array = new int[10];
        for (int i = 0; i < 10; i++) {
            array[i] = (int) (Math.random() * 100) - (int) (Math.random() * 100);
        }
//        Arrays.sort(array);
        System.out.println(Arrays.toString(array));
        System.out.println(getMinIndex(array));
    }

    public boolean binarySearch(int[] array, int number) {
        if (array == null || array.length == 0) {
            return false;
        }
        int left = 0;
        int right = array.length - 1;
        int middle = 0;
        while (left < right) {
            middle = left + ((right - left) >> 1);
            if (array[middle] == number) {
                return true;
            } else if (array[middle] < number) {
                left = middle + 1;
            } else {
                right = middle - 1;
            }
        }
        return array[middle] == number;
    }

    // 应用1：返回>=number的最左边的索引
    public int getIndex(int[] array, int number) {
        if (array == null || array.length == 0) {
            return -1;
        }
        int left = 0;
        int right = array.length - 1;
        int middle = 0;
        int index = 0;
        while (left <= right) {
            middle = left + ((right - left) >> 1);
            if (array[middle] >= number) {
                right = middle - 1;
                index = middle;
            } else {
                left = middle + 1;
            }
        }
        return index;
    }

    // 应用二：寻找局部最小值，返回索引
    public int getMinIndex(int[] array) {
        if (array == null || array.length == 0) {
            return -1;
        }
        if (array[0] < array[1]) {
            return 0;
        }
        if (array[array.length - 2] > array[array.length - 1]) {
            return array.length - 1;
        }
        int left = 1;
        int right = array.length - 2;
        int middle = 0;
        while (left < right) {
            middle = left + ((right - left) >> 1);
            if (array[middle] > array[middle - 1]) {
                right = middle - 1;
            } else if (array[middle] > array[middle + 1]) {
                left = middle + 1;
            } else {
                return middle;
            }
        }
        // ????????
        return left;
    }
}

