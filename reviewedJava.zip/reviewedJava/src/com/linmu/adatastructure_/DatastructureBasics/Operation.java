package com.linmu.adatastructure_.DatastructureBasics;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class Operation { // 异或运算
    public static void main(String[] args) {
        System.out.println(Arrays.toString(swap(12, 17)));
    }

    @Test
    public static int[] swap(int num1, int num2) {
        // 不使用额外变量交换两个数的值
        num1 = num1 ^ num2;
        num2 = num1 ^ num2;
        num1 = num1 ^ num2;
        return new int[]{num1, num2};
    }

    // 应用1：给定数组，只要一种数出现了奇数次，其他数都出现了偶数次，打印该数
    @Test
    public static int printnum1(int[] arr) {
        int num = 0;
        for (int i = 0; i < arr.length; i++) {
            num ^= arr[i];
        }
        return num;
    }

    // 应用2：返回最左侧的1
    @Test
    public static int getOne(int number) { // -a ==  ~a+1
        number = number & (-number + 1);
        return number;
    }

    // 应用3：给定数组，只要两种数出现了奇数次，其他数都出现了偶数次，打印这两个数
    @Test
    public static int[] getDouble(int[] arr) {// 根据最左侧1的位置进行分组
        int num = 0;
        for (int i = 0; i < arr.length; i++) {
            num ^= arr[i];
        }
        int rightone = num & (-num);
        int onlyone = 0;
        for (int i = 0; i < arr.length; i++) {
            if ((arr[i] & rightone) != 0) {
                onlyone ^= arr[i];
            }
        }
        return new int[]{onlyone, (num ^ onlyone)};
    }

    // 应用4：给定数组，只要1种数出现了k次，其他数都出现了m次，出现k次的数
    public static int getKTimesNumber(int[] arr, int k, int m) {
        int[] saveNum = new int[32];
        for (int num : arr) {
            for (int i = 0; i < 32; i++) {
                saveNum[i] += (num >> i) & 1;
            }
        }
        int answer = 0;
        for (int i = 0; i < 32; i++) {
            if (saveNum[i] % m != 0) {
                answer |= (1 << i);
            }
        }
        return answer;
    }


    // 对数器
    @Test
    public void main() {
        int maxvalu = 200;
        int maxkind = 10;
        int count = 9;
        int testtime = 100000;
        System.out.println("begin..");
        for (int i = 0; i < testtime; i++) {
            int a = getRandomNumber(count);
            int b = getRandomNumber(count);
            int k = Math.min(a, b);
            int m = Math.max(a, b);
            if (k == m) {
                m++;
            }
            int[] arr = getRandomArray(maxvalu, maxkind, k, m);
            int num1 = getKTN(arr, k, m);
            int num2 = getKTimesNumber(arr, k, m);
            if (num1 != num2){
                System.out.println("isError.." + num1 + "\t" + num2);
            }
        }
        System.out.println("end..");


    }

    // 常规方法
    public int getKTN(int[] arr, int k, int m) {
        HashMap<Integer, Integer> numbers = new HashMap();
        for (int num : arr) {
            if (numbers.containsKey(num)) {
                numbers.put(num, numbers.get(num) + 1);
            } else {
                numbers.put(num, 1);
            }
        }
        for (int num : numbers.keySet()) {
            if (numbers.get(num) == k) {
                return num;
            }
        }
        return -1;
    }

    // 获取随机数组
    public int[] getRandomArray(int maxvalue, int maxkind, int k, int m) {
        int knumber = getRandomNumber(maxkind);
        int cnumber = getRandomNumber(maxkind) + 2;
        int[] arr = new int[k + (cnumber - 1) * m];
        int[] randomArray = new int[getRandomNumber(maxkind)];
        int index = 0;
        for ( ;index < k; index++) {
            arr[index] = knumber;
        }
        cnumber--;
        HashSet<Integer> numbers = new HashSet<>();
        numbers.add(knumber);
        while (cnumber != 0){
            int num = 0;
            do{
                num = getRandomNumber(maxvalue);
            }while(numbers.contains(num));
            numbers.add(num);
            cnumber--;
            for (int i = 0; i < m; i++) {
                arr[index++] = num;
            }
        }
        for (int i = 0; i < arr.length; i++) {
            int j = getRandomNumber(arr.length - 1);
            swap(arr[i],arr[j]);
        }
        return arr;
    }

    // 数据交换
    public void swapNumber(int num1, int num2){
        int tmp = num1;
        num1 = num2;
        num2 = tmp;
    }

    // 获取随机数
    public int getRandomNumber(int maxval) {
        return (int) (Math.random() * maxval + 1);
    }
}


