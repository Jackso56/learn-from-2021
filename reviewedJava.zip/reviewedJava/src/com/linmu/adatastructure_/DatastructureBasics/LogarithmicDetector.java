package com.linmu.adatastructure_.DatastructureBasics;

import org.testng.annotations.Test;

import java.util.Arrays;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class LogarithmicDetector {
    private final int testTime = 1000000;
    private final int maxSize = 100;
    private final int maxNumber = 100;
    // 调用方法实现对数
    @Test
    public void detector(){
        boolean flag = true;
        for (int i = 0; i < testTime; i++) {
            int[] data1 = randomData();
            Arrays.sort(data1);
            int[] data2 = copyData(data1);
            //自定义算法
            new InsertSort().insertsort(data2);
            flag = contrast(data1,data2);
        }
        System.out.println(flag == true ? "Successful..." : "Error...");
    }
    // 产生随机数组
    public int[] randomData(){
        int[] datas = new int[(int)(Math.random()*maxSize)];
        for (int i = 0; i < datas.length; i++) {
            datas[i] = (int)(Math.random()*maxNumber) - (int)(Math.random()*maxNumber);
        }
        return datas;
    }
    // 拷贝数组
    public int[] copyData(int[] datas){
        if (datas == null){
            return datas;
        }
        int[] data = new int[datas.length];
        for (int i = 0; i < datas.length; i++) {
            data[i] = datas[i];
        }
        return data;
    }
    // 对比数据
    public boolean contrast(int[] data1, int[] data2){
        boolean flag = true;
        for (int i = 0; i < data1.length - 1; i++) {
            if (data1[i] != data2[i]){
                flag = false;
            }
        }
        return flag;
    }

}
