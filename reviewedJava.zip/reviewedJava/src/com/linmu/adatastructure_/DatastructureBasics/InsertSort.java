package com.linmu.adatastructure_.DatastructureBasics;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class InsertSort {
    public void insertsort(int[] array){
        if (array == null || array.length < 2){
            return;
        }

    }
    public void sort(int[] array, int left, int right){
        for (int i = 0; i <= right - left; i++) {
            for (int j = 0; j <= right - left - i; j++) {
                if (array[j] > array[j+1]){
                    swap(array, j, j+1);
                }
            }
        }
    }
    public void swap(int[] array, int left, int right){
        int tmp = array[left];
        array[left] = array[right];
        array[right] = tmp;
    }
}
