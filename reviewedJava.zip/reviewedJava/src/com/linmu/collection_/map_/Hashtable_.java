package com.linmu.collection_.map_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Hashtable简介
 * 1）键和值均不能为空
 * 2）方法与HashMap一样
 * 3）线程安全（synchronized）
 * 4）Hashtable底层维护了Hashtable$Node数组，初始化大小为11，
 *      调用addEntry(hash,key,value,index)来添加元素到Entry中
 * 5）加载因子为0.75
 * 6）到达临界值后，按“(数组大小<<1)+1”方式扩容
 **/
@SuppressWarnings({"all"})
public class Hashtable_ {
}
