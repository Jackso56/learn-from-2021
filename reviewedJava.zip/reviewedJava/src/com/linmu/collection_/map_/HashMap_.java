package com.linmu.collection_.map_;

import java.util.Arrays;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * HashMap小结
 * 1）HashMap是Map接口常用的实现子类
 * 2）以键值对的方式存储数据
 * 3）键和值均可为null，键不可重复，值可重复
 * 4）键相同，意味着替换键对应的值
 * 5）不保证存取顺序一致，jdk8以后，底层使用数组+链表+红黑树
 * 6）没有做同步互斥操作，线程不安全
 *
 * HashMap底层源码分析
 * 1）HashMap底层维护了Node类型的数组table，默认为null
 * 2）table大小初始默认16，加载因子为0.75
 * 2）当单条链表的元素大于8，数组到大于等于64时，将会变成红黑树
 **/
@SuppressWarnings({"all"})
public class HashMap_ {
    public static void main(String[] args) {
    }
}
