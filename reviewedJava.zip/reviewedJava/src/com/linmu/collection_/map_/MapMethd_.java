package com.linmu.collection_.map_;

import org.testng.annotations.Test;

import javax.crypto.spec.PSource;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Map接口实现类简介：
 * 1）Map与Collection并列，Map保存着数据键值对
 * 2）值可以重复，键不能重复
 * 3）键和值都可以是null
 * 4）常用String对象作为键
 * 5）数据的k-v存在一一对应的关系
 *
 * Map常用实现子类：HashMap,Hashtable,properties
 *
 * Map接口常用方法;put,get,size,isEmpty,remove,containsKey,containsValues,
 *                  keySet,values,entrySet,clear
 *
 *  元素遍历方式：两种
 *                 1）EntrySet集合中存放着多个HashMap$Node键值对
 *                 2）Map.Entry中有getKey()和getValues()方法方便我们遍历元素
 *                      因此要向下转型
 **/
@SuppressWarnings({"all"})
public class MapMethd_ {

    @Test
    public void method(){
        Map hashMap = new HashMap();
//        添加元素
        hashMap.put("1","林沐");
        hashMap.put("3","林沐");
        hashMap.put("5","林羽");
        hashMap.put("2","观南");
        hashMap.put("6","林冲");
        hashMap.put("4","林动");
        System.out.println("hashMap元素：" + hashMap);
//        根据键获取值
        System.out.println("1对应的元素：" + hashMap.get("1"));
//        获取大小
        System.out.println("hashMap的大小：" + hashMap.size());
//        空判断
        System.out.println("hashMap是否为空：" + hashMap.isEmpty());
//        删除元素
        hashMap.remove("1");
        System.out.println("删除元素方式一，hashMap的元素：" + hashMap);
        hashMap.remove("2","观南");
        System.out.println("删除元素方式二，hashMap的元素：" + hashMap);
//        键存在判断
        System.out.println("键是否存在：" + hashMap.containsKey("3"));
//        值存在判断
        System.out.println("值是否存在：" + hashMap.containsValue("林动"));
//        获取所有的键
        System.out.println("获取所有键：" + hashMap.keySet());
//        获取所有的值
        System.out.println("获取所有值：" + hashMap.values());
//        获取所有的键值对
        System.out.println("获取所有键值对：" + hashMap.entrySet());
//        清空数据
        hashMap.clear();
        System.out.println("清除HashMap后，hashMap的元素：" + hashMap);
    }

    @Test
    public void TraverseElements(){
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("jack",1);
        hashMap.put("jackson",2);
        hashMap.put("mike",3);
        hashMap.put("jhon",4);
        System.out.println("获取数据的方式一：");
        Set<Map.Entry<String, Integer>> entries = hashMap.entrySet();
        for (Map.Entry<String, Integer> entry : entries) {
            System.out.println(entry.getKey() + "\t" + entry.getValue());
        }
        System.out.println("获取数据的方式二：");
        Set<String> strings = hashMap.keySet();
        for (String string : strings) {
            System.out.println(string + "\t" + hashMap.get(string));
        }
    }

    @Test
    public void method02(){
        Map hashMap = new HashMap();
        hashMap.put("1","林沐");
        hashMap.put("2","林沐");
        hashMap.put("3","林羽");
        hashMap.put("4","观南");
        hashMap.put("5","林冲");
        hashMap.put("6","林动");
//        方式一：获取键---》获取值
        Set set = hashMap.keySet();
        for (Object object : set) {
            System.out.println("增强for循环遍历元素：" + object + "=" + hashMap.get(object));
        }
        System.out.println("++++++++++++++++");
        Iterator iterator = set.iterator();
        while (iterator.hasNext()){
            Object next = iterator.next();
            System.out.println("迭代器遍历元素：" + next + "=" + hashMap.get(next));
        }
    }

    @Test
    public void method03() {
        Map hashMap = new HashMap();
        hashMap.put("1", "林沐");
        hashMap.put("2", "林沐");
        hashMap.put("3", "林羽");
        hashMap.put("4", "观南");
        hashMap.put("5", "林冲");
        hashMap.put("6", "林动");
//        方式二：键值对
        Set set = hashMap.entrySet();
        System.out.println(set.getClass());
        System.out.println(hashMap.getClass());
        for (Object o : set) {
//            向下转型，可调用方法
            Map.Entry entry = (Map.Entry)o;
            System.out.println("for循环遍历元素：" + entry.getKey() + "=" + entry.getValue());
            System.out.println("运行类型：" + entry.getClass());
        }
        System.out.println("++++++++++++++++++++");
        Iterator iterator = set.iterator();
        while (iterator.hasNext()){
            Object next = iterator.next();
            Map.Entry entry =  (Map.Entry)next;
            System.out.println("for循环遍历元素：" + entry.getKey() + "=" + entry.getValue());
            System.out.println("运行类型：" + entry.getClass());
        }
    }
}
