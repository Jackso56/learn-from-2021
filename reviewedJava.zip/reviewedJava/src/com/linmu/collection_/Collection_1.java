package com.linmu.collection_;

import java.util.Hashtable;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 *
 *                              Collection实际业务开发中如何选择：
 *                  1）判断数据类型：一组对象（单列），一组键值对（双列）
 *                  2）单列：Collection接口
 *                         允许重复：List接口
 *                                  增删多，LinkedList[底层维护了一个双向链表]
 *                                  改查多：ArrayList、Vector[底层维护了Object类型的可变数组]
 *                         不允许重复：Set接口
 *                                  无序：HashSet[底层是HashMap，数组+双向链表+红黑树]
 *                                  排序：TreeSet（构造器中允许传入比较器）
 *                                  存取顺序一致：LinkedTreeSet,底层维护的是数组+双向链表
 *                  3）双列：Map接口
 *                          键无序：HashMap[jdk7以前：数组+链表  jdk8以后：数组+双向链表+红黑树]
 *                          键排序：TreeMap（构造器中允许传入比较器）
 *                          存取顺序一致;LinkedHashMap
 *                          读取文件：Properties
 **/
@SuppressWarnings({"all"})
public class Collection_1 {
    public static void main(String[] args) {
    }
}

























