package com.linmu.collection_;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Collections工具类简介
 * 1）Collections是一个操作Set，List，Map等集合的工具类
 * 2）Collections中提供了一系列静态得方法对集合元素进行排序，查询和修改等操作
 *
 * Collections方法（均为静态）:reverse,shuffle,sort,swap,max,min,frequency
 *  *                              copy,replaceAll,
 **/
@SuppressWarnings({"all"})
public class Connections_ {

    @Test
    public void method01(){
        ArrayList arrayList = new ArrayList();
        arrayList.add("林沐师兄");
        arrayList.add("林羽1");
        arrayList.add("林尧1234");
        arrayList.add("林冲");
        System.out.println("arrayList元素："  + arrayList);
//        元素反转
        Collections.reverse(arrayList);
        System.out.println("arrayList元素反转："  + arrayList);
//        随机排序
        Collections.shuffle(arrayList);
        System.out.println("arrayList元素随机排序："  + arrayList);
//        排序(默认升序),可重写比较器
        Collections.sort(arrayList);
        System.out.println("arrayList元素排序："  + arrayList);
        Collections.sort(arrayList, new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length();
            }
        });
        System.out.println("arrayList元素排序："  + arrayList);
//        交换元素
        Collections.swap(arrayList,0,2);
        System.out.println("arrayList元素交换："  + arrayList);
//        最大值，最小值，可传入比较器
        System.out.println("arrayList元素最大值：" + Collections.max(arrayList));
        System.out.println("arrayList元素最小值：" + Collections.min(arrayList));
//        复制,存在元素覆盖的情况，因此要考虑集合的大小问题，会存在溢出的情况
        ArrayList arrayList1 = new ArrayList();
        arrayList1.add("观南");
        arrayList1.add("若辰");
        arrayList1.add("南裘");
        // 源集合的长度需要小于等于目标数组的长度
        Collections.copy(arrayList,arrayList1);
        System.out.println("元素copy：" + arrayList);
//        元素替换
        Collections.replaceAll(arrayList,"观南","望北");
        System.out.println("元素替换：" + arrayList);
    }
}
