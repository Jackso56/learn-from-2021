package com.linmu.collection_.collection_.set_;

import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.Set;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Set简介：
 * 1）元素无序（存取顺序不一定一致）
 * 2）不支持索引
 * 3）不允许元素重复，只能有一null
 * Set接口的常用方法继承Collection的常用方法
 * Set接口实现子类的两种元素遍历方式，不支持索引遍历
 **/
@SuppressWarnings({"all"})
public class Set_ {

    @Test
    public void method01(){
        Set hashSet = new HashSet();
        hashSet.add("林沐");
        hashSet.add("林沐");
        hashSet.add("林彡");
        hashSet.add("林羽");
        hashSet.add("林尧");
        System.out.println("hashSet的元素：" + hashSet);
//        System.out.println("hashSet的元素：" + hashSet);
    }
}
