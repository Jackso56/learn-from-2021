package com.linmu.collection_.collection_.set_;

import org.testng.annotations.Test;

import java.util.LinkedHashSet;
import java.util.Set;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * LinkedHashSet简介：
 * 1）LinkedHashSet是HashSet的子类
 * 2）LinkedHashSet的底层是LinkedHashMap,底层维护了一个数组加链表
 * 3）LinkedHashSet根据元素的hash值来决定元素的存储位置，
 *      同时使用链表来维护元素的次序，这看起来元素是以插入顺序保存的
 * 4）不允许元素重复
 **/
@SuppressWarnings({"all"})
public class LinkedHashSet_ {

    @Test
    public void method01(){
        Set linkedHashSet = new LinkedHashSet();
        linkedHashSet.add("林沐");
        linkedHashSet.add("林沐");
        linkedHashSet.add("林羽");
        linkedHashSet.add("林动");
        linkedHashSet.add("林冲");
        linkedHashSet.add("林尧");
        System.out.println("linkedHashSet元素：" + linkedHashSet);


    }
}
