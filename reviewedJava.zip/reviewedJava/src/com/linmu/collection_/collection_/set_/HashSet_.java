package com.linmu.collection_.collection_.set_;

import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.Set;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * HashSet的底层是HashMap，HashMap的底层是数组、链表、红黑树
 * 1）HashSet底层是HashMap
 * 2）添加元素时，先得到hash值，hash再转索引值
 *      （具有相同的hash值的元素，会放在同一条链表上）
 * 3）找到数据表的table，看索引位置上是否有元素
 * 4）若没有，直接加入；若有，则调用equals方法，
 *         相同不添加，不相同，添加在同一条链表上
 * 5）Java8中，当单链表的元素个数大于8，数组大小大于等于64时，
 *          就会树化，数组会变成红黑树
 *
 * HashSet扩容机制：
 * 1）HashSet中table的初始化大小为16
 * 2）当table的数据元素达到临界值（数组大小*加载因子---这里加载因子为0.75）
 * 3）table数组按两倍扩容
 * 4）当单链表的元素个数大于8，数组大小大于等于64时，
 *    就会树化，数组会变成红黑树
 *
 **/
@SuppressWarnings({"all"})
public class HashSet_ {

    @Test
    public void method01(){
        Set hashSet = new HashSet();
        hashSet.add("林沐");
        hashSet.add("林羽");
        hashSet.add("林尧");
        hashSet.add("林动");
        hashSet.add("林冲");
        System.out.println("hashSet元素：" + hashSet);
    }
}
