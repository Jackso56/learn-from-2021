package com.linmu.collection_.collection_.set_;

import org.testng.annotations.Test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.TreeSet;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 **/
@SuppressWarnings({"all"})
public class TreeSet_ {

    @Test
    public void method01(){
        TreeSet treeSet = new TreeSet(new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                return ((String)o1).length() - ((String)o2).length();
            }
        });
        treeSet.add("jack");
        treeSet.add("jackson");
        treeSet.add("mike");
        treeSet.add("jhon");
        treeSet.add("black");
//        会自动去除长度相同的元素
        System.out.println("treeSet元素：" + treeSet);
    }
}
