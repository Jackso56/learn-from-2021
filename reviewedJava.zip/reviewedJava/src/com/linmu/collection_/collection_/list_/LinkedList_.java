package com.linmu.collection_.collection_.list_;

import org.testng.annotations.Test;

import java.util.LinkedList;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * LinkedList源码分析：
 * 1）LinkedList底层维护的是一个双向链表
 * 2）LinkedList底层维护了first、last属性分别指向首节点和尾节点
 * 3）每个节点（Node）里面又维护了prev、next、item属性，分别表示
 *      指向前一个节点，指向下一个节点，节点内容；最终实现了双向链表、
 * 4）元素的增加、删除不是通过数组完成的，因此效率较高
 *
 *                      ArrayList和LinkedList对比
 *                  底层结构        增删的效率               改查效率
 *    ArrayList     可变数组        较低，数组扩容           较高
 *    LinkedList    双向链表        较高，通过链表追加       较低
 *
 *    建议：1）改查多，用ArrayList；增删多用LinkedList
 *          2）一般业务中改查多于增删，但也要具体问题具体分析
 **/
@SuppressWarnings({"all"})
public class LinkedList_ {

    @Test
    public void method01(){
        LinkedList linkedList = new LinkedList();
        linkedList.add("林沐大师兄");
        linkedList.add("林沐二师兄");
        linkedList.add("林羽三师兄");
        linkedList.add("林尧四师兄");
        linkedList.add("林彡师弟");
        linkedList.add("林沐大师兄");
        linkedList.add("若辰大师兄");
        System.out.println("linkedList的元素：" + linkedList);
    }
}
