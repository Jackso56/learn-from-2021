package com.linmu.collection_.collection_.list_;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collection;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * ArrayList源码分析：
 * 1）ArrayList底层维护了一个Object类型的数组：Object[] elementData
 * 2）使用无参构造器是，默认初始大小为10,空间不足则1.5倍扩容
 * 3）使用有参构造器是，默认初始大小为指定大小,空间不足则1.5倍扩容
 * 4）ArrayList线程不安全（效率高），多线程情况下，不建议使用
 * 5）可以加入任何元素，包括null（且可以有多个null）
 **/
@SuppressWarnings({"all"})
public class ArrayList_ {

    @Test
    public void method01(){
        Collection arrayList = new ArrayList();
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        arrayList.add("林羽");
        System.out.println("arrayList的元素：" + arrayList);
    }

    @Test
    public void method02(){
        Collection arrayList = new ArrayList(4);
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        arrayList.add("林羽");
        System.out.println("arrayList的元素：" + arrayList);
    }
}
