package com.linmu.collection_.collection_.list_;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * List接口基本介绍
 * 1）List集合类中的元素有序（即：存取顺序一致，且可重复）
 * 2）支持索引
 * 3）三个实现子类：ArrayList,LinkedList,Vector
 * List接口基本方法：add(),addAll(),   增加元素
 *                   remove(),  删除元素
 *                   set(), 修改元素
 *                   get(),subList(),indexOf(),lastIndexOf()    查找元素
 * List接口的实现子类两种集合元素遍历方式：增强for循环，Iterator迭代器
 **/
@SuppressWarnings({"all"})
public class ListMethod_ {

    @Test
    public void method(){
        ArrayList arrayList = new ArrayList();
        arrayList.add("林沐");
        arrayList.add("林羽");
        arrayList.add("林沐");
        System.out.println("arrayList的元素：" + arrayList);
//        获取指定位置的元素
        System.out.println("arrayList的第二个元素：" + arrayList.get(1));
    }

    @Test
    public void method02(){
        ArrayList arrayList = new ArrayList();
        arrayList.add("林沐大师兄");
        arrayList.add("林沐二师兄");
        arrayList.add("林羽三师兄");
        arrayList.add("林尧四师兄");
        arrayList.add("林彡师弟");
        arrayList.add("林沐大师兄");
        arrayList.add("若辰大师兄");
        System.out.println("arrayList元素：" + arrayList);
//        在指定位置添加元素
        arrayList.add(3,"观南师弟");
        System.out.println("arrayList元素:" + arrayList);
        ArrayList arrayList1 = new ArrayList();
        arrayList1.add("鬼羽山");
        arrayList1.add("鬼冢");
//        添加多个元素
        arrayList.addAll(arrayList1);
        System.out.println("arrayList的元素：" + arrayList);
//        返回元素序号：第一次出现，最后一次出现
        System.out.println("林沐第一次出现的位置：" + arrayList.indexOf("林沐大师兄"));
        System.out.println("林沐最后一次出现的位置：" + arrayList.lastIndexOf("林沐大师兄"));
//        删除指定位置的元素
        arrayList.remove(0);
        System.out.println("arrayList的元素：" + arrayList);
//        指定位置替换元素
        arrayList.set(0,"林沐");
        System.out.println("arrayList的元素：" + arrayList);
//        返回子集合
        System.out.println("arrayList的子集合：" + arrayList.subList(0,4));
    }

    @Test
    public void method03(){
        ArrayList arrayList = new ArrayList();
        arrayList.add("林沐大师兄");
        arrayList.add("林沐二师兄");
        arrayList.add("林羽三师兄");
        arrayList.add("林尧四师兄");
        arrayList.add("林彡师弟");
        arrayList.add("林沐大师兄");
        arrayList.add("若辰大师兄");
//        集合元素遍历方式一：增强for循环
        for (Object object : arrayList) {
            System.out.println("arrayList元素：" + object);
        }
        System.out.println("++++++++++++++++++++++++++++++++++++");
//        集合元素遍历方式二：Iterator迭代器
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()){
            System.out.println("arrayList元素：" + iterator.next());
        }
    }
}
