package com.linmu.collection_.collection_.list_;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 *                          Vecotr与ArrayList的对比
 *                  底层结构        版本          线程安全（同步），效率       扩容
 *   Vector                        JDK1.0        线程安全，效率不高         可指定大小（默认10），1.5倍扩容
 *                  可变数组
 *   ArrayList                     JDK1.2        线程不安全，效率不高        可指定大小（默认10），2倍扩容
 *
 **/
@SuppressWarnings({"all"})
public class Vector_ {

}
