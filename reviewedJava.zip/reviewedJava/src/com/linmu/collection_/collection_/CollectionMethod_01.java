package com.linmu.collection_.collection_;

import org.testng.annotations.Test;

import java.util.Collection;
import java.util.ArrayList;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * 集合的好处：集合可以动态存储多个对象
 * Collection下的单列集合：List(ArrayList,LinkedList,Vector),
 *                          Set(HashSet,TreeSet,LinkedHashSet)
 * 1)collection实现类可以存放多个元素，每个元素可以是Object
 * 2）collection实现类，List存放重复元素，Set元素不可重复
 * 3）collection实现类，有些是有序的（List），有些是无序的（Set）
 * Collection接口常见方法：add(),remove(),contains(),isEmpty(),clear(),size(),
 *                      addAll(),removeAll(),containsAll()
 * Map下的双列集合：HashMap,Hashtable,LinkedHashMap,TreeMap,Properties
 *
 *
 * ArrayList <--- List <--- Connection <--- Iterable
 * public interface List<E> extends Collection<E>
 * public class ArrayList<E> extends AbstractList<E>
 *         implements List<E>, RandomAccess, Cloneable, java.io.Serializable
 * public interface Collection<E> extends Iterable<E>
 **/
@SuppressWarnings({"all"})
public class CollectionMethod_01 {

    @Test
    public void method01(){
        Collection arraylist = new ArrayList();
//        添加元素
        arraylist.add("林沐");
        arraylist.add(19);
        arraylist.add(3.14);
        arraylist.add('A');
        System.out.println("集合元素：" + arraylist);
//        删除元素
        arraylist.remove(19);
        System.out.println("集合元素：" + arraylist);
//        查询元素
        System.out.println("元素是否包含在集合中：" + arraylist.contains("林沐"));
//        查看元素大小
        System.out.println("集合大小：" + arraylist.size());
//        判断是否为空集合
        System.out.println("集合是否为空：" + arraylist.isEmpty());
//        清空集合
        arraylist.clear();
        System.out.println("集合元素：" + arraylist);
        System.out.println("集合是否为空：" + arraylist.isEmpty());
    }

    @Test
    public void method02(){
        Collection arrayList = new ArrayList();
        arrayList.add("林羽");
        arrayList.add(12);
        arrayList.add('a');
        Collection newArrayList = new ArrayList();
//        一次性添加多个元素
        newArrayList.addAll(arrayList);
        System.out.println("newArrayList集合元素：" + newArrayList);
        newArrayList.add("林沐");
//        查看多个元素是否存在
        System.out.println("查看是否存在多个元素：" + newArrayList.containsAll(arrayList));
//        一次性删除多个元素
        newArrayList.removeAll(arrayList);
        System.out.println("newArrayList集合元素：" + newArrayList);
    }
}
