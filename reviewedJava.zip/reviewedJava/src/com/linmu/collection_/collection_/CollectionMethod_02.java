package com.linmu.collection_.collection_;

import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * @author 林沐
 * @version 先努力变强，再大方拥有
 *
 * Collection接口遍历元素方式1-使用Iterator（迭代器）
 * 1）Iterrator对象称为迭代器，主要用于遍历Collection集合中的元素
 * 2）所有实现Collection接口的集合类都是一个iterator方法，用于返回
 *      一个实现了Iterator接口的对象，即可以返回一个迭代器
 * 3）Iterator仅用于遍历集合，Iterator本身不存放对象
 *
 *  Iterator常用方法：hasNext(),next()
 *
 **/
@SuppressWarnings({"all"})
public class CollectionMethod_02 {

    @Test // Collection接口遍历元素方式1-使用Iterator（迭代器）
    public void method01(){
        Collection arrayList = new ArrayList();
        arrayList.add(new Book("三国演义","罗贯中",100));
        arrayList.add(new Book("水浒传","施耐庵",99));
        arrayList.add(new Book("西游记","吴承恩",130));
//        iterator()方法用于返回一个迭代器
        Iterator iterator = arrayList.iterator();
//        hasNext()判断是否还有下一个元素
        while (iterator.hasNext()){
//            next()返回下一个元素,涉及游标/指针的移动
            System.out.println("arrayList元素：" + iterator.next());
        }
    }

    @Test // Collection接口遍历元素方式2-使用增强for循环
    public void method02(){ // 增强for循环是简化的迭代器遍历，但底层仍然是迭代器
        Collection arrayList = new ArrayList();
        arrayList.add(new Book("三国演义","罗贯中",100));
        arrayList.add(new Book("水浒传","施耐庵",99));
        arrayList.add(new Book("西游记","吴承恩",130));
        for (Object object : arrayList) {
            System.out.println("arrayList元素：" + object);
        }
    }
}
@SuppressWarnings({"all"})
class Book{
    private String name;
    private String author;
    private double price;

    public Book(String name, String author, double price) {
        this.name = name;
        this.author = author;
        this.price = price;
    }

    @Override
    public String toString() {
        return "Book{" +
                "name='" + name + '\'' +
                ", author='" + author + '\'' +
                ", price=" + price +
                '}';
    }
}
